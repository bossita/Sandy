﻿using System;
using System.Collections.Generic;

public class FemaleCivState : IAnimationState
{
    public enum FemaleCivStateEnum
    {
        Default = -1,
        Idle = 0,
        Walk = 1,
        Death = 3,
    }
    //public Dictionary<SoldierStateEnum, string> stateToTrigger { get; } = new Dictionary<SoldierStateEnum, string>()
    //{
    //    {SoldierStateEnum.Idle, "Idle"},
    //    {SoldierStateEnum.Walk, "Walk"},
    //    {SoldierStateEnum.Fire, "WeaponFire"},
    //    {SoldierStateEnum.Death, "Death"},
    //};

    public Dictionary<Enum, string> stateToTrigger { get; } = new Dictionary<Enum, string>()
    {
        {FemaleCivStateEnum.Idle, "Idle"},
        {FemaleCivStateEnum.Walk, "Walk"},
        {FemaleCivStateEnum.Death, "Death"},
    };
    public Dictionary<string, Enum> stateNameToState { get; } = new Dictionary<string, Enum>()
    {
        {"Idle" ,FemaleCivStateEnum.Idle},
        {"Walk" ,FemaleCivStateEnum.Walk},
        { "Death",FemaleCivStateEnum.Death},
    };
}
