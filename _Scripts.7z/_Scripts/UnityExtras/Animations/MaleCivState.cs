﻿using System;
using System.Collections.Generic;

public class MaleCivState : IAnimationState
{
    public enum MaleCivStateEnum
    {
        Default = -1,
        Idle = 0,
        Walk = 1,
        Throw = 2,
        Death = 3,
    }
    //public Dictionary<SoldierStateEnum, string> stateToTrigger { get; } = new Dictionary<SoldierStateEnum, string>()
    //{
    //    {SoldierStateEnum.Idle, "Idle"},
    //    {SoldierStateEnum.Walk, "Walk"},
    //    {SoldierStateEnum.Fire, "WeaponFire"},
    //    {SoldierStateEnum.Death, "Death"},
    //};

    public Dictionary<Enum, string> stateToTrigger { get; } = new Dictionary<Enum, string>()
    {
        {MaleCivStateEnum.Idle, "Idle"},
        {MaleCivStateEnum.Walk, "Walk"},
        {MaleCivStateEnum.Throw, "Throw"},
        {MaleCivStateEnum.Death, "Death"},
    };
    public Dictionary<string, Enum> stateNameToState { get; } = new Dictionary<string, Enum>()
    {
        {"Idle" ,MaleCivStateEnum.Idle},
        {"Walk" ,MaleCivStateEnum.Walk},
        { "Throw",MaleCivStateEnum.Throw},
        { "Death",MaleCivStateEnum.Death},
    };
}
