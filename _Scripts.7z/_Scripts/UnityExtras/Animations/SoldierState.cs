﻿using System;
using System.Collections.Generic;

public class SoldierState : IAnimationState
{
    public enum SoldierStateEnum
    {
        Default = -1,
        Idle = 0,
        Walk = 1,
        Fire = 2,
        Death = 3,
    }
    //public Dictionary<SoldierStateEnum, string> stateToTrigger { get; } = new Dictionary<SoldierStateEnum, string>()
    //{
    //    {SoldierStateEnum.Idle, "Idle"},
    //    {SoldierStateEnum.Walk, "Walk"},
    //    {SoldierStateEnum.Fire, "WeaponFire"},
    //    {SoldierStateEnum.Death, "Death"},
    //};

    public Dictionary<Enum, string> stateToTrigger { get; } = new Dictionary<Enum, string>()
    {
        {SoldierStateEnum.Idle, "Idle"},
        {SoldierStateEnum.Walk, "Walk"},
        {SoldierStateEnum.Fire, "WeaponFire"},
        {SoldierStateEnum.Death, "Death"},
    };
    public Dictionary<string, Enum> stateNameToState { get; } = new Dictionary<string, Enum>()
    {
        {"Idle",SoldierStateEnum.Idle},
        {"Walk",SoldierStateEnum.Walk},
        {"WeaponFire",SoldierStateEnum.Fire},
        {"Death",SoldierStateEnum.Death},
    };
}
