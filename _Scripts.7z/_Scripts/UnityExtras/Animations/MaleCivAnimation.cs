﻿using System;
using UnityEngine;

public class MaleCivAnimation : IAnimation
{
    public bool ChangeState(Animator animator, IAnimationState animationState, EntityInformation info, string stateName)
    {
        Enum state = animationState.stateNameToState[stateName];
        //Debug.Log(state);
        if (!CanChangeState(animator, state))
        {
            return false;
        }
        animator.SetTrigger(animationState.stateToTrigger[state]);
        info.holder.state = state;
        //Debug.Log(state);
        return true;
    }
    public bool ChangeState(Animator animator, IAnimationState animationState, EntityInformation info, Enum state)
    {   
        //Debug.Log(state);
        if (!CanChangeState(animator, state))
        {
            return false;
        }
        animator.SetTrigger(animationState.stateToTrigger[state]);
        info.holder.state = state;
        //Debug.Log(state);
        return true;
    }
    public bool CanChangeState(Animator animator, System.Enum state)
    {
        return (MaleCivState.MaleCivStateEnum)state != MaleCivState.MaleCivStateEnum.Death;
    }
    public Enum GetCurrentState(Animator animator)
    {   
        int animationStateNameHash = animator.GetCurrentAnimatorStateInfo(0).shortNameHash;
        if (animationStateNameHash == Animator.StringToHash("Idle"))
        {
            return MaleCivState.MaleCivStateEnum.Idle;
        }
        if (animationStateNameHash == Animator.StringToHash("Walk"))
        {
            return MaleCivState.MaleCivStateEnum.Walk;
        }
        if (animationStateNameHash == Animator.StringToHash("Throw"))
        {
            return MaleCivState.MaleCivStateEnum.Throw;
        }
        if (animationStateNameHash == Animator.StringToHash("Death"))
        {
            return MaleCivState.MaleCivStateEnum.Death;
        }
        return MaleCivState.MaleCivStateEnum.Default;
    }
}
