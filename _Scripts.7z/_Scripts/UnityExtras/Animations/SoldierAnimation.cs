﻿using System;
using UnityEngine;

public class SoldierAnimation : IAnimation
{   
    public bool ChangeState(Animator animator, IAnimationState animationState, EntityInformation info, string stateName)
    {
        Enum state = animationState.stateNameToState[stateName];
        //Debug.Log(state);
        if (!CanChangeState(animator,state))
        {
            return false;
        }
        animator.SetTrigger(animationState.stateToTrigger[state]);
        info.holder.state = state;
        //Debug.Log(state);
        return true;
    }
    public bool ChangeState(Animator animator, IAnimationState animationState, EntityInformation info, Enum state)
    {    
        //Debug.Log(state);
        if (!CanChangeState(animator, state))
        {
            return false;
        }
        animator.SetTrigger(animationState.stateToTrigger[state]);
        info.holder.state = state;
        //Debug.Log(state);
        return true;
    }
    public bool CanChangeState(Animator animator, System.Enum state)
    {
        return (SoldierState.SoldierStateEnum)state != SoldierState.SoldierStateEnum.Death;
    }
    public Enum GetCurrentState(Animator animator)
    {
        int animationStateNameHash = animator.GetCurrentAnimatorStateInfo(0).shortNameHash;
        if (animationStateNameHash == Animator.StringToHash("Rifle Idle"))
        {
            return SoldierState.SoldierStateEnum.Idle;
        }
        if (animationStateNameHash == Animator.StringToHash("Rifle Walk"))
        {
            return SoldierState.SoldierStateEnum.Walk;
        }
        if (animationStateNameHash == Animator.StringToHash("Rifle Fire"))
        {
            return SoldierState.SoldierStateEnum.Fire;
        }
        if (animationStateNameHash == Animator.StringToHash("Rifle Death"))
        {
            return SoldierState.SoldierStateEnum.Death;
        }
        return SoldierState.SoldierStateEnum.Default;
    }
}
