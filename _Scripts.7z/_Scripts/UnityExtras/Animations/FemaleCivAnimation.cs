﻿using System;
using UnityEngine;

public class FemaleCivAnimation : IAnimation
{
    public bool ChangeState(Animator animator, IAnimationState animationState, EntityInformation info, string stateName)
    {
        Enum state = animationState.stateNameToState[stateName];
        //Debug.Log(state);
        if (!CanChangeState(animator, state))
        {
            return false;
        }
        animator.SetTrigger(animationState.stateToTrigger[state]);
        info.holder.state = state;
        //Debug.Log(state);
        return true;
    }
    public bool ChangeState(Animator animator, IAnimationState animationState, EntityInformation info, Enum state)
    {    
        //Debug.Log(state);
        if (!CanChangeState(animator, state))
        {
            return false;
        }
        animator.SetTrigger(animationState.stateToTrigger[state]);
        info.holder.state = state;
        //Debug.Log(state);
        return true;
    }
    public bool CanChangeState(Animator animator, System.Enum state)
    {
        return (FemaleCivState.FemaleCivStateEnum)state != FemaleCivState.FemaleCivStateEnum.Death;
    }
    public Enum GetCurrentState(Animator animator)
    {
        int animationStateNameHash = animator.GetCurrentAnimatorStateInfo(0).shortNameHash;
        if (animationStateNameHash == Animator.StringToHash("Idle"))
        {
            return FemaleCivState.FemaleCivStateEnum.Idle;
        }
        if (animationStateNameHash == Animator.StringToHash("Walk"))
        {
            return FemaleCivState.FemaleCivStateEnum.Walk;
        }
        if (animationStateNameHash == Animator.StringToHash("Death"))
        {
            return FemaleCivState.FemaleCivStateEnum.Death;
        }
        return FemaleCivState.FemaleCivStateEnum.Default;
    }
}
