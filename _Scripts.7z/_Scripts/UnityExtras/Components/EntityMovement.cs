﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class EntityMovement : MonoBehaviour
//{
//    [HideInInspector]
//    public EntityInformation info;
    
//    public float startTime;
    
//    public float deltaSeconds;
    
//    public float offSet;
    
//    public Vector3d distance;
    
//    public Vector3d destination;
    
//    public Vector3d startPosition;
    
//    public bool isMoving;
//    // Start is called before the first frame update
//    void Start()
//    {
//        startTime = Time.realtimeSinceStartup;
//        isMoving = false;
//    }

//    // Update is called once per frame
//    void Update()
//    {
//        if (this.gameObject.name == "1_3001_846vrx")
//        {
//            Debug.Log("another second passed by");
//        }
//        if (isMoving)
//        {
            

//            offSet = Time.realtimeSinceStartup - startTime;
//            if (this.gameObject.name == "1_3001_846vrx")
//            {
//                //Debug.Log("offSet: " + offSet);
//                //Debug.Log("deltaSeconds: " + deltaSeconds);
//                //Debug.Log("realtimeSinceStartup: " + Time.realtimeSinceStartup);
//            }
//            if (offSet > deltaSeconds)
//            {
//                offSet = deltaSeconds;
//            }
//            info.reflectedEntity.lastWorldLocation = startPosition + (distance * offSet / deltaSeconds);
//            Vector3 unityPosition = (Vector3)TransformCoordinates.ECEF2Unity(info.reflectedEntity.lastWorldLocation);
//            if (this.gameObject.name == "1_3001_846vrx")
//            {
//                Debug.Log("now at: " + this.transform.localPosition);
//            }
//            Debug.LogFormat("Distance in unity world: {0}", Vector3.Distance(info.gameObject.transform.localPosition, unityPosition));
//            //if (Vector3.Distance(info.gameObject.transform.localPosition, unityPosition) >= 0.001)
//            //{
//            //    info.gameObject.transform.localPosition = unityPosition;
//            //}
//            info.gameObject.transform.localPosition = unityPosition;
//            if (info.reflectedEntity.lastWorldLocation.Equals(destination))
//            {
//                if (this.gameObject.name == "1_3001_846vrx")
//                {
//                    Debug.Log(info.reflectedEntity.lastWorldLocation + " Equals " + destination);
//                }
//                isMoving = false;
//            }
//            //if (Vector3.Distance(info.gameObject.transform.localPosition, unityPosition) >= 0.001)
//            //{
//            //    info.gameObject.transform.localPosition = unityPosition;
//            //}
//            //info.gameObject.transform.localPosition = unityPosition;
//            //if (Vector3d.Distance(info.reflectedEntity.lastWorldLocation, destination) >= 0.001)
//            //{
//            //    if (this.gameObject.name == "1_3001_846vrx")
//            //    {
//            //        Debug.Log(info.reflectedEntity.lastWorldLocation + " Equals " + destination);
//            //    }
//            //    isMoving = false;
//            //}
//        }
//    }
//    public void SetNewDestination(Vector3d destination, float deltaTime)
//    {
//        if(deltaTime<0.001)
//        {
//            return;
//        }
//        if (this.gameObject.name == "1_3001_846vrx")
//        {
//            //Debug.Log("moving from: " + this.transform.localPosition + " to: " + destination);
//            Debug.Log("delta time: "+deltaTime);
//        }

//        this.destination = destination;
//        this.deltaSeconds = deltaTime;
//        this.startTime = Time.realtimeSinceStartup;
//        this.startPosition = info.reflectedEntity.lastWorldLocation;
//        this.distance = destination - startPosition;
//        this.isMoving = true;
//    }
//    //List<Vector3> positions = new List<Vector3>();
//    //public IEnumerator MoveEntityBetweenMessages(EntityInformation info, Vector3d endPosition, float deltaSeconds)
//    //{
//    //    string path = @"C:\EntitiesFiles\" + info.gameObject.name + ".log";
//    //    System.IO.File.AppendAllText(path, "\n" + Time.realtimeSinceStartup.ToString() + " ");
//    //    Vector3d startPosition = info.reflectedEntity.lastWorldLocation;
//    //    float startTime = Time.realtimeSinceStartup;
//    //    float offSet = 0;
//    //    Vector3d distance = endPosition - startPosition;
//    //    while (offSet < deltaSeconds)
//    //    {
//    //        System.IO.File.AppendAllText(path, Time.realtimeSinceStartup.ToString() + " ");
//    //        yield return new WaitForSeconds(0.0002f);
//    //        //yield return null;
//    //        System.IO.File.AppendAllText(path, Time.realtimeSinceStartup.ToString() + " ");
//    //        offSet = Time.realtimeSinceStartup - startTime;
//    //        if (offSet > deltaSeconds)
//    //        {
//    //            offSet = deltaSeconds;
//    //        }
//    //        info.reflectedEntity.lastWorldLocation = startPosition + (distance * offSet / deltaSeconds);
//    //        Vector3 unityPosition = (Vector3)TransformCoordinates.ECEF2Unity(info.reflectedEntity.lastWorldLocation);
//    //        if (info.gameObject.name == "1_3001_846vrx")
//    //        {
//    //            positions.Add(unityPosition);
//    //        }
//    //        info.gameObject.transform.localPosition = unityPosition;
//    //        System.IO.File.AppendAllText(path, Time.realtimeSinceStartup.ToString() + " ");
//    //    }
//    //}
//    //if (firstTime)
//    //{
//    //    info.reflectedEntity.lastWorldLocation = Vector3d.From3DArray(worldLocationXYZ);
//    //    entity.transform.localPosition = (Vector3)TransformCoordinates.ECEF2Unity(info.reflectedEntity.lastWorldLocation);
//    //}
//    //else
//    //{
//    //    try
//    //    {
//    //        StopCoroutine(info.holder.movementCoroutine);
//    //    }
//    //    catch
//    //    {

//    //    }
//    //    //if (info.gameObject.name == "1_3001_846vrx")
//    //    //{
//    //    //    for (int i = 0; i < positions.Count; i++)
//    //    //    {
//    //    //        Debug.LogFormat("{0}: ({1}, {2}, {3})" , i, positions[i].x,positions[i].y,positions[i].z);
//    //    //    }
//    //    //    positions.Clear();
//    //    //}
//    //    float deltaSeconds = currentTimeUpdatedUnity - info.reflectedEntity.lastTimeUpdatedUnity;
//    //    info.holder.movementCoroutine = StartCoroutine(MoveEntityBetweenMessages(info, Vector3d.From3DArray(worldLocationXYZ), deltaSeconds));
//    //}
//}
