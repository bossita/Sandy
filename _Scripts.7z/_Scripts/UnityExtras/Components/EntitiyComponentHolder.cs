﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntitiyComponentHolder
{
    public Enum state;
    public Animator animator;
    public Coroutine DeadReckoningCoroutine = null;
    public Queue<DeadReckoningCoroutineParams> DeadReckoningParameters = new Queue<DeadReckoningCoroutineParams>();
    //public Queue<Coroutine> rotationCoroutines = new Queue<Coroutine>();
    //public Queue<MovementCoroutineParams> rotationParameters = new Queue<MovementCoroutineParams>();


    //??
    Orientation orientation;

}
