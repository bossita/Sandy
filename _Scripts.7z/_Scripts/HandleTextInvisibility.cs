﻿using Assets.Game._Scripts.Helpers;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class HandleTextInvisibility : MonoBehaviour
{
    [SerializeField]
    public GameObject textsHolder;
    private TextMeshPro[] allTexts;

    [SerializeField]
    public BoxCollider boxIndicatingVisibility;
    private Vector3[] verticesPositions;

    private void Start()
    {
        allTexts = textsHolder.GetComponentsInChildren<TextMeshPro>();
        Vector3[] verticesDirections = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(boxIndicatingVisibility, BOX_COLLIDER_VERTICES.TopVerticesOfBoxCollider());
        verticesPositions = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirections, boxIndicatingVisibility);
    }
    private void Update()
    {
        UpdateTextsVisibilityByPosition();
    }
    private void UpdateTextsVisibilityByPosition()
    {
        foreach (TextMeshPro text in allTexts)
        {
            Vector3 textPos = text.transform.position;
            bool visibilityState = OutOfRangeHelper.IsPointWhitinRect(verticesPositions, textPos);
            text.gameObject.SetActive(visibilityState);
        }
    }
}
