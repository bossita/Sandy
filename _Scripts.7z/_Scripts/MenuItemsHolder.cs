﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MenuItemsHolder : MonoBehaviour
{
    private const string MENU_ITEMS_TAG = "MenuItem";
    public List<GameObject> MenuItems;

	void Awake ()
    {
        MenuItems = GameObject.FindGameObjectsWithTag(MENU_ITEMS_TAG).ToList();
	}
	
    public void AddMenuItem(GameObject newMenuItem)
    {
        MenuItems.Add(newMenuItem);
    }

    public void RemoveMenuItem(GameObject menuItemToRemove)
    {
        MenuItems.Remove(menuItemToRemove);
    }
}
