﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CullByDistanceAndLayer : MonoBehaviour
{
    private Camera cameraAttached;
    public int indexLayerToCull;
    public float distanceCulling;

    void Start ()
    {
        cameraAttached = GetComponent<Camera>();
        float[] distancesInLayers = new float[32];
        distancesInLayers[indexLayerToCull] = distanceCulling;
        // layerCull distances works that if the value of indexLayer is 0 -> it will use default farplane,
        // thus no need to assign value to other indecies.
        cameraAttached.layerCullDistances = distancesInLayers;
    }

}
