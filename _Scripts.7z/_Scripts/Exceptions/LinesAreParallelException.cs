﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Game._Scripts.Exceptions
{
    public class LinesAreParallelException : Exception
    {
        private const string MESSAGE_EXCEPTION = "There is no intersection between the lines, " +
                                                        "because the lines are parallel";
        public LinesAreParallelException() : base(MESSAGE_EXCEPTION)
        {
        }
        public LinesAreParallelException(string message) : base(message)
        {
        }
    }
}
