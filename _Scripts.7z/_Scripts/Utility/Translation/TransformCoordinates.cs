﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class TransformCoordinates
{
    public static Vector3 ECEF2Unity(double xECEF, double yECEF, double zECEF)
    {
        return new Vector3()
        {
            z = (float)-zECEF,
            y = (float)(xECEF - MultiClass.equatorial_radius_WGS84),
            x = (float)-yECEF,
        };
    }

    //public static Vector3 ECEF2Unity(double[] coord)
    //{
    //    if (coord.Length != 3)
    //    {
    //        Debug.LogError("coordinate specified is not a 3d coordinate");
    //    }

    //    return ECEF2Unity(coord[0], coord[1], coord[2]);
    //}

    public static double[] ECEF2Unity(double[] coord)
    {
        return new double[]
        {
            -coord[1],
            coord[0] - MultiClass.equatorial_radius_WGS84,
            -coord[2],
        };
    }
    public static Vector3d ECEF2Unity(Vector3d coord)
    {
        return new Vector3d
        (
            -coord[1],
            coord[0] - MultiClass.equatorial_radius_WGS84,
            -coord[2]
        );
    }

    public static Vector3 doubleArrayToVector3(double[] array)
    {
        return new Vector3()
        {
            x = (float)array[0],
            y = (float)array[1],
            z = (float)array[2],
        };
    }

    public static double ConvertRadiansToDegrees(double radians)
    {
        double degrees = (180 / System.Math.PI) * radians;
        return degrees;
    }


    public static Vector3d ECEFOrientation2UnityEulerAngles(Vector3d orientationPsiThetaPhi, bool isHuman)
    {
        const int x = 2;
        const int y = 1;
        const int z = 0;
        const float xBonus = 90;
        const float yBonus = -90;
        const float zBonus = -90;
        const float xMult = 1;
        const float yMult = 1;
        const float zMult = 1;

        //const int x = 2;
        //const int y = 1;
        //const int z = 0; // inverted
        //const float xBonus = 0;
        //const float yBonus = -90;
        //const float zBonus = 0;
        //const float xMult = 1;
        //const float yMult = 1;
        //const float zMult = 1;
        Vector3d eulerAngles = eulerAngles = new Vector3d()
        {
            x = (xMult * TransformCoordinates.ConvertRadiansToDegrees(orientationPsiThetaPhi[x])) + xBonus,
            y = (yMult * TransformCoordinates.ConvertRadiansToDegrees(orientationPsiThetaPhi[y])) + yBonus,
            z = (zMult * TransformCoordinates.ConvertRadiansToDegrees(orientationPsiThetaPhi[z])) + zBonus,
        };

        //if (isHuman)
        //{
            if (((180 - Mathd.Abs(eulerAngles.x)) < Mathd.Abs(eulerAngles.x))
            && ((180 - Mathd.Abs(eulerAngles.z)) < Mathd.Abs(eulerAngles.z)))
            {
                eulerAngles.y = -(180 + eulerAngles.y);
            }
        //}        

        // should have definitely found a solution that replaces this code yet
        

        return eulerAngles;
    }
}
