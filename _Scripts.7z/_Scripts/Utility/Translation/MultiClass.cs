﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class MultiClass : MonoBehaviour
{
    public const double equatorial_radius_WGS84 = 6378137;
    const double flattening_WGS84 = 1 / 298.257223563;
    static Spheroid WGS84Spheroid = new Spheroid(6378137.0, 6356752.3142);
    static MapDatum WGS84 = new MapDatum(new Spheroid(6378137.0, 6356752.3142), 0, 0, 0);
    public class Spheroid
    {
        public double semiMajor;
        public double semiMinor;

        public Spheroid(double semiMajor, double semiMinor)
        {
            this.semiMajor = semiMajor;
            this.semiMinor = semiMinor;
        }
    }
    public class MapDatum
    {
        public Spheroid spheroid;
        public double[] datumShift;
        public MapDatum(Spheroid spheroid, double x, double y, double z)
        {
            this.spheroid = spheroid;
            this.datumShift = new double[] { x, y, z };
        }
        public MapDatum()
        {
            this.datumShift = new double[3];
        }
    }
    public class ReferenceEllipsoid
    {
        private MapDatum mapDatum;
        double ellipse_a = 0;
        double ellipse_a_sq = 0;
        double ellipse_f = 0;
        double ellipse_b = 0;
        double ellipse_b_sq = 0;
        double ellipse_a_sq_over_b = 0;
        double ellipse_e = 0;
        double ellipse_c1 = 0;
        double maxIterationsForConvergence = 5000;

        public ReferenceEllipsoid(MapDatum datum)
        {
            this.mapDatum = new MapDatum(datum.spheroid, datum.datumShift[0], datum.datumShift[1], datum.datumShift[2]);
            //var self = this;//?????

            var inverseFlattening = (this.mapDatum.spheroid.semiMajor -
             this.mapDatum.spheroid.semiMinor) /
             this.mapDatum.spheroid.semiMajor;
            this.InitializeEllipsoid(this.mapDatum.spheroid.semiMajor, inverseFlattening);
        }

        public void InitializeEllipsoid(double a, double f)
        {
            ellipse_a = a;
            ellipse_a_sq = ellipse_a * ellipse_a;
            ellipse_f = f;
            ellipse_b = ellipse_a * (1.0 - ellipse_f);
            ellipse_b_sq = ellipse_b * ellipse_b;
            ellipse_a_sq_over_b = ellipse_a_sq / ellipse_b;

            /* changed by Huat Ng                         */
            /* ellipse_e = ellipse_f * (2.0 + ellipse_f); */

            ellipse_e = ellipse_f * (2.0 - ellipse_f);
            ellipse_c1 = (1.0 - ellipse_f) * (1.0 - ellipse_f);
        }

        public double[] GeodeticToGeocentric(double lat, double lon, double height)
        {
            /* obtain the vertical and horizontal projection of the      */
            /* point on the ellipsoid                                    */
            double sinlat = Math.Sin(lat);
            double temp1 = ellipse_a / Math.Sqrt(1.0 - (ellipse_e * (sinlat * sinlat)));
            double temp2 = temp1 * ellipse_c1;
            temp1 += height;
            temp2 += height;
            /* obtain the projected horizontal position on the equatorial plane */
            double w = temp1 * Math.Cos(lat);

            /* obtain the projected vertical position on the polar axis */
            double z = temp2 * sinlat;

            /* project the horizontal position on the two axes in the       */
            /* equatorial plane.                                            */
            double x = w * Math.Cos(lon);

            /* cannot use sqrt here, y will always be positive if this is the case */
            /* changed by Huat Ng     */
            /* *y = sqrt((w * w) - (*x * *x));     */
            double y = w * Math.Sin(lon);

            return new double[] { x, y, z };
        }
        public double[] GeocentricToGeodetic(double xp, double yp, double zp)
        {
            double m;
            double h;
            double f;
            double f_prime;
            double h_previous;
            double xp_sq;
            double yp_sq;
            double zp_sq;
            double wp;
            double wp_sq;
            double x;
            double y;
            double z;
            double w;
            double w_sq;
            double tanphi;
            double temp1;
            double temp2;
            double temp1_sq;
            double temp2_sq;
            double temp_m;
            double theMaxIterationsForConvergence = 5000;
            double lat = 0;
            double lon;
            double height = 0;

            /* test for special cases on longitude.        */
            /* initialize both special cases to FALSE first. */

            bool special_case1 = false;
            bool special_case2 = false;
            if (xp != 0)
            {
                /* xp not equal to zero: ordinary case */
                lon = Math.Atan2(yp, xp);
            }
            else
            {
                /* xp is zero */
                if (yp > 0)
                {
                    lon = (Math.PI / 2);
                }
                else if (yp < 0)
                {
                    lon = -(Math.PI / 2);
                }
                else
                {
                    /* xp and yp is both zero: special case */
                    special_case2 = true;

                    //console.log("Longitude is undefined when X = Y = 0");

                    // Arbitrarily set longitude to 0.
                    lon = 0;

                    if (zp > 0.0)
                    {
                        lat = (Math.PI / 2);
                    }
                    else if (zp < 0.0)
                    {
                        lat = -(Math.PI / 2);
                    }
                    else
                    {
                        // Center of Earth
                        special_case1 = true;
                        //console.log("Both latitude and h are undefined when X = Y = Z = 0");
                        lat = 0;
                        lon = 0;
                        height = -ellipse_a;
                    }
                }
            }
            if (!special_case1)
            {
                /* calculate squares of xp, yp, and zp */

                xp_sq = xp * xp;
                yp_sq = yp * yp;
                zp_sq = zp * zp;

                /* calculate wp square */
                wp_sq = xp_sq + yp_sq;
                wp = Math.Sqrt(wp_sq);

                /* Initial guess */
                temp_m = ellipse_a_sq * zp_sq + ellipse_b_sq * wp_sq;
                m = 0.5 * ((ellipse_a * ellipse_b * temp_m * (Math.Sqrt(temp_m) -
                   ellipse_a * ellipse_b)) /
                   (ellipse_a_sq * ellipse_a_sq * zp_sq +
                   ellipse_b_sq * ellipse_b_sq * wp_sq));

                /* calculate x, y, z */
                x = (1.0 / (1.0 + (2.0 * m) / ellipse_a_sq)) * xp;
                y = (1.0 / (1.0 + (2.0 * m) / ellipse_a_sq)) * yp;
                z = (1.0 / (1.0 + (2.0 * m) / ellipse_b_sq)) * zp;

                /* calculate height */
                h = Math.Sqrt((xp - x) * (xp - x) + (yp - y) * (yp - y) + (zp - z) * (zp - z));


                var count = 0;
                /* begins the iteration for convergence */
                do
                {
                    h_previous = h;

                    temp1 = ellipse_a + (2.0 * m) / ellipse_a;
                    temp2 = ellipse_b + (2.0 * m) / ellipse_b;
                    temp1_sq = temp1 * temp1;
                    temp2_sq = temp2 * temp2;

                    /* calculate f and f prime */
                    f = wp_sq / temp1_sq + zp_sq / temp2_sq - 1.0;
                    f_prime = -(4.0 * wp_sq) / (ellipse_a * temp1 * temp1_sq)
                       - (4.0 * zp_sq) / (ellipse_b * temp2 * temp2_sq);


                    /* Newton-Raphson's convergence algorithm */
                    m = m - f / f_prime;
                    w = (1.0 / (1.0 + (2.0 * m) / ellipse_a_sq)) * wp;
                    z = (1.0 / (1.0 + (2.0 * m) / ellipse_b_sq)) * zp;


                    /* recalculate the height */
                    h = Math.Sqrt((wp - w) * (wp - w) + (zp - z) * (zp - z));
                    if (count++ > theMaxIterationsForConvergence)
                    {
                        Debug.LogError("Maximum Iterations exceeded(" + theMaxIterationsForConvergence + "), probable error.");
                        //DtTHROW_NEW(DtException,errorMsg);
                    }

                } while (Math.Abs(h - h_previous) > 0.5);

                /* convert x, y, z into latitude, longitude, and height */
                w_sq = w * w;

                /* assign the value for height */
                height = h;

                if ((wp_sq + zp_sq) < (w_sq + z * z))
                {
                    height = -(height);
                }

                /* calculate for latitude */
                if (!special_case2)
                {
                    tanphi = (ellipse_a_sq_over_b *
                       Math.Sqrt(Math.Abs(1.0 - w_sq / ellipse_a_sq))) / w;

                    lat = Math.Atan(tanphi);
                    if (zp < 0)
                    {
                        lat = -(lat);
                    }
                }
                /* if special case 2 is false */
            }
            /* end of special case 1 */

            return new double[] { lat, lon, height };
        }
        public double[] RadToGeo(double radian)
        {
            double deg_min_sec;
            double min_and_sec;
            double sec_only;

            deg_min_sec = Math.Abs(radian * (360.0 / (2.0 / Math.PI)));

            /* rounds the argument down to an integer */
            var deg = Math.Floor(deg_min_sec);

            /* get the fractional part of radian argument */
            min_and_sec = deg_min_sec - deg;

            /* get the minutes part out from the fraction */
            var min = Math.Floor(min_and_sec * 60.0);

            /* get the fractional part of the min_and_sec argument */
            sec_only = (min_and_sec * 60.0) - min;

            var sec = sec_only * 60.0;

            return new double[] { deg, min, sec };
        }
        /**
        Convert a given geocentric coordinate to geodetic.
        @param {Array} gc Geocentric coordinate
        @return {Array} Array containing latitude, longitude, altitude.  Latitude and
        longitude are given in radians, altitude in meters.
        **/
        public double[] GeocentricToGeodetic(double[] gc)
        {
            var result = this.GeocentricToGeodetic(gc[0] - this.mapDatum.datumShift[0],
               gc[1] - this.mapDatum.datumShift[1],
               gc[2] - this.mapDatum.datumShift[2]);

            return result;
        }
        /**
        Convert a given geodetic coordinate to geocentric.
        @param {Array} Array containing latitude, longitude, altitude.  Latitude and
        longitude are given in radians, altitude in meters.
        @return {Array} gc Geocentric coordinate
        **/
        public double[] GeodeticToGeocentric(double[] gd)
        {
            var result = this.GeodeticToGeocentric(
               gd[0], gd[1], gd[2]);

            result[0] += this.mapDatum.datumShift[0];
            result[1] += this.mapDatum.datumShift[1];
            result[2] += this.mapDatum.datumShift[2];

            return result;
        }
    }
    private void Start()
    {
        ReferenceEllipsoid globalEllipsoid = new ReferenceEllipsoid(new MapDatum(new Spheroid(equatorial_radius_WGS84, 6356752.3142), 0, 0, 0));
        //double[] result = globalEllipsoid.GeocentricToGeodetic(6378142.280279575, 197.3272406091594, -28.88229504160358);
        double[] result = globalEllipsoid.GeocentricToGeodetic(6378143.312467767 - equatorial_radius_WGS84, 160.9249286031395, 29.28107983863833);
        //Debug.Log("x: " + result[0] + " | y: " + result[1] + " | z: " + result[2]);
    }
}
