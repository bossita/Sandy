﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ResourcesPaths
{
    // prefabs should be under "...Resources/Prefabs"
    private const string PREFABS_PATH = "Prefabs";

    public const string SOLDIER_PREFAB = "Soldier";
    public const string DETONATION_PREFAB = "Explosion3D_10";

    public const string AMBULANCE_PREFAB = "Ambulance Parent";
    public const string BUS_PREFAB = "Bus Parent";
    public const string HUMVEE_PREFAB = "Humvee Parent";
    public const string CIVILIAN_MALE_PREFAB = "Arab Man";
    public const string CIVILIAN_FEMALE_PREFAB = "Arab Woman";
    public const string SQUAD = "Squad";
    public const string CROWD = "Crowd";


    public static readonly string[] DETONATIONS_LIST = {
        "Explosion3D_1",
        "Explosion3D_2",
        "Explosion3D_3",
        "Explosion3D_4",
        "Explosion3D_5",
        "Explosion3D_6",
        "Explosion3D_7",
        "Explosion3D_8",
        "Explosion3D_9",
        "Explosion3D_10",
        "Explosion3D_11",
        "Explosion3D_12",
        "Explosion3D_13",
    };


    /// <summary>
    /// Generate the full path for a prefab using the function Resources.Load/s.
    /// </summary>
    /// <param name="prefab">Prefab string path.</param>
    /// <returns>The full path for a prefab.</returns>
    public static string GetPrefabResourcePath(string prefab)
    {
        return string.Join("/", PREFABS_PATH, prefab);
    }
}