﻿
using System.Collections.Generic;
using System.Linq;
using System;

public static class ModelsEntityTypesDIS
{   
    public static Dictionary<int[], string> EntityTypesDISToModels = new Dictionary<int[], string>(ModelsEntityTypesDISComparer.comparer)
    {
        { new int[] { 1, 1, 225, 84, 1, 1, 3 } , ResourcesPaths.AMBULANCE_PREFAB},
        { new int[] { 1, 1, 225, 82, 0, 0, 0 } , ResourcesPaths.BUS_PREFAB},
        { new int[] { 1, 1, 225, 6, 1, 1, 0 } , ResourcesPaths.HUMVEE_PREFAB},
        { new int[] { 3, 1, 225, 3, 0, 1, 0 } , ResourcesPaths.CIVILIAN_MALE_PREFAB},
        { new int[] { 3, 1, 225, 3, 1, 1, 0 } , ResourcesPaths.CIVILIAN_FEMALE_PREFAB},
        { new int[] { 3, 1, 105, 1, 0, 0, 0 } , ResourcesPaths.SOLDIER_PREFAB},
        { new int[] { 11, 1, 225, 12, 3, 0, 3 } , ResourcesPaths.SQUAD},
        { new int[] { 11, 1, 0, 0, 34, 0, 1 } , ResourcesPaths.CROWD},
    };

    public static bool GetRandomPrefabNumber(string model, out int prefabNum)
    {
        prefabNum = ModelsToPrefabCount[model];
        if (prefabNum == 0)
        {
            return false;
        }
        else
        {
            prefabNum = UnityEngine.Random.Range(0, prefabNum);
        }
        return true;
    }
    public static float GetAnimatorSpeed(string model)
    {
        try
        {
            string modelName = model;
            foreach (var pair in ModelsToAnimatorSpeed)
            {
                if (modelName.Contains(pair.Key))
                {
                    {
                        return pair.Value;
                    }
                }
            }
        }
        catch
        {
            UnityEngine.Debug.Log(model);
        }
        return 1;
    }
    private static Dictionary<string, int> ModelsToPrefabCount = new Dictionary< string, int>()
    {
        { ResourcesPaths.AMBULANCE_PREFAB,0},
        { ResourcesPaths.BUS_PREFAB,0},
        { ResourcesPaths.HUMVEE_PREFAB,0},
        { ResourcesPaths.CIVILIAN_MALE_PREFAB,5},
        { ResourcesPaths.CIVILIAN_FEMALE_PREFAB,3},
        { ResourcesPaths.SOLDIER_PREFAB,0},
        { ResourcesPaths.SQUAD,0},
        { ResourcesPaths.CROWD,0},
    };
    private static Dictionary<string, float> ModelsToAnimatorSpeed = new Dictionary<string, float>()
    {
        { ResourcesPaths.AMBULANCE_PREFAB,1},
        { ResourcesPaths.BUS_PREFAB,1},
        { ResourcesPaths.HUMVEE_PREFAB,1},
        { ResourcesPaths.CIVILIAN_MALE_PREFAB,0.5f},
        { ResourcesPaths.CIVILIAN_FEMALE_PREFAB,0.5f},
        { ResourcesPaths.SOLDIER_PREFAB,1},
        { ResourcesPaths.SQUAD,1},
        { ResourcesPaths.CROWD,1},
    };

    public static Dictionary<int[], Tuple<IAnimation,IAnimationState>> EntityTypesDISToInterfaces = new Dictionary<int[], Tuple<IAnimation,IAnimationState>>(ModelsEntityTypesDISComparer.comparer)
    {
        //{ new int[] { 1, 1, 225, 84, 1, 1, 3 } , ResourcesPaths.AMBULANCE_PREFAB},
        //{ new int[] { 1, 1, 225, 82, 0, 0, 0 } , ResourcesPaths.BUS_PREFAB},
        //{ new int[] { 1, 1, 225, 6, 1, 1, 0 } , ResourcesPaths.HUMVEE_PREFAB},
        { new int[] { 3, 1, 225, 3, 0, 1, 0 } , new Tuple<IAnimation,IAnimationState>(new MaleCivAnimation(),new MaleCivState())},
        { new int[] { 3, 1, 225, 3, 1, 1, 0 } , new Tuple<IAnimation,IAnimationState>(new FemaleCivAnimation(),new FemaleCivState())},
        { new int[] { 3, 1, 105, 1, 0, 0, 0 } , new Tuple<IAnimation,IAnimationState>(new SoldierAnimation(),new SoldierState())},
        //{ new int[] { 11, 1, 225, 12, 3, 0, 3 } , ResourcesPaths.SQUAD},
        //{ new int[] { 11, 1, 0, 0, 34, 0, 1 } , ResourcesPaths.CROWD},
    };
}

public class ModelsEntityTypesDISComparer : IEqualityComparer<int[]>
{
    public static readonly ModelsEntityTypesDISComparer comparer = new ModelsEntityTypesDISComparer();

    public bool Equals(int[] x, int[] y)
    {
        return x.SequenceEqual(y);
    }

    public int GetHashCode(int[] obj)
    {
        int result = 17;
        for (int i = 0; i < obj.Length; i++)
        {
            unchecked
            {
                result = (result * 23) + obj[i];
            }
        }
        return result;
    }
}