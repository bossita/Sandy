﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FaceCamera : MonoBehaviour
{
    private Camera MainCamera;
    private readonly Vector3 mirrorVector = new Vector3(0f, 180f, 0f);

    void Start()
    {
        MainCamera = Camera.main;
    }

    void Update()
    {
        this.transform.LookAt(MainCamera.transform);
        this.transform.Rotate(mirrorVector);
    }
}
