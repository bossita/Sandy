﻿using Assets.Game._Scripts.Helpers;
using UnityEngine;
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using TMPro;

public class HiderOfUnwatedPartsInMap : MonoBehaviour
{
    private const string NAME_OF_THE_LIST_POINTS_IN_SHADER = "_listOfVisibleAreaPoints";

    [SerializeField]
    public BoxCollider tablesCollider;

    [SerializeField]
    public GameObject MapHolder;
    // might use later if all objects share the same material
    //[SerializeField]
    //public Renderer mapPartTemplate;

    [SerializeField]
    public Shader invisibiltyForOutOfRangeMap;

    //[SerializeField]
    //public List<Renderer> textsToChange;

    //[SerializeField]
    //public Shader invisibilityToTexts;

    private Vector3[] verticesDirectionsFromCenterOfTable;
    private Vector4[] positionOfTablePoints;
    private Vector3 previousPositionOfMap;

    public void Start()
    {
        BOX_COLLIDER_VERTICES.VertexKey[] topVertices = BOX_COLLIDER_VERTICES.TopVerticesOfBoxCollider();

        verticesDirectionsFromCenterOfTable = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(tablesCollider, topVertices);
        positionOfTablePoints = new Vector4[topVertices.Length];
        InitializeVerticesPosition();
        //foreach(Vector3 vertex in positionOfTablePoints)
        //{
        //    Debug.DrawRay(vertex, Vector3.up * 100, Color.cyan, 10f);
        //}
        //foreach (Renderer r in textsToChange)
        //{
        //    Material[] arrayOfMaterialsForRenderer = r.sharedMaterials;
        //    for (int indexMaterial = 0; indexMaterial < arrayOfMaterialsForRenderer.Length; indexMaterial++)
        //    {
        //        Material currentMat = arrayOfMaterialsForRenderer[indexMaterial];
        //        Debug.Log(r.name);
        //        Debug.Log(currentMat);
        //        if (currentMat != null)
        //        {
        //            currentMat.shader = invisibilityToTexts;
        //            currentMat.SetVectorArray(NAME_OF_THE_LIST_POINTS_IN_SHADER, positionOfTablePoints);
        //        }
        //        else
        //        {
        //            Debug.LogWarning("material is null :(");
        //        }
        //    }
        //}
        AssignPartialInvisiblityShaderToMapParts();
        previousPositionOfMap = tablesCollider.transform.position;
    }
    private void Update()
    {
        HandleTableMovement();
    }
    private void HandleTableMovement()
    {
        Vector3 currentMapPosition = tablesCollider.transform.position;
        if (previousPositionOfMap != currentMapPosition)
        {
            previousPositionOfMap = currentMapPosition;
            InitializeVerticesPosition();
            AssignPartialInvisiblityShaderToMapParts();
        }
    }
    public void AssignPartialInvisiblityShaderToMapParts()
    {
        //mapPartTemplate.material.SetVectorArray(NAME_OF_THE_LIST_POINTS_IN_SHADER, positionOfTablePoints);
        Renderer[] allMapRendererObjects = MapHolder.GetComponentsInChildren<Renderer>();
        foreach (Renderer objectRenderer in allMapRendererObjects)
        {
            ApplyInvisibilityAccountabilityToObject(objectRenderer);
        }
    }
    public bool ShouldntAssignTransparecyTo(Renderer renderer)
    {
        return renderer.GetComponent<TextMeshPro>() != null || renderer.GetComponent<TMP_SubMesh>() != null;
    }
    public void ApplyInvisibilityAccountabilityToObject(Renderer renderer)
    {
        if(ShouldntAssignTransparecyTo(renderer))
        {
            return;
        }
        Material[] arrayOfMaterialsForRenderer = renderer.sharedMaterials;
        for (int indexMaterial = 0; indexMaterial < arrayOfMaterialsForRenderer.Length; indexMaterial++)
        {
            Material currentMat = arrayOfMaterialsForRenderer[indexMaterial];
            if (currentMat != null)
            {
                
                currentMat.shader = invisibiltyForOutOfRangeMap;
                currentMat.SetVectorArray(NAME_OF_THE_LIST_POINTS_IN_SHADER, positionOfTablePoints);
            }
            //else
            //{
            //    Debug.LogWarning("material is null :(");
            //}
        }
    }
    public void InitializeVerticesPosition()
    {
        Vector3[] verticesPositionOfTable = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirectionsFromCenterOfTable, tablesCollider);
        for(int indexPosition = 0; indexPosition < verticesPositionOfTable.Length;indexPosition++)
        {
            positionOfTablePoints[indexPosition] = new Vector4(verticesPositionOfTable[indexPosition].x, verticesPositionOfTable[indexPosition].z);
        }
    }
}
