﻿using Assets.Game._Scripts.Helpers;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AdjustMapCharacteristics : MonoBehaviour
{
    private Transform mapTransform;

    struct MinMaxValues
    {
        public float minValue;
        public float maxValue;
    }

    private MinMaxValues xRangeValues;
    private MinMaxValues zRangeValues;
    private MinMaxValues yRangeValues;

    // the function has to be on awake, because the map transformation components are being applied on the start function.
    private void Awake()
    {
        mapTransform = this.transform.parent;
        FindMinAndMaxBoxColliderRange();
        #region draw lines of boxCollider points
        //Debug.DrawRay(new Vector3(xRangeValues.minValue, yRangeValues.minValue, zRangeValues.minValue),
        //                                                                Vector3.up * 100f, Color.red, 10f);
        //Debug.DrawRay(new Vector3(xRangeValues.minValue, yRangeValues.minValue, zRangeValues.maxValue),
        //                                                                Vector3.up * 100f, Color.red, 10f);
        //Debug.DrawRay(new Vector3(xRangeValues.maxValue, yRangeValues.minValue, zRangeValues.minValue),
        //                                                                Vector3.up * 100f, Color.red, 10f);
        //Debug.DrawRay(new Vector3(xRangeValues.maxValue, yRangeValues.minValue, zRangeValues.maxValue),
        //                                                                Vector3.up * 100f, Color.red, 10f);
        #endregion
        AssignNewMapBoxCollider();
        #region changing the collider of parent without creating new object (currently not being used)
        //BoxCollider boxColliderOfParent = FindOrCreateBoxCollider(mapTransform.gameObject);
        //Vector3 middlePos = new Vector3((xRangeValues.maxValue + xRangeValues.minValue),
        //                                (yRangeValues.maxValue + yRangeValues.minValue),
        //                                (zRangeValues.maxValue + zRangeValues.minValue)) / 2.0f;
        //Vector3 newCenter = (middlePos - mapTransform.position);
        //Vector3 reversedScale = new Vector3((1 / boxColliderOfParent.transform.lossyScale.x),
        //                                    (1 / boxColliderOfParent.transform.lossyScale.y),
        //                                    (1 / boxColliderOfParent.transform.lossyScale.z));
        //newCenter.Scale(reversedScale);
        //boxColliderOfParent.center = newCenter;

        //Vector3 sizeVector = new Vector3((xRangeValues.maxValue - xRangeValues.minValue),
        //                                 (yRangeValues.maxValue - yRangeValues.minValue),
        //                                 (zRangeValues.maxValue - zRangeValues.minValue));
        //sizeVector.Scale(reversedScale);
        //boxColliderOfParent.size = sizeVector;
        //#region drawing boxCollider diagonal lines
        //Debug.DrawLine(
        //    new Vector3(xRangeValues.minValue, yRangeValues.minValue, zRangeValues.minValue),
        //    new Vector3(xRangeValues.maxValue, yRangeValues.maxValue, zRangeValues.maxValue),
        //    Color.yellow,
        //    10f);
        //Debug.DrawLine(
        //    new Vector3(xRangeValues.minValue, yRangeValues.minValue, zRangeValues.maxValue),
        //    new Vector3(xRangeValues.maxValue, yRangeValues.maxValue, zRangeValues.minValue),
        //    Color.blue,
        //    10f);
        //#endregion
        //newObjectHolder = new GameObject();
        //Transform newTransformHolder = newObjectHolder.transform;
        //newTransformHolder.position = new Vector3(middlePos.x, yRangeValues.minValue, middlePos.z);
        #endregion
    }
    private void AssignNewMapBoxCollider()
    {
        BoxCollider boxColliderOfNewParent = FindOrCreateComponents.Component<BoxCollider>(mapTransform.gameObject);

        Vector3 reversedScale = new Vector3((1 / mapTransform.lossyScale.x),
                                            (1 / mapTransform.lossyScale.y),
                                            (1 / mapTransform.lossyScale.z));

        Vector3 middlePos = new Vector3((xRangeValues.maxValue + xRangeValues.minValue),
                                        (yRangeValues.maxValue + yRangeValues.minValue),
                                        (zRangeValues.maxValue + zRangeValues.minValue)) / 2.0f;
        Debug.Log(middlePos);
        Vector3 newCenter = mapTransform.TransformDirection(middlePos - mapTransform.position);
        newCenter.Scale(reversedScale);
        boxColliderOfNewParent.center = newCenter;
        Debug.Log(boxColliderOfNewParent.center);
        Vector3 sizeVector = new Vector3((xRangeValues.maxValue - xRangeValues.minValue),
                                            (yRangeValues.maxValue - yRangeValues.minValue),
                                            (zRangeValues.maxValue - zRangeValues.minValue));
        // the new object could have scale different than default(1,1,1) thus the size of the sizeVector
        // should be scaled by the inverse scale ( (1 / scale.x, 1 / scale.y, 1/scale.z) )
        sizeVector.Scale(reversedScale);
        boxColliderOfNewParent.size = sizeVector;
    }
    private void FindMinAndMaxBoxColliderRange()
    {
        Renderer[] allRenderedObjects = this.mapTransform.GetComponentsInChildren<Renderer>();
        int indexCollider = 0;
        foreach (Renderer renderer in allRenderedObjects)
        {
            BoxCollider boxCollider = FindOrCreateComponents.Component<BoxCollider>(renderer.gameObject);

            Vector3[] verticesDirection = BOX_COLLIDER_VERTICES.VerticiesDirectionsFromCenterOfBoxCollider(boxCollider);
            Vector3[] verticesPositions = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirection, boxCollider);
            if (indexCollider == 0)
            {
                InitializeMinMaxValues(verticesPositions[0]);
            }
            AdjustMinMaxValues(verticesPositions);
            indexCollider++;
            Destroy(boxCollider);
        }
    }
    private void InitializeMinMaxValues(Vector3 vertexToInitializeFrom)
    {
        xRangeValues.minValue = vertexToInitializeFrom.x;
        xRangeValues.maxValue = vertexToInitializeFrom.x;
        zRangeValues.minValue = vertexToInitializeFrom.z;
        zRangeValues.maxValue = vertexToInitializeFrom.z;
        yRangeValues.minValue = vertexToInitializeFrom.y;
        yRangeValues.maxValue = vertexToInitializeFrom.y;
    }
    private void AdjustByRefference(float vectorComponentValue, ref MinMaxValues minMaxComponentRange)
    {
        if (vectorComponentValue < minMaxComponentRange.minValue)
        {
            minMaxComponentRange.minValue = vectorComponentValue;
        }
        else if (vectorComponentValue > minMaxComponentRange.maxValue)
        {
            minMaxComponentRange.maxValue = vectorComponentValue;
        }
    }
    private void AdjustMinMaxValues(Vector3[] vertices)
    {
        foreach(Vector3 vertex in vertices)
        {
            AdjustByRefference(vertex.x, ref xRangeValues);
            AdjustByRefference(vertex.z, ref zRangeValues);
            AdjustByRefference(vertex.y, ref yRangeValues);
        }
    }
}
