﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AdjustHandActionIcons : MonoBehaviour
{
    private Camera cameraBeingUsed;

    [SerializeField]
    public Sprite MapMovementSprite;

    [SerializeField]
    public Sprite MapScalingSprite;

    [SerializeField]
    public Image imageAction;

    void Start()
    {
        cameraBeingUsed = Camera.main;
        DisableIcon();
    }

    public void EnableMapMovementIcon()
    {
        imageAction.enabled = true;
        imageAction.sprite  = MapMovementSprite;
    }

    public void EnableMapZoomingIcon()
    {
        imageAction.enabled = true;
        imageAction.sprite  = MapScalingSprite;
    }

    public void DisableIcon()
    {
        imageAction.enabled = false;
    }

    void Update()
    {
        transform.LookAt(transform.position + cameraBeingUsed.transform.rotation * Vector3.forward, cameraBeingUsed.transform.rotation * Vector3.up);
    }
}
