﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LayersOfDataHandler : MonoBehaviour
{
    [SerializeField]
    public List<GameObject> informationDetailHolders;

    private bool inMiddleOfAdding;
    private bool inMiddleOfRemoving;

    private Stack<GameObject> visibilityStack;
    private Stack<GameObject> invisibilityStack;

    private bool DidAddDataToLayer()
    {
        return ControllerInputsHolder.LBButtonPush();
    }
    public bool DidRemoveDataToLayer()
    {
        return ControllerInputsHolder.RBButtonPush();
    }

    private void Start()
    {
        inMiddleOfAdding   = false;
        inMiddleOfRemoving = false;
        visibilityStack    = new Stack<GameObject>();
        invisibilityStack  = new Stack<GameObject>();
        PopulateStack(visibilityStack, informationDetailHolders);
    }
    private void PopulateStack(Stack<GameObject> stackToPopulate, List<GameObject> data)
    {
        data.ForEach((obj) => stackToPopulate.Push(obj));        
    }
    private void CheckForLayersChange()
    {
        bool buttonPushRegistered = DidAddDataToLayer();
        if(LayerChangeRegitered(buttonPushRegistered, ref inMiddleOfAdding))
        {
            GameObject objectMoved = MoveFromStackToStack(invisibilityStack, visibilityStack);
            AssignVisibilityIfPossible(objectMoved, false);
            Debug.Log(visibilityStack.Count + " " + invisibilityStack.Count);
        }
        buttonPushRegistered = DidRemoveDataToLayer();
        if(LayerChangeRegitered(buttonPushRegistered, ref inMiddleOfRemoving))
        {
            GameObject objectMoved = MoveFromStackToStack(visibilityStack, invisibilityStack);
            AssignVisibilityIfPossible(objectMoved, true);
            Debug.Log(visibilityStack.Count + " " + invisibilityStack.Count);
        }
    }

    private void AssignVisibilityIfPossible(GameObject objectToAssign, bool visibilityState)
    {
        if(objectToAssign != null)
        {
            objectToAssign.SetActive(visibilityState);
        }
    }
    private GameObject MoveFromStackToStack(Stack<GameObject> stackToMoveFrom, Stack<GameObject> stackToMoveTo)
    {
        GameObject topObject = null;
        try
        {
            topObject = stackToMoveFrom.Pop();
            stackToMoveTo.Push(topObject);
        }
        catch(InvalidOperationException)
        {
        }
        return topObject;
    }
    private bool LayerChangeRegitered(bool inputRegitered, ref bool inMiddleOfAction)
    {
        bool inputRegiteredNow = false;
        if (!inMiddleOfAction && inputRegitered)
        {
            inMiddleOfAction = true;
            inputRegiteredNow = true;
        }
        else if (!inputRegitered)
        {
            inMiddleOfAction = false;
        }
        return inputRegiteredNow;
    }
    void Update()
    {
        CheckForLayersChange();
    }
}
