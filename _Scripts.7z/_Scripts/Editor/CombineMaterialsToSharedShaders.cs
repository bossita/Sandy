﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

// this class doesnt work on objects whom have more than one material or have no _MainTexture
public class CombineMaterialsToSharedShaders : MonoBehaviour
{
    void Start()
    {
        MaterialPropertyBlock materialPropertyBlock = new MaterialPropertyBlock();
        MeshRenderer[] meshRenderers = transform.GetComponentsInChildren<MeshRenderer>();
        Dictionary<Shader, Material> sharedMaterialOfSameShader = new Dictionary<Shader, Material>();
        foreach (MeshRenderer currentMeshRenderer in meshRenderers)
        {
            Material[] materials = currentMeshRenderer.sharedMaterials;
            for (int indexMat = 0; indexMat < materials.Length; indexMat++)
            {
                Material matUsed = materials[indexMat];
                Shader shaderBeingUsed = matUsed.shader;
                Material sharedMaterialForCurrentShader;
                if (!sharedMaterialOfSameShader.TryGetValue(shaderBeingUsed, out sharedMaterialForCurrentShader))
                {
                    sharedMaterialForCurrentShader = matUsed;
                    sharedMaterialOfSameShader.Add(shaderBeingUsed, matUsed);
                }
                currentMeshRenderer.sharedMaterial = sharedMaterialForCurrentShader;
                ShaderDataFromMaterial(matUsed, indexMat, currentMeshRenderer, materialPropertyBlock);
            }
        }
    }
    private ShaderDataHolder AssignShaderDataFromPreviousMat(Material materialToExtractFrom)
    {
        Shader currentShader = materialToExtractFrom.shader;
        int numberOfProperties = ShaderUtil.GetPropertyCount(currentShader);
        ShaderDataHolder shaderData = new ShaderDataHolder(materialToExtractFrom);
        for (int indexShaderProperty = 0; indexShaderProperty < numberOfProperties; indexShaderProperty++)
        {
            AddPropertyDependingOnType(shaderData, materialToExtractFrom, indexShaderProperty);
        }
        return shaderData;
    }
    private void ShaderDataFromMaterial(Material materialToExtractFrom, int indexMat, MeshRenderer meshToAssignTo, MaterialPropertyBlock propertyBlock)
    {
        propertyBlock.Clear();
        Shader currentShader = materialToExtractFrom.shader;
        int numberOfProperties = ShaderUtil.GetPropertyCount(currentShader);
        for (int indexShaderProperty = 0; indexShaderProperty < numberOfProperties; indexShaderProperty++)
        {
            SetPropertyDependingOnType(propertyBlock, materialToExtractFrom, indexShaderProperty);
        }
        meshToAssignTo.SetPropertyBlock(propertyBlock);
    }
    private void SetPropertyDependingOnType(MaterialPropertyBlock propertyBlock, Material matToExtractFrom, int indexProperty)
    {
        Shader shaderOfMaterial = matToExtractFrom.shader;
        ShaderUtil.ShaderPropertyType shaderPropertyType = ShaderUtil.GetPropertyType(shaderOfMaterial, indexProperty);
        string propertyName = ShaderUtil.GetPropertyName(shaderOfMaterial, indexProperty);
        switch (shaderPropertyType)
        {
            case (ShaderUtil.ShaderPropertyType.Color):
                {
                    Color colorUsed = matToExtractFrom.GetColor(propertyName);
                    propertyBlock.SetColor(propertyName, colorUsed);
                    break;
                }
            case (ShaderUtil.ShaderPropertyType.Float | ShaderUtil.ShaderPropertyType.Range):
                {
                    float floatUsed = matToExtractFrom.GetFloat(propertyName);
                    propertyBlock.SetFloat(propertyName, floatUsed);
                    break;
                }
            case (ShaderUtil.ShaderPropertyType.Vector):
                {
                    break;
                }

            case (ShaderUtil.ShaderPropertyType.TexEnv):
                {
                    Texture textureUsed = matToExtractFrom.GetTexture(propertyName);
                    if (textureUsed != null)
                    {
                        propertyBlock.SetTexture(propertyName, textureUsed);
                    }
                    break;
                }
        }
    }
    private void AssignMaterialPropertyBlockByShaderData(MeshRenderer meshRendererToAssignTo, int indexMaterial, MaterialPropertyBlock materialPropertyBlock, ShaderDataHolder dataToTransfer)
    {
        materialPropertyBlock.Clear();
        foreach (ColorProperty colorProp in dataToTransfer.ColorsProperties)
        {
            materialPropertyBlock.SetColor(colorProp.colorName, colorProp.colorVariable);
        }
        foreach (TextureProperty textureProp in dataToTransfer.TextureProperties)
        {
            if (textureProp.textureVariable != null)
            {
                materialPropertyBlock.SetTexture(textureProp.textureName, textureProp.textureVariable);
            }
        }
        foreach (FloatProperty floatProp in dataToTransfer.FloatsProperties)
        {
            materialPropertyBlock.SetFloat(floatProp.floatName, floatProp.floatVariable);
        }
        meshRendererToAssignTo.SetPropertyBlock(materialPropertyBlock, indexMaterial);
    }
    private void AddPropertyDependingOnType(ShaderDataHolder shaderData, Material materialUsed, int indexProperty)
    {
        Shader shaderOfMaterial = materialUsed.shader;
        ShaderUtil.ShaderPropertyType shaderPropertyType = ShaderUtil.GetPropertyType(shaderOfMaterial, indexProperty);
        string propertyName = ShaderUtil.GetPropertyName(shaderOfMaterial, indexProperty);
        switch (shaderPropertyType)
        {
            case (ShaderUtil.ShaderPropertyType.Color):
                {
                    Color colorUsed = materialUsed.GetColor(propertyName);
                    shaderData.AddColorProperty(propertyName, colorUsed);
                    break;
                }
            case (ShaderUtil.ShaderPropertyType.Float | ShaderUtil.ShaderPropertyType.Range):
                {
                    float floatUsed = materialUsed.GetFloat(propertyName);
                    shaderData.AddFloatProperty(propertyName, floatUsed);
                    break;
                }
            case (ShaderUtil.ShaderPropertyType.Vector):
                {
                    break;
                }

            case (ShaderUtil.ShaderPropertyType.TexEnv):
                {
                    Texture textureUsed = materialUsed.GetTexture(propertyName);
                    shaderData.AddTextureProperty(propertyName, textureUsed);
                    break;
                }
        }
    }
}
