﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraCullingMask : MonoBehaviour
{
    // Turn on the bit using an OR operation:
    public static void Show(Camera camera, string layer)
    {
        camera.cullingMask |= 1 << LayerMask.NameToLayer(layer);
    }

    // Turn off the bit using an AND operation with the complement of the shifted int:
    public static void Hide(Camera camera, string layer)
    {
        camera.cullingMask &= ~(1 << LayerMask.NameToLayer(layer));
    }
}
