﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ClosestTest : MonoBehaviour
{
    public GameObject sourceObject;
    public Collider targetCollider;
    public GameObject textMeshPro;
    public float minDistance = 250;
    bool wasVisiable = true;
    Camera mainCamera;

    // Start is called before the first frame update
    void Start()
    {
        Vector3 closestPoint = targetCollider.ClosestPoint(sourceObject.transform.position);
        textMeshPro.transform.position = closestPoint;
        mainCamera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 closestPoint = targetCollider.ClosestPoint(sourceObject.transform.position);
        float distance = Vector3.Distance(sourceObject.transform.position, closestPoint);
        if (distance > minDistance)
        {
            textMeshPro.transform.position = closestPoint;
            textMeshPro.GetComponent<TextMeshPro>().text = "Distance: " + distance.ToString();
            if(wasVisiable==false)
            {
                CameraCullingMask.Show(mainCamera,LayerMask.LayerToName(textMeshPro.layer));
                wasVisiable = true;
            }
        }
        else
        {
            if(wasVisiable==true)
            {

                CameraCullingMask.Hide(mainCamera, LayerMask.LayerToName(textMeshPro.layer));
                wasVisiable = false;
            }
        }
    }
}
