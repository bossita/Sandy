﻿using System.Collections.Concurrent;
using UnityEngine;
using WebSocketSharp;
using System;
using Newtonsoft.Json;
using System.Collections.Generic;

public class WebLVCServerConnection : MonoBehaviour
{
    /// <summary>
    /// default WebSocket-Echo-Server for testing. (ws://echo.websocket.org)
    /// </summary>
    private const string DefaultEchoServer = "ws://echo.websocket.org";

    private const float WebLVCVersion = 1.4f;

    /// <summary>
    /// The WebSocket Connection.
    /// </summary>
    private WebSocket ws;

    /// <summary>
    /// Connection string for WebSocket.
    /// WebLVC Server should be in the format: "ws://<ip>:<port>/ws"
    /// * the 'ws' in the end is not a mistake.
    /// </summary>
    public string ConnectionString;

    /// <summary>
    /// Message queue for WebLVC messages.
    /// </summary>
    public ConcurrentQueue<WebLVCMessage> messagesQueue;
    private string userName = string.Empty;

    #region Refresh
    /// <summary>
    /// Last time the WebLVC server was requested by the client, using a refresh message.
    /// </summary>
    private float lastTimeRefreshedServer = 0;
    private readonly WebLVCMessage refreshMessage = new WebLVCMessage() { MessageKind = WebLVCMessageKind.Refresh };
    static Array array = Array.CreateInstance(typeof(double),3);
    private readonly WebLVCMessage createMessage = new MakVrfCreateObject()
    {
        MessageKind = WebLVCMessageKind.Interaction,
        InteractionType = "MAK:VrfCreateObject",
        Address = new int[2] { 1, 3001 },
        Name = "MyObject",
        ObjectType = new int[] { 3, 1, 105, 1, 0, 0, 0 },
        ForceType = Force.Friendly,
        Label = "CreatedEntities",
        Heading = 0,
        Vertices = new Array[3] 
        {
            array,
            array,
            array,
        }
        ,
        ClampToGround = false,
        ClosedFigure = false,
        CreateSubObjects = false,
        Projection = false,
    };
    private readonly WebLVCMessage SetMessage = new MakVrfSet()
    {
        MessageKind = WebLVCMessageKind.Interaction,
        InteractionType = "MAK:VrfSet",
        ReceivingApplicationName = "MyObject",
        DataVariables = new DataVariable[1]
        {
            new DataVariable()
            {
                type="LocationWithAltitude",
                name="Location",
                value=new double[3]
                {
                    6378137,1,2
                },
            }
        }
    };
    private WebLVCMessage ConnectMessage;

    private string serializedRefreshMessage = null;
    private string serializedCreateMessage = null;
    private string serializedSetMessage = null;
    private string serializedConnectMessage = null;
    #endregion

    private long MessagesPerSecond = 0;
    private long ParsedMessagedPerSecond = 0;

    private float lastTimeUpdated = 0;

    private void InitializeServerSafe()
    {
        if (System.IO.File.Exists(InputManager.path))
        {
            string Port = string.Empty;
            string IP = string.Empty;
            string[] lines = System.IO.File.ReadAllLines(InputManager.path);
            foreach (string line in lines)
            {
                string[] pair = line.Split(':');
                if (pair[0] == "Port")
                {
                    Port = pair[1];
                    continue;
                }
                if (pair[0] == "IP")
                {
                    IP = pair[1];
                    continue;
                }
                if (pair[0] == "UserName")
                {
                    userName = pair[1];
                    continue;
                }
            }
            if (IP != string.Empty && Port != string.Empty)
            {
                //"ws://<ip>:<port>/ws"
                ConnectionString = string.Format("ws://{0}:{1}/ws", IP, Port);
            }
        }
        ConnectMessage = new ConnectMessage()
        {
            MessageKind = WebLVCMessageKind.Connect,
            ClientName = userName,
            WebLVCVersion = WebLVCVersion,
        };
    
        if (this.ws == null)
        {
            if (this.ConnectionString.IsNullOrEmpty())
            {
                this.ConnectionString = DefaultEchoServer;
                Debug.LogWarningFormat("[WARNING] not valid connection string - connecting to default echo server: {0}", DefaultEchoServer);
            }

            this.ws = new WebSocket(this.ConnectionString);
        }

        this.messagesQueue = new ConcurrentQueue<WebLVCMessage>();
        this.InitializeServerEvents();
        this.ws.Connect();
    }

    private void InitializeServerEvents()
    {
        this.ws.OnOpen += (sender, e) =>
        {   
            Debug.LogFormat("[OPEN] WebLVC connection {0} opened", this.ConnectionString);
        };
        this.ws.OnClose += (sender, e) =>
        {
            Debug.LogFormat("[CLOSED] WebLVC connection {0} closed", this.ConnectionString);
        };

        this.ws.OnMessage += (sender, e) =>
        {
            MessagesPerSecond++;
            string message = e.Data;
            if(message.Contains("VrfTextReport"))
            {
                Debug.Log("a MAK: VrfTextReport message has been sent");
            }
            WebLVCMessage webLVCMessage = this.ParseMessage(message);
            if (webLVCMessage != null)
            {
                this.messagesQueue.Enqueue(webLVCMessage);
                ParsedMessagedPerSecond++;
            }
            
            //Debug.LogFormat("[RECEIVED] WebLVC connection {0} received message: {1}", this.ConnectionString, e.Data);
        };

        this.ws.OnError += (sender, e) =>
        {
            bool isCausedByException = e.Exception != null && e.Exception is System.Exception;
            if (!isCausedByException)
            {
                Debug.LogErrorFormat("[ERROR] WebLVC connection {0} is in an ERROR state.\n\nError Message: {1}", this.ConnectionString, e.Message);
            }
            else
            {
                Debug.LogErrorFormat("[ERROR] WebLVC connection {0} is in an ERROR state.\n\nError Message: {1}\n\nCaused By Exception: {2}", this.ConnectionString, e.Message, e.Exception);
            }
        };
    }

    private void CloseServerSafe()
    {
        this.ws.Close();
        Debug.LogFormat("[CLOSED] WebLVC connection {0} closed", this.ConnectionString);

        this.ClearMessageQueue();
    }

    // Start is called before the first frame update
    void Start()
    {
        serializedRefreshMessage = JsonConvert.SerializeObject(refreshMessage);
        serializedCreateMessage = JsonConvert.SerializeObject(createMessage);
        serializedSetMessage = JsonConvert.SerializeObject(SetMessage);
        serializedConnectMessage = JsonConvert.SerializeObject(ConnectMessage);
        for (int i = 0; i < array.Length; i++)
        {
            array.SetValue(0, i);
        }
        this.InitializeServerSafe();
        this.ws.Send(this.serializedConnectMessage);
    }

    private WebLVCMessage ParseMessage(string message)
    {
        WebLVCMessage webLVCMessage = null;
        try
        {
            webLVCMessage = JsonConvert.DeserializeObject<WebLVCMessage>(message)?.ParseAll(message);
        }
        catch (Exception e)
        {
            //Debug.LogWarningFormat("[UNPARSABLE] Unparsable Message: {0}\nException Information: {1}", message, e);
            webLVCMessage = null;
        }

        return webLVCMessage;

        //#region use this after everything is implemented
        ////if (!(webLVCMessage is IChildMessage))
        ////{
        ////    Debug.LogError("something went wrong");
        ////}
        ////(webLVCMessage as IChildMessage).HandleMessage(message);
        //#endregion

        //#region temporary test
        //if (webLVCMessage as WebLVCPhysicalEntityMessage == null)
        //{
        //    //Debug.LogWarning("Something went wrong");
        //    return;
        //}

        //(webLVCMessage as WebLVCPhysicalEntityMessage).HandleMessage();
        //#endregion
    }

    // Update is called once per frame
    private void Update()
    {
        #region messages rate
        if (lastTimeUpdated + 1 < Time.realtimeSinceStartup)
        {
            Debug.LogFormat("Messages per second: {0}\t|\tParsed messages per second: {1}\t|\tQueue Size: {2}", MessagesPerSecond, ParsedMessagedPerSecond ,this.messagesQueue.Count);
            MessagesPerSecond = 0;
            ParsedMessagedPerSecond = 0;
            lastTimeUpdated = Time.realtimeSinceStartup;
        }
        #endregion

        #region refresh messages
        //this.ws.Send(serializedRefreshMessage);
        if (lastTimeRefreshedServer + (0.1) < Time.realtimeSinceStartup)
        {
            if (this.ws.ReadyState == WebSocketState.Open)
            {
                this.ws.Send(this.serializedRefreshMessage);
            }

            lastTimeRefreshedServer = Time.realtimeSinceStartup;
        }
        #endregion

        #region send create message
        //if(Input.GetKeyDown(KeyCode.Space))
        //{
        //    Debug.Log("sent a create message");
        //    this.ws.Send(this.serializedCreateMessage);
        //}
        #endregion

        #region send set message
        //if (Input.GetKeyDown(KeyCode.D))
        //{
        //    Debug.Log("sent a set message: "+serializedSetMessage);
        //    this.ws.Send(this.serializedSetMessage);
        //}
        #endregion

        //...

        //var stopwatch = new System.Diagnostics.Stopwatch();
        //stopwatch.Start();

        while (this.messagesQueue.TryDequeue(out WebLVCMessage msg))
        {
            if (msg is WebLVCWeaponFireInteractionMessage)
            {
                Debug.Log("[Weapon Fire Message]");
            }

            (msg as IChildMessage)?.HandleMessage();
        }

        //stopwatch.Stop();
        //Debug.LogFormat("Processing Messages Time: {0} ms", stopwatch.ElapsedMilliseconds);

    }

    void OnEnable()
    {
        this.InitializeServerSafe();
    }

    void OnDisable()
    {
        this.CloseServerSafe();
    }

    void OnDestroy()
    {
        this.CloseServerSafe();
    }

    private void ClearMessageQueue()
    {
        int messagesCount = this.messagesQueue.Count;
        while (!this.messagesQueue.IsEmpty)
        {
            this.messagesQueue.TryDequeue(out WebLVCMessage msg);
        }

        Debug.LogFormat("[QUEUE] Message Queue has been cleared ({0} messages)", messagesCount);
    }
}
