﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAnimationState
{   
    Dictionary<Enum, string> stateToTrigger { get; }
    Dictionary<string, Enum> stateNameToState { get; }
}
