﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponFire
{
    private GameObject entity;
    private GameObject targetEntity;
    private Animator animator;
    private float fireRate = 1;
    private int rounds = 0;
    private static SoldierState soldierState = new SoldierState();
    private static SoldierAnimation soldierAnimation = new SoldierAnimation();

    public WeaponFire(GameObject entity, GameObject targetEntity, float fireRate, int rounds)
    {
        this.fireRate = fireRate;
        this.rounds = rounds;
        this.entity = entity;
        this.targetEntity = targetEntity;
    }

    public void StartShooting(EntityInformation info)
    {
        animator = entity.GetComponent<Animator>();
        entity.transform.LookAt(targetEntity.transform.position);
        if (!soldierAnimation.ChangeState(animator, soldierState, info, "WeaponFire"))
        {
            Debug.LogErrorFormat("Soldier {0} is trying to start shooting even though he can't", entity.name);
        }
    }
    public void StopShooting(EntityInformation info)
    {
        if (!soldierAnimation.ChangeState(animator, soldierState, info, "WeaponFire"))
        {
            Debug.LogErrorFormat("Soldier {0} is trying to Stop shooting even though he can't", entity.name);
        }
    }
}
