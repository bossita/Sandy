﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

public class WebLVCParser
{
    //public static readonly Dictionary<WebLVCMessageKind, IWebLVCStandardMessageParserFactory> Parsers = new Dictionary<WebLVCMessageKind, IWebLVCStandardMessageParserFactory>()
    //{
    //    { WebLVCMessageKind.Any, new WebLVCAnyMessageParser() },
    //    { WebLVCMessageKind.Other, new WebLVCOtherMessageParser() },
    //    { WebLVCMessageKind.AttributeUpdate, new WebLVCAttributeUpdateMessageParser() },
    //    { WebLVCMessageKind.Interaction, new WebLVCInteractionMessageParser() },
    //    { WebLVCMessageKind.Connect, new WebLVCConnectMessageParser() },
    //    { WebLVCMessageKind.ObjectDeletion, new WebLVCObjectDeletionMessageParser() },
    //};

    //public static WebLVCMessage ParseMessage(string message)
    //{
    //    WebLVCMessage webLVCMessage = null;
    //    try
    //    {
    //        webLVCMessage = JsonConvert.DeserializeObject<WebLVCMessage>(message);
    //    }
    //    catch (Exception exception)
    //    {
    //        //TODO: log exception
    //        webLVCMessage = null;
    //        return webLVCMessage;
    //    }

    //    webLVCMessage = Parsers[webLVCMessage.MessageKind]?.Parse(message);
    //    return webLVCMessage;
    //}
}
