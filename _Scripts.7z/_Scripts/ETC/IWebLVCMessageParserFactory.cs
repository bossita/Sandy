﻿
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

interface IWebLVCStandardMessageParserFactory
{
    /// <summary>
    /// Parsing a JSON message to an WebLVC Message.
    /// </summary>
    /// <param name="message">The JSON message to be parsed.</param>
    /// <returns>The De-serialized WebLVC Message.</returns>
    WebLVCMessage Parse(string message);
}

public class WebLVCAttributeUpdateMessageParser : IWebLVCStandardMessageParserFactory
{
    /// <inheritdoc/>
    public WebLVCMessage Parse(string message)
    {
        AttributeUpdateMessage attributeUpdateMessage = JsonConvert.DeserializeObject<AttributeUpdateMessage>(message);
        if (attributeUpdateMessage.ObjectType == null || attributeUpdateMessage.ObjectType == string.Empty)
        {
            // TODO: add log
            return attributeUpdateMessage;
        }

        switch (attributeUpdateMessage.ObjectType)
        {
            case "WebLVC:PhysicalEntity":
                attributeUpdateMessage = JsonConvert.DeserializeObject<WebLVCPhysicalEntityMessage>(message);
                break;
            case "WebLVC:AggregateEntity":
                attributeUpdateMessage = JsonConvert.DeserializeObject<WebLVCAggregateEntityMessage>(message);
                break;
            case "WebLVC:EnvironmentalEntity":
                attributeUpdateMessage = JsonConvert.DeserializeObject<WebLVCEnvironmentalEntityMessage>(message);
                break;
            case "WebLVC:RadioTransmitter":
                attributeUpdateMessage = JsonConvert.DeserializeObject<WebLVCRadioTransmitterMessage>(message);
                break;
            default:
                attributeUpdateMessage = null;
                break;
        }

        return attributeUpdateMessage;
    }
}

public class WebLVCInteractionMessageParser : IWebLVCStandardMessageParserFactory
{
    /// <inheritdoc/>
    public WebLVCMessage Parse(string message)
    {
        InteractionMessage interactionMessage = JsonConvert.DeserializeObject<InteractionMessage>(message);
        if (interactionMessage.InteractionType == null || interactionMessage.InteractionType == string.Empty)
        {
            // TODO: add log
            return interactionMessage;
        }

        switch (interactionMessage.InteractionType)
        {
            case "WebLVC:WeaponFire":
                interactionMessage = JsonConvert.DeserializeObject<WebLVCWeaponFireInteractionMessage>(message);
                break;
            case "WebLVC:MunitionDetonation":
                interactionMessage = JsonConvert.DeserializeObject<WebLVCMunitionDetonationInteractionMessage>(message);
                break;
            case "WebLVC:StartResume":
                interactionMessage = JsonConvert.DeserializeObject<WebLVCStartResumeInteractionMessage>(message);
                break;
            case "WebLVC:StopFreeze":
                interactionMessage = JsonConvert.DeserializeObject<WebLVCStopFreezeInteractionMessage>(message);
                break;
            case "WebLVC:RadioSignal":
                interactionMessage = JsonConvert.DeserializeObject<WebLVCRadioSignalInteractionMessage>(message);
                break;
            default:
                interactionMessage = null;
                break;
        }

        return interactionMessage;
    }
}

public class WebLVCOtherMessageParser : IWebLVCStandardMessageParserFactory
{
    /// <inheritdoc/>
    public WebLVCMessage Parse(string message)
    {
        throw new NotImplementedException();
    }
}

public class WebLVCAnyMessageParser : IWebLVCStandardMessageParserFactory
{
    /// <inheritdoc/>
    public WebLVCMessage Parse(string message)
    {
        throw new NotImplementedException();
    }
}

public class WebLVCConnectMessageParser : IWebLVCStandardMessageParserFactory
{
    /// <inheritdoc/>
    public WebLVCMessage Parse(string message)
    {
        ConnectMessage connectMessage = null;
        connectMessage = JsonConvert.DeserializeObject<ConnectMessage>(message);
        return connectMessage;
    }
}

public class WebLVCObjectDeletionMessageParser : IWebLVCStandardMessageParserFactory
{
    public WebLVCMessage Parse(string message)
    {
        ObjectDeletionMessage connectMessage = null;
        connectMessage = JsonConvert.DeserializeObject<ObjectDeletionMessage>(message);
        return connectMessage;
    }
}

//public class WebLVCBasicMessageFactory
//{
//    private static readonly Dictionary<WebLVCMessageKind, IWebLVCStandardMessageParserFactory> Parsers = new Dictionary<WebLVCMessageKind, IWebLVCStandardMessageParserFactory>()
//    {
//        { WebLVCMessageKind.Any, new WebLVCAnyMessageParser() },
//        { WebLVCMessageKind.Other, new WebLVCOtherMessageParser() },
//        { WebLVCMessageKind.AttributeUpdate, new WebLVCAttributeUpdateMessageParser() },
//        { WebLVCMessageKind.Interaction, new WebLVCInteractionMessageParser() },
//        { WebLVCMessageKind.Connect, new WebLVCConnectMessageParser() },
//        { WebLVCMessageKind.ObjectDeletion, new WebLVCObjectDeletionMessageParser() },
//    };

//    public WebLVCMessage ParseMessage(string message)
//    {
//        WebLVCMessage webLVCMessage = null;
//        try
//        {
//            webLVCMessage = JsonConvert.DeserializeObject<WebLVCMessage>(message);
//        }
//        catch (Exception e)
//        {
//            //TODO: log exception
//            webLVCMessage = null;
//            return webLVCMessage;
//        }

//        webLVCMessage = Parsers[webLVCMessage.MessageKind]?.Parse(message);
//        return webLVCMessage;
//    }
//}
