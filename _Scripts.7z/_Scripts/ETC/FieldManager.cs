﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldManager : MonoBehaviour
{
    public void UpdateField(string value)
    {
        Debug.Log("changed value to: " + value);
        InputManager.UpdateField(this.name, value);
    }
}
