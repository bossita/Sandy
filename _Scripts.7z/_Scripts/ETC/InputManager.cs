﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using UnityEngine.SceneManagement;

public class InputManager : MonoBehaviour
{
    public static string path;
    private const string configurationFilePath = "Configuration.txt";
    private void Start()
    {
        path = Application.dataPath +"/"+ configurationFilePath;
        if(File.Exists(path))
        {
            string[] lines = File.ReadAllLines(path);
            foreach (string line in lines)
            {
                Debug.Log(line);
                string[] fieldValuePair = line.Split(':');
                GameObject.Find(fieldValuePair[0]+ " Input Field").GetComponent<InputField>().text = fieldValuePair[1];
                FieldToValue[fieldValuePair[0]] = fieldValuePair[1];
            }
        }
    }

    private static Dictionary<string, string> FieldToValue = new Dictionary<string, string>()
    {
        {"Port",string.Empty},
        {"IP",string.Empty},
        {"UserName",string.Empty},
    };

    public static void UpdateField(string senderName, string value)
    {
        string field = senderName.Split(' ')[0];
        FieldToValue[field] = value;
        List<string> lines = new List<string>();
        foreach (var pair in FieldToValue)
        {
            lines.Add(pair.Key + ":" + pair.Value);
        }
        File.WriteAllLines(path, lines);
        Debug.Log("created configuration file at path: " + path);
    }

    public void Submit()
    {
        SceneManager.LoadScene("MainScene");
    }
}
