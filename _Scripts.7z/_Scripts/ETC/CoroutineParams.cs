﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeadReckoningCoroutineParams
{
    public EntityInformation info;
    public Vector3d endPosition;
    public Vector3d endRotation;
    public float deltaSeconds;
    public bool isHuman;
}
//public class RotationCoroutineParams
//{   
//    public EntityInformation info;
//    public Vector3d endRotation;
//}
