﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class UIManager : MonoBehaviour
{
    [SerializeField]
    private GameObject terrainsParent;
    private Collider targetCollider = null;
    private Camera mainCamera = null;
    private bool isIcons = false;
    private float lastTimeUpdated = 0;
    public float minDistance = 100f;
    public float timeBetweenRefreshes = 0.1f;

    // Start is called before the first frame update
    void Start()
    {
        lastTimeUpdated = Time.realtimeSinceStartup;
        targetCollider = terrainsParent.GetComponent<Collider>();
        mainCamera = this.GetComponent<Camera>();
        //textMeshPro.transform.position = closestPoint;
        //mainCamera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
    }
    
    void Update()
    {
        if (lastTimeUpdated + timeBetweenRefreshes < Time.realtimeSinceStartup)
        {
            lastTimeUpdated = Time.realtimeSinceStartup;
        }
        else
        {
            return;
        }
        Vector3 closestPoint = targetCollider.ClosestPoint(this.gameObject.transform.position);
        float distance = Vector3.Distance(this.gameObject.transform.position, closestPoint);
        if (distance > minDistance)
        {   
            if (isIcons == false)
            {   
                CameraCullingMask.Show(mainCamera, LayerMask.LayerToName(LayerMask.NameToLayer("Icons")));
                CameraCullingMask.Hide(mainCamera, LayerMask.LayerToName(LayerMask.NameToLayer("Entities")));
                isIcons = true;
            }
        }
        else
        {
            if (isIcons == true)
            {
                CameraCullingMask.Show(mainCamera, LayerMask.LayerToName(LayerMask.NameToLayer("Entities")));
                CameraCullingMask.Hide(mainCamera, LayerMask.LayerToName(LayerMask.NameToLayer("Icons")));
                isIcons = false;
            }
        }
    }
}
