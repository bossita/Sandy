﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IAnimation
{
    bool ChangeState(Animator animator, IAnimationState animationState, EntityInformation info, string state);

    bool ChangeState(Animator animator, IAnimationState animationState, EntityInformation info, Enum state);
    bool CanChangeState(Animator animator, System.Enum state);
    Enum GetCurrentState(Animator animator);
}
