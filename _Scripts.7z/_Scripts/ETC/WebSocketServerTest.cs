﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using WebSocketSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Concurrent;

public class WebSocketServerTest : MonoBehaviour
{
    private const string DefaultEchoServer = "ws://echo.websocket.org";
    ConcurrentQueue<string> messages;
    int MPS = 0;

    private WebSocket ws;

    //private string webLVCServer = "ws://10.0.0.2:9101/ws";
    private string webLVCServer = "ws://localhost:8001";

    // Start is called before the first frame update
    void Start()
    {
        if (this.ws == null)
        {
            if (this.webLVCServer.IsNullOrEmpty())
            {
                this.webLVCServer = DefaultEchoServer;
            }

            this.ws = new WebSocket(this.webLVCServer);
        }

        this.ws.OnOpen += (sender, e) =>
        {
            messages = new ConcurrentQueue<string>();
            Debug.Log("WebSocket Server connection is OPEN");
        };
        this.ws.OnClose += (sender, e) =>
        {
            Debug.Log("WebSocket Server connection is CLOSED");
        };

        this.ws.OnMessage += (sender, e) =>
        {
            MPS++;
            Debug.Log("Unity Received from server:" + e.Data);
            messages.Enqueue(e.Data);
        };

        this.ws.OnError += (sender, e) =>
        {
            Debug.Log("WebSocket Server connection is in an ERROR STATE");
        };

        this.ws.Connect();
    }
    //most messages dont apear in the drop file, varify later when we have all messages
    Dictionary<string, Type> MessageNameToType = new Dictionary<string, Type>()
    {
        { "WebLVC:PhysicalEntity", typeof(WebLVCPhysicalEntityMessage)},
        { "WebLVC:AggregateEntity", typeof(WebLVCAggregateEntityMessage)},
        { "WebLVC:EnvironmentalEntity", typeof(WebLVCEnvironmentalEntityMessage)},
        { "WebLVC:RadioTransmitter", typeof(WebLVCRadioTransmitterMessage)},
        { "WebLVC:WeaponFire", typeof(WebLVCWeaponFireInteractionMessage)},
        { "WebLVC:MunitionDetonation", typeof(WebLVCMunitionDetonationInteractionMessage)},
        { "WebLVC:StartResume", typeof(WebLVCStartResumeInteractionMessage)},
        { "WebLVC:StopFreeze", typeof(WebLVCStopFreezeInteractionMessage)},
        { "WebLVC:RadioSignal", typeof(WebLVCRadioSignalInteractionMessage)},
    };

    #region oldParse
    //public object ParseWebLVCMessage(string data)
    //{
    //    JObject obj = JObject.Parse(data);
    //    if ((int)obj["MessageKind"] < 0 || (int)obj["MessageKind"] > 4)
    //    {
    //        return null;
    //    }
    //    string m = JsonConvert.SerializeObject(obj);
    //    WebLVCMessage message = null;
    //    try
    //    {
    //        message = JsonConvert.DeserializeObject<WebLVCMessage>(m);
    //    }
    //    catch (Exception e)
    //    {

    //        Debug.Log(e);
    //    }

    //    object convertedMessage = null;
    //    switch (message.MessageKind)
    //    {
    //        case WebLVCMessageKind.Other:
    //            break;

    //        case WebLVCMessageKind.AttributeUpdate:
    //            AttributeUpdateMessage auMsg = JsonConvert.DeserializeObject<AttributeUpdateMessage>(data);
    //            if (auMsg.ObjectType == null || auMsg.ObjectType == string.Empty)
    //            {
    //                Debug.LogWarning("attribute update message is missing object type");
    //                return auMsg;
    //            }

    //            switch (auMsg.ObjectType)
    //            {
    //                case "WebLVC:PhysicalEntity":
    //                    //convertedMessage = JsonConvert.DeserializeObject<WebLVCPhysicalEntityMessage>(data);
    //                    Debug.Log(1);
    //                    WebLVCPhysicalEntityMessage msg = JsonConvert.DeserializeObject<WebLVCPhysicalEntityMessage>(data);
    //                    break;
    //                case "WebLVC:AggregateEntity":
    //                    convertedMessage = JsonConvert.DeserializeObject<WebLVCAggregateEntityMessage>(data);
    //                    break;
    //                case "WebLVC:EnvironmentalEntity":
    //                    convertedMessage = JsonConvert.DeserializeObject<WebLVCEnvironmentalEntityMessage>(data);
    //                    break;
    //                case "WebLVC:RadioTransmitter":
    //                    convertedMessage = JsonConvert.DeserializeObject<WebLVCRadioTransmitterMessage>(data);
    //                    break;
    //                default:
    //                    Debug.LogError("unknown object type");
    //                    return null;
    //            }

    //            break;

    //        case WebLVCMessageKind.Interaction:
    //            InteractionMessage iMsg = JsonConvert.DeserializeObject<InteractionMessage>(data);
    //            if (iMsg.InteractionType == null || iMsg.InteractionType == string.Empty)
    //            {
    //                Debug.LogWarning("interaction message is missing interaction type");
    //                return iMsg;
    //            }

    //            switch (iMsg.InteractionType)
    //            {
    //                case "WebLVC:WeaponFire":
    //                    convertedMessage = JsonConvert.DeserializeObject<WebLVCWeaponFireInteractionMessage>(data);
    //                    break;
    //                case "WebLVC:MunitionDetonation":
    //                    convertedMessage = JsonConvert.DeserializeObject<WebLVCMunitionDetonationInteractionMessage>(data);
    //                    break;
    //                case "WebLVC:StartResume":
    //                    convertedMessage = JsonConvert.DeserializeObject<WebLVCStartResumeInteractionMessage>(data);
    //                    break;
    //                case "WebLVC:StopFreeze":
    //                    convertedMessage = JsonConvert.DeserializeObject<WebLVCStopFreezeInteractionMessage>(data);
    //                    break;
    //                case "WebLVC:RadioSignal":
    //                    convertedMessage = JsonConvert.DeserializeObject<WebLVCRadioSignalInteractionMessage>(data);
    //                    break;
    //                default:
    //                    Debug.LogError("unknown interaction type");
    //                    return null;
    //            }

    //            break;

    //        case WebLVCMessageKind.Connect:
    //            convertedMessage = JsonConvert.DeserializeObject<ConnectMessage>(data);
    //            break;

    //        case WebLVCMessageKind.ObjectDeletion:
    //            convertedMessage = JsonConvert.DeserializeObject<ObjectDeletionMessage>(data);
    //            break;

    //        default:
    //            Debug.LogError("Unknown message kind");
    //            return null;
    //    }

    //    string parsedStr = convertedMessage.ToString();
    //    Debug.Log("[PARSED] " + parsedStr);
    //    return convertedMessage;
    //}
    #endregion

    private void StartParsing(string message)
    {
        WebLVCMessage webLVCMessage = null;
        try
        {
            webLVCMessage = JsonConvert.DeserializeObject<WebLVCMessage>(message)?.ParseAll(message);
        }
        catch (Exception e)
        {
            Debug.LogWarning("unparsable message: " + e);
            return;
        }

        //webLVCMessage = webLVCMessage.ParseAll(message);
        if (webLVCMessage == null)
        {
            Debug.LogWarning("Something went wrong");
            return;
        }

        #region use this after everything is implemented
        //if (!(webLVCMessage is IChildMessage))
        //{
        //    Debug.LogError("something went wrong");
        //}
        //(webLVCMessage as IChildMessage).HandleMessage(message);
        #endregion

        #region temporary test
        if (webLVCMessage as WebLVCPhysicalEntityMessage == null)
        {
            Debug.LogWarning("Something went wrong");
            return;
        }

        (webLVCMessage as WebLVCPhysicalEntityMessage).HandleMessage();
        #endregion
    }

    private float lastTimeUpdated = 0;

    // Update is called once per frame
    private void Update()
    {
        #region messages rate
        if (lastTimeUpdated + 1 < Time.realtimeSinceStartup)
        {
            Debug.Log("Messages per second: " + MPS);
            MPS = 0;
            lastTimeUpdated = Time.realtimeSinceStartup;
        }
        #endregion

        #region check messages
        string msg = "From Unity";
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("Sending message to WebSocket echo server: " + msg);
            this.ws.Send(msg);
        }
        #endregion

        string message;

        while (messages.TryDequeue(out message))
        {
            this.StartParsing(message);
        }
    }

    private void OnEnable()
    {
        if (this.ws == null)
        {
            if (this.webLVCServer.IsNullOrEmpty())
            {
                this.webLVCServer = DefaultEchoServer;
            }

            this.ws = new WebSocket(this.webLVCServer);
        }
    }

    private void OnDisable()
    {
        this.ws.Close();
        Debug.Log("WebSocket Connection has been disconnected");
    }

    private void OnDestroy()
    {
        this.ws.Close();
        Debug.Log("WebSocket Connection has been disconnected");
    }
}
