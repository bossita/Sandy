﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class ModelsProducer
{
    public static string GetModel(int[] entityType)
    {
        string modelsPath = null;
        int prefabNum = 0;

        ModelsEntityTypesDIS.EntityTypesDISToModels.TryGetValue(entityType, out modelsPath);

        if(ModelsEntityTypesDIS.GetRandomPrefabNumber(modelsPath, out prefabNum))
        {
            modelsPath += prefabNum;
        }
        return ResourcesPaths.GetPrefabResourcePath(modelsPath);
    }
}
