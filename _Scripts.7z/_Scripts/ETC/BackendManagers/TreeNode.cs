﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class TreeNode<T> : IEnumerable<TreeNode<T>>, IEquatable<TreeNode<T>>
{
    public T Data { get; set; }
    public TreeNode<T> Parent { get; set; }
    public ISet<TreeNode<T>> Children { get; set; }

    public Boolean IsRoot
    {
        get { return Parent == null; }
    }

    public Boolean IsLeaf
    {
        get { return Children.Count == 0; }
    }

    public int Level
    {
        get
        {
            return this.IsRoot ? 0 : Parent.Level + 1;
        }
    }


    public TreeNode(T data)
    {
        this.Data = data;
        this.Children = new HashSet<TreeNode<T>>();

        this.ElementsIndex = new LinkedList<TreeNode<T>>();
        this.ElementsIndex.Add(this);
    }

    public TreeNode<T> AddChild(T child)
    {
        TreeNode<T> existingChild = FindTreeNode(node => node.Data != null && node.Data.Equals(child));

        TreeNode<T> childNode = existingChild ?? new TreeNode<T>(child) { Parent = this };
        this.Children.Add(childNode);

        this.RegisterChildForSearch(childNode);

        return childNode;
    }

    public override string ToString()
    {
        return Data != null ? Data.ToString() : "[data null]";
    }


    #region searching

    private ICollection<TreeNode<T>> ElementsIndex { get; set; }

    private void RegisterChildForSearch(TreeNode<T> node)
    {
        ElementsIndex.Add(node);
        Parent?.RegisterChildForSearch(node);
    }

    public TreeNode<T> FindTreeNode(Func<TreeNode<T>, bool> predicate)
    {
        return this.ElementsIndex.FirstOrDefault(predicate);
    }

    #endregion


    #region iterating

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    public IEnumerator<TreeNode<T>> GetEnumerator()
    {
        yield return this;
        foreach (var directChild in this.Children)
        {
            foreach (var anyChild in directChild)
                yield return anyChild;
        }
    }

    #endregion

    public void Remove()
    {
        this.Children.Clear();
        this.Parent.Children.Remove(this);
    }

    public string PrintAllUnderMe()
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        TreeNode<T> treeRoot = this;
        foreach (TreeNode<T> node in treeRoot)
        {
            string indent = CreatePrintIndent(node.Level);
            sb.Append(indent).Append(node.Data?.ToString() ?? "null").Append("\n");
        }

        return sb.ToString();
    }
    private string CreatePrintIndent(int depth)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        for (int i = 0; i < depth; i++)
        {
            sb.Append('\t');
        }
        return sb.ToString();
    }

    public bool Equals(TreeNode<T> other)
    {
        return this.Data.Equals(other.Data);
    }
}
