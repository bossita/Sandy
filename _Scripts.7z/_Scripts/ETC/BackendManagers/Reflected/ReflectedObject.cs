﻿using System;

/// <summary>
/// Represents a remotely simulated object (e.g. entity, aggregate).
/// </summary>
[System.Serializable]
public class ReflectedObject
{
    /// <summary>
    /// Entity's object name.
    /// </summary>
    public string objectName;

    /// <summary>
    /// Simulation time at which last update was received for entity in Unity.
    /// </summary>
    public float lastTimeUpdatedUnity;

    /// <summary>
    /// Timestamp of last update received for entity.
    /// </summary>
    public string lastReceivedTimeStamp;

    public ReflectedObject(string objectName)
    {
        this.objectName = objectName;
        this.lastTimeUpdatedUnity = 0;
        this.lastReceivedTimeStamp = string.Empty;
    }
}
