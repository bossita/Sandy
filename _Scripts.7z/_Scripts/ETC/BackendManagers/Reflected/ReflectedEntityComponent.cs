﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReflectedEntityComponent : MonoBehaviour
{
    public ReflectedEntity entity;
    public SoldierState.SoldierStateEnum animationState;
}
