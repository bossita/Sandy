﻿[System.Serializable]
public class EntityTypeDIS
{
    public int EntityKind;
    public int Domain;
    public int CountryCode;
    public int Category;
    public int Subcategory;
    public int Specific;
    public int Extra;

    public EntityTypeDIS()
    {
        this.EntityKind = 0;
        this.Domain = 0;
        this.CountryCode = 0;
        this.Category = 0;
        this.Subcategory = 0;
        this.Specific = 0;
        this.Extra = 0;
    }

    public static EntityTypeDIS FromIntArray(int[] entityType)
    {
        if (entityType == null || entityType.Length != 7)
        {
            //TODO: log error message
            return null;
        }

        EntityTypeDIS entityTypeDIS = new EntityTypeDIS();
        entityTypeDIS.EntityKind = entityType[0];
        entityTypeDIS.Domain = entityType[1];
        entityTypeDIS.CountryCode = entityType[2];
        entityTypeDIS.Category = entityType[3];
        entityTypeDIS.Subcategory = entityType[4];
        entityTypeDIS.Specific = entityType[5];
        entityTypeDIS.Extra = entityType[6];

        return entityTypeDIS;
    }

    public static int[] ToIntArray(EntityTypeDIS entityTypeDIS)
    {
        if (entityTypeDIS == null)
        {
            //TODO: log error message
            return null;
        }

        return new int[]
        {
            entityTypeDIS.EntityKind,
            entityTypeDIS.Domain,
            entityTypeDIS.CountryCode,
            entityTypeDIS.Category,
            entityTypeDIS.Subcategory,
            entityTypeDIS.Specific,
            entityTypeDIS.Extra,
        };
    }
}
