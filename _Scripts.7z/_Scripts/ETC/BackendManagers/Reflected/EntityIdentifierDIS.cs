﻿[System.Serializable]
public class EntityIdentifierDIS
{
    public int SiteID;
    public int ApplicationID;
    public int EntityNumber;

    public EntityIdentifierDIS()
    {
        this.SiteID = 0;
        this.ApplicationID = 0;
        this.EntityNumber = 0;
    }
}
