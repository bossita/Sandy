﻿
/// <summary>
/// Represents a remotely simulated entity.
/// </summary>
[System.Serializable]
public class ReflectedEntity : ReflectedObject
{
    /// <summary>
    /// EntityIdentifier - DIS-style entity identifier expressed as an array
    /// of three numbers representing SiteID, ApplicationID, and EntityNumber,
    /// e.g. [1, 2, 3].
    /// </summary>
    public EntityIdentifierDIS entityIdentifier;

    /// <summary>
    /// DIS-style entity identifier expressed as an array of seven numbers
    /// representing EntityKind, Domain, CountryCode, Category, Subcategory,
    /// Specific, and Extra, as defined by the SISO Enumerations document,
    /// e.g. [1, 2, 225, 1, 6, 0, 0].
    /// </summary>
    public EntityTypeDIS entityType;

    /// <summary>
    /// A number representing the ForceIdentifier of the entity, as
    /// defined by DIS/RPR.
    /// </summary>
    public int forceIdentifier;

    /// <summary>
    /// A string representing the marking text of the entity, as defined
    /// by DIS/RPR.
    /// </summary>
    public string marking;

    /// <summary>
    /// An enumeration representing damage status of the entity.
    /// </summary>
    public DamageStateEnum damageState;

    /// <summary>
    /// Last world location of this entity.
    /// </summary>
    public Vector3d lastWorldLocation;

    /// <summary>
    /// Last velocity of this entity.
    /// </summary>
    public Vector3d lastVelocity;

    /// <summary>
    /// Last acceleration of this entity.
    /// </summary>
    public Vector3d lastAcceleration;

    /// <summary>
    /// Last orientation of this entity.
    /// </summary>
    public Vector3d lastRotation;

    /// <summary>
    /// Last angular velocity of this entity.
    /// </summary>
    public Vector3d lastAngularVelocity;

    public ReflectedEntity(string objectName)
        : base(objectName)
    {
        // "meta-data"
        this.entityIdentifier = new EntityIdentifierDIS();
        this.entityType = new EntityTypeDIS();
        this.forceIdentifier = 0;
        this.marking = string.Empty;
        this.damageState = DamageStateEnum.NoDamage;

        // last
        this.lastWorldLocation = Vector3d.zero;
        this.lastVelocity = Vector3d.zero;
        this.lastAcceleration = Vector3d.zero;
        this.lastRotation = Vector3d.zero;
        this.lastAngularVelocity = Vector3d.zero;
    }
}
