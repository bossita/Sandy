﻿using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System;
using System.Collections;
using Assets.Game._Scripts.Helpers;

public class MessagesHandler : MonoBehaviour
{
    [SerializeField]
    public GameObject pivotTerrain;
    [SerializeField]
    public GameObject world;
    public int x = 2;
    public int y = 1;
    public int z = 0;
    public float xBonus = 90;
    public float yBonus = -90;
    public float zBonus = -90;
    public float xMult = 1;
    public float yMult = 1;
    public float zMult = 1;
    private static GameObject parentTerrain;
    public static Transform worldTransform;
    static GameObject backEndManager = null;
    public static EntitiesRepository EntitiesRepository = null;
    public static MessagesHandler _messageHandler = null;

    private const string TRANSPARENT_SHADER = "Custom/TransparentPixel";
    private const string NAME_OF_THE_LIST_POINTS_IN_SHADER = "_listOfVisibleAreaPoints";
    private static Shader transparentShader;
    private static BoxCollider tableBoxCollider;
    private static Vector3[] tablePositions;
    private static Vector4[] positionOfTablePoints;

    private void Start()
    {
        parentTerrain = pivotTerrain;
        worldTransform = world.transform;
        backEndManager = GameObject.Find("BackEndManager");

        transparentShader = Shader.Find(TRANSPARENT_SHADER);
        GameObject table = GameObject.Find("MapVisibilityArea");
        tableBoxCollider = table.GetComponent<BoxCollider>();
        Vector3[] tableDirections = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(tableBoxCollider,
                                    BOX_COLLIDER_VERTICES.TopVerticesOfBoxCollider());
        tablePositions = BOX_COLLIDER_VERTICES.VerticesPosition(tableDirections, tableBoxCollider);
        InitializeVerticesPosition();



        EntitiesRepository = backEndManager.GetComponent<EntitiesRepository>();
        _messageHandler = this;

    }
    public void InitializeVerticesPosition()
    {
        positionOfTablePoints = new Vector4[tablePositions.Length];
        for (int indexPosition = 0; indexPosition < tablePositions.Length; indexPosition++)
        {
            positionOfTablePoints[indexPosition] = new Vector4(tablePositions[indexPosition].x, tablePositions[indexPosition].z);
        }
    }
    /// <summary>
    /// Create a gameobject that represents the entity.
    /// </summary>
    /// <param name="message"> Message to create the gameobject from.</param>
    /// <returns> Gameobject representing the entity. </returns>
    public static GameObject CreateEntity(WebLVCPhysicalEntityMessage message)
    {
        //Debug.Log("DeadReockoning: " + message.DeadReckoningAlgorithm);
        if (message.EntityType==null)
        {
            return null;
        }
        string modelPath = ModelsProducer.GetModel(message.EntityType);
        ReflectedEntity reflectedEntity = message.ToReflectedEntity();
        string objectName = reflectedEntity.objectName.Replace(':', '_');
        Tuple<IAnimation, IAnimationState> interfaces = null;
        if (ModelsEntityTypesDIS.EntityTypesDISToInterfaces.ContainsKey(message.EntityType))
        {
            interfaces = ModelsEntityTypesDIS.EntityTypesDISToInterfaces[message.EntityType];
        }
        GameObject gameObjEntity = Resources.Load<UnityEngine.Object>(modelPath) as GameObject;
        gameObjEntity = Instantiate(gameObjEntity, parentTerrain.transform);
        gameObjEntity.name = objectName;

        foreach (Renderer objectRendered in gameObjEntity.GetComponentsInChildren<Renderer>())
        {
            if (objectRendered != null)
            {
                AssignTransperancyByPosition(objectRendered);
            }
        }

        Animator animator = gameObjEntity.GetComponent<Animator>();
        if (animator != null)
        {   
            animator.speed = ModelsEntityTypesDIS.GetAnimatorSpeed(modelPath);
        }
        double[] transformedPosition;
        if (message.WorldLocationXYZ != null)
        {
            transformedPosition = TransformCoordinates.ECEF2Unity(message.WorldLocationXYZ);
        }
        else
        {
            transformedPosition = new double[] { 0d, 0d, 0d };
        }

        gameObjEntity.transform.localPosition = TransformCoordinates.doubleArrayToVector3(transformedPosition);

        EntityInformation info = new EntityInformation
        {
            gameObject = gameObjEntity,
            reflectedEntity = reflectedEntity,
            holder = new EntitiyComponentHolder()
            {
                animator = animator,
                state = (interfaces ==null? null : interfaces.Item1.GetCurrentState(animator))
            }
        };
        EntitiesRepository.Entities.Add(objectName, info);

        //TODO: remove to a function
        switch (message.DamageState)
        {
            case DamageStateEnum.NoDamage:
                break;
            case DamageStateEnum.SlightDamage:
                break;
            case DamageStateEnum.ModerateDamage:
                break;
            case DamageStateEnum.Destroyed:
                // remove this later
                if (interfaces != null)
                {
                    interfaces.Item1.ChangeState(animator, interfaces.Item2, info, "Death");//SoldierState.SoldierStateEnum.Death);
                }
                //Debug.Log("[DEATH]");
                break;
        }


        return gameObjEntity;
    }

    private static void AssignTransperancyByPosition(Renderer objectRendered)
    {
        Material[] arrayOfMaterialsForRenderer = objectRendered.sharedMaterials;
        for (int indexMaterial = 0; indexMaterial < arrayOfMaterialsForRenderer.Length; indexMaterial++)
        {
            Material currentMat = arrayOfMaterialsForRenderer[indexMaterial];
            Debug.Log(objectRendered.name);
            Debug.Log(currentMat);
            if (currentMat != null)
            {
                currentMat.shader = transparentShader;
                currentMat.SetVectorArray(NAME_OF_THE_LIST_POINTS_IN_SHADER, positionOfTablePoints);
            }
        }
    }
    /// <summary>
    /// Makes the entity shoot.
    /// </summary>
    /// <param name="message">WeaponFire interaction message.</param>
    /// <param name="entity">The shooter.</param>
    /// <param name="targetEntity">The target.</param>
    public static void WeaponFireAction(WebLVCWeaponFireInteractionMessage message, GameObject entity, GameObject targetEntity)
    {
        WeaponFire weaponFire = new WeaponFire(entity, targetEntity, message.Rate, message.Quantity);
        weaponFire.StartShooting(EntitiesRepository.Entities[entity.name]);
    }

    //maybe split this function later
    /// <summary>
    /// Updates entity position, rotation and animation.
    /// </summary>
    /// <param name="message">Physical entity message.</param>
    /// <param name="gameObjEntity">Entity to update.</param>
    /// <param name="firstTime">Is it the first time updating the current entity after creation?</param>
    public static void UpdateEntity(WebLVCPhysicalEntityMessage message, GameObject gameObjEntity, bool firstTime)
    {
        // maybe remove this later
        if (EntitiesRepository.Entities.ContainsKey(gameObjEntity.name))
        {
            float currentTimeUpdatedUnity = Time.realtimeSinceStartup;
            _messageHandler.DeadReckonEntity(gameObjEntity, message, firstTime, currentTimeUpdatedUnity);
            //_messageHandler.RotateEntity(gameObjEntity, message.OrientationPsiThetaPhi, currentTimeUpdatedUnity);

            bool needToPlayDeathAnimation = false;
            if (message.DamageState == DamageStateEnum.Destroyed && EntitiesRepository.Entities[gameObjEntity.name].reflectedEntity.damageState != DamageStateEnum.Destroyed)
            {
                needToPlayDeathAnimation = true;
            }

            // not allocating new space
            message.AssignToReflectedEntity(EntitiesRepository.Entities[gameObjEntity.name].reflectedEntity, currentTimeUpdatedUnity);

            if (needToPlayDeathAnimation)
            {
                var animator = EntitiesRepository.Entities[gameObjEntity.name].holder.animator;
                animator?.SetTrigger("Death");
                //Debug.Log("[DEATH]");
            }
            //switch (message.DamageState)
            //{
            //    case DamageStateEnum.NoDamage:
            //        break;
            //    case DamageStateEnum.SlightDamage:
            //        break;
            //    case DamageStateEnum.ModerateDamage:
            //        break;
            //    case DamageStateEnum.Destroyed:
                    
            //        break;
            //}
        }
        else
        {
            Debug.LogWarning("trying to update object thats not on the manager's list");
        }

        
    }

    /// <summary>
    /// Dead reckons entity's position and updates entity rotation
    /// </summary>
    /// <param name="entity">Entity to update</param>
    /// <param name="message">Physical entity message.</param>
    /// <param name="firstTime">Is it the first time updating the current entity after creation?</param>
    /// <param name="currentTimeUpdatedUnity">The unity time (Time.realtimesincestartup) this function is called</param>
    private void DeadReckonEntity(GameObject entity, WebLVCPhysicalEntityMessage message, bool firstTime, float currentTimeUpdatedUnity)
    {   
        if (message.EntityType == null)// || !ModelsEntityTypesDIS.EntityTypesDISToInterfaces.ContainsKey(message.EntityType))
        {
            return;
        }

        Vector3d? worldLocationXYZ = Vector3d.From3DArrayNullable(message.WorldLocationXYZ);
        Vector3d? orientationPsiThetaPhi = Vector3d.From3DArrayNullable(message.OrientationPsiThetaPhi);

        if (worldLocationXYZ.HasValue || orientationPsiThetaPhi.HasValue)
        {
            Tuple<IAnimation, IAnimationState> animationInterfaces = null;
            ModelsEntityTypesDIS.EntityTypesDISToInterfaces.TryGetValue(message.EntityType, out animationInterfaces);
            //animationInterfaces=ModelsEntityTypesDIS.EntityTypesDISToInterfaces[message.EntityType];
            var info = EntitiesRepository.Entities[entity.name];
            Animator animator = info.holder.animator;
            if (animator != null && animationInterfaces != null)
            {
                Vector3d? velocityVectorXYZ = Vector3d.From3DArrayNullable(message.VelocityVectorXYZ);
                if (!velocityVectorXYZ.HasValue || velocityVectorXYZ.Equals(Vector3d.zero))
                {
                    if (info.holder.state != animationInterfaces.Item2.stateNameToState["Idle"])
                    {
                        animationInterfaces.Item1.ChangeState(animator, animationInterfaces.Item2, info, "Idle");
                    }
                }
                else
                {
                    if (info.holder.state != animationInterfaces.Item2.stateNameToState["Walk"])
                    {
                        animationInterfaces.Item1.ChangeState(animator, animationInterfaces.Item2, info, "Walk");
                    }
                }
            }
            bool isHuman = true;
            if (ModelsEntityTypesDIS.EntityTypesDISToModels[message.EntityType] == ResourcesPaths.HUMVEE_PREFAB)
            {
                isHuman = false;
            }
            //if (entity.name == "1_3001_404vrx")
            //{
            //    Debug.LogFormat("before: ({0},{1},{2}", message.OrientationPsiThetaPhi[0], message.OrientationPsiThetaPhi[1], message.OrientationPsiThetaPhi[2]);
            //    Debug.LogFormat("after: {0}", (Vector3)TransformCoordinates.ECEFOrientation2UnityEulerAngles(orientationPsiThetaPhi.Value));
            //}
            if (firstTime)
            {
                // set position
                info.reflectedEntity.lastWorldLocation = worldLocationXYZ.Value;
                entity.transform.localPosition = (Vector3)TransformCoordinates.ECEF2Unity(info.reflectedEntity.lastWorldLocation);

                // set rotation
                info.reflectedEntity.lastRotation = orientationPsiThetaPhi.Value;
                entity.transform.localEulerAngles = (Vector3)TransformCoordinates.ECEFOrientation2UnityEulerAngles(info.reflectedEntity.lastRotation, isHuman);
            }
            else
            {
                float deltaSeconds = currentTimeUpdatedUnity - info.reflectedEntity.lastTimeUpdatedUnity;
                if (info.holder.DeadReckoningCoroutine == null)
                {
                    info.holder.DeadReckoningCoroutine=StartCoroutine(DeadReckonEntityBetweenMessages(new DeadReckoningCoroutineParams()
                    {
                        info = info,
                        endPosition = worldLocationXYZ.Value,
                        deltaSeconds = deltaSeconds,
                        endRotation = orientationPsiThetaPhi.Value,
                        isHuman = isHuman,
                    }));
                }
                else
                {
                    info.holder.DeadReckoningParameters.Enqueue(new DeadReckoningCoroutineParams()
                    {
                        info = info,
                        endPosition = worldLocationXYZ.Value,
                        deltaSeconds = deltaSeconds,
                        endRotation = orientationPsiThetaPhi.Value,
                        isHuman = isHuman,
                    });
                }
            }
        }
    }

    //private void RotateEntity(GameObject entity, double[] orientationPsiThetaPhi, float currentTimeUpdatedUnity)
    //{
    //    if (orientationPsiThetaPhi != null)
    //    {
    //        //Vector3d orientationDegrees = new Vector3d()
    //        //{
    //        //    x = (xMult * TransformCoordinates.ConvertRadiansToDegrees(orientationPsiThetaPhi[this.x])) + this.xBonus,
    //        //    y = (yMult * TransformCoordinates.ConvertRadiansToDegrees(orientationPsiThetaPhi[this.y])) + this.yBonus,
    //        //    z = (zMult * TransformCoordinates.ConvertRadiansToDegrees(orientationPsiThetaPhi[this.z])) + this.zBonus,
    //        //};
    //        //Vector3 eular = (Vector3)orientationDegrees;

    //        //// should have definitely found a solution that replaces this code yet
    //        //if (((180 - Mathf.Abs(eular.x)) < Mathf.Abs(eular.x))
    //        //    && ((180 - Mathf.Abs(eular.z)) < Mathf.Abs(eular.z)))
    //        //{
    //        //    eular.y = -(180 + eular.y);
    //        //}

    //        //entity.transform.localEulerAngles = eular;
    //        entity.transform.localEulerAngles = (Vector3)TransformCoordinates.ECEFOrientation2UnityEulerAngles(Vector3d.From3DArray(orientationPsiThetaPhi));


    //        //var info = EntitiesRepository.Entities[entity.name];
    //        //float deltaSeconds = currentTimeUpdatedUnity - info.reflectedEntity.lastTimeUpdatedUnity;
    //        //if (info.holder.rotationCoroutine == null)
    //        //{
    //        //    info.holder.rotationCoroutine = (StartCoroutine(RotateEntityBetweenMessages(new RotationCoroutineParams()
    //        //    {
    //        //        info = info,
    //        //        endOrientation = Vector3d.From3DArray(orientationPsiThetaPhi),
    //        //        deltaSeconds = deltaSeconds
    //        //    })));
    //        //}
    //        //else
    //        //{
    //        //    info.holder.rotationParameters.Enqueue(new RotationCoroutineParams()
    //        //    {
    //        //        info = info,
    //        //        endOrientation = Vector3d.From3DArray(orientationPsiThetaPhi),
    //        //        deltaSeconds = deltaSeconds
    //        //    });
    //        //}

    //    }
    //}

    public IEnumerator DeadReckonEntityBetweenMessages(DeadReckoningCoroutineParams parameters)
    {
        // rotation
        parameters.info.reflectedEntity.lastRotation = parameters.endRotation;
        parameters.info.gameObject.transform.localEulerAngles = (Vector3)TransformCoordinates.ECEFOrientation2UnityEulerAngles(parameters.info.reflectedEntity.lastRotation, parameters.isHuman);

        // position
        Vector3d startPosition = parameters.info.reflectedEntity.lastWorldLocation;
        float startTime = Time.realtimeSinceStartup;
        float offSet = 0;
        Vector3d distance = parameters.endPosition - startPosition;
        while (offSet< parameters.deltaSeconds)
        {
            yield return new WaitForEndOfFrame();
            offSet = Time.realtimeSinceStartup - startTime;
            if(offSet> parameters.deltaSeconds)
            {
                offSet = parameters.deltaSeconds;
            }
            parameters.info.reflectedEntity.lastWorldLocation = startPosition + (distance * offSet / parameters.deltaSeconds);
            Vector3 unityPosition = (Vector3)TransformCoordinates.ECEF2Unity(parameters.info.reflectedEntity.lastWorldLocation);
            
            parameters.info.gameObject.transform.localPosition = unityPosition;
        }
        
        try
        {
            parameters.info.holder.DeadReckoningCoroutine = null;
        }
        catch
        {
            Debug.LogError("coroutines aren't syncing too well, maybe add some locks to fix it");
        }
        if (parameters.info.holder.DeadReckoningParameters.Count != 0)
        {
            parameters.info.holder.DeadReckoningCoroutine=(StartCoroutine(
                DeadReckonEntityBetweenMessages(parameters.info.holder.DeadReckoningParameters.Dequeue())));
        }
    }

    //public IEnumerator RotateEntityBetweenMessages(RotationCoroutineParams parameters)
    //{
        
    //    parameters.info.holder.rotationCoroutine = null;

    //    if (parameters.info.holder.movementCoroutine == null)
    //    {
    //        if (parameters.info.holder.rotationParameters.Count != 0 && parameters.info.holder.rotationParameters.Count!=0)
    //        {
    //            parameters.info.holder.rotationCoroutine = (StartCoroutine(
    //                RotateEntityBetweenMessages(parameters.info.holder.rotationParameters.Dequeue())));
    //        }
    //    }
    //    yield return null;
    //}

    //int count = 0;
    //float lastTimeUpdated = 0;
    //private void FixedUpdate()
    //{
    //    float seconds = Time.realtimeSinceStartup- lastTimeUpdated;
    //    lastTimeUpdated = Time.realtimeSinceStartup;
    //    Debug.Log(seconds);
    //}

    

    //public static double[] ECEF2Unity(double[] coord)
    //{
    //    return new double[]
    //    {
    //        -coord[1],
    //        coord[0] - MultiClass.equatorial_radius_WGS84,
    //        -coord[2],
    //    };
    //}
    // coordinate system
    // x_unity = -y_ecef
    // y_unity = x_ecef
    // z_unity = -z_ecef
    // orientation
    // 0 psi -> z_ecef
    // 1 theta -> y_ecef
    // 2 phi -> x_ecef



    public static void AddToHierarchy(WebLVCAggregateEntityMessage message)
    {
        if(message.Subordinates==null)
        {
            return;
        }
        string objectName = message.ObjectName.Replace(':', '_');

        TreeNode<string> parentEntity = EntitiesRepository.Hierarchy.AddChild(objectName);

        foreach (string subName in message.Subordinates)
        {
            parentEntity.AddChild(subName.Replace(':', '_'));
        }

        string modelPath = ModelsProducer.GetModel(message.EntityType);
        GameObject parent = Resources.Load<UnityEngine.Object>(modelPath) as GameObject;
        parent = Instantiate(parent, Vector3.zero, Quaternion.identity, worldTransform);
        
        EntitiesRepository.Entities.Add(objectName, new EntityInformation
        {
            gameObject = parent,
            reflectedEntity = new ReflectedEntity(objectName)
            {
                entityType = EntityTypeDIS.FromIntArray(message.EntityType)
            },
            holder = null // TODO: fix
        });
        //Debug.LogFormat("Parent: {0}\n\tSubs: {1}", message.ObjectName, string.Join(", ", message.Subordinates));
        //Debug.Log(MessagesHandler.EntitiesRepository?.Hierarchy.PrintAllUnderMe());
    }

    //public static void AddIcon(WebLVCAggregateEntityMessage message)
    //{
    //    // if already exists
    //    TreeNode<string> parentEntity = EntitiesRepository.Hierarchy.FindTreeNode(node => node.Data != null && node.Data.Contains(message.ObjectName.Replace(':', '_')));
    //    GameObjectReflectedEntityPair pair = null;
    //    MessagesHandler.EntitiesRepository?.Entities.TryGetValue(parentEntity.Data, out pair);

    //    #region squad with parent
    //    //List<GameObject> nonParentalGameobjects = new List<GameObject>();
    //    //bool haveParent = false;
    //    //GameObject parent = null;
    //    //foreach (string name in entitiesNames)
    //    //{
    //    //    GameObject child = EntitiesRepository.Entities[name].gameObject;
    //    //    if (child.transform.parent?.name==parentEntity.Data)
    //    //    {
    //    //        haveParent = true;
    //    //        parent = child.transform.parent.gameObject;
    //    //    }
    //    //    else
    //    //    {
    //    //        nonParentalGameobjects.Add(child);
    //    //    }
    //    //}
    //    //if(haveParent==false)
    //    //{
    //    //    parent = new GameObject(parentEntity.Data);
    //    //    string modelPath = ModelsProducer.GetModel(message.EntityType);
    //    //    GameObject image = Resources.Load<UnityEngine.Object>(modelPath) as GameObject;
    //    //    Instantiate(image, Vector3.zero, Quaternion.identity, parent.transform);
    //    //}
    //    //else
    //    //{   
    //    //    foreach(GameObject child in nonParentalGameobjects)
    //    //    {
    //    //        child.transform.parent = parent.transform;
    //    //    }
    //    //}
    //    #endregion
    //}
    public static void UpdateAggregatedParent(WebLVCAggregateEntityMessage message)
    {
        if(message.Subordinates==null)
        {
            return;
        }
        var messageSubs = new HashSet<string>(message.Subordinates);
        
        TreeNode<string> parentEntity = EntitiesRepository.Hierarchy.FindTreeNode(node => node.Data != null && node.Data.Contains(message.ObjectName.Replace(':', '_')));
        HashSet<string> entitiesNames = new HashSet<string>(parentEntity.Children.Select(x => x.Data));

        var unionMessageSubs = new HashSet<string>(messageSubs);
        unionMessageSubs.IntersectWith(entitiesNames);
        unionMessageSubs.UnionWith(messageSubs);
        List<string> futureChildren = new List<string>();
        foreach(var child in unionMessageSubs)
        {
            futureChildren.Add(child.Replace(':', '_'));
        }
        //var futureChildren= unionMessageSubs.Select(x => x.Replace(':', '_'));
        var children= parentEntity.Children.ToArray();
        //List<string> das = new List<string>(parentEntity.Children.Select(x => x.Data));
        for (int i = children.Length-1; i >= 0; i--)
        {
            if (!futureChildren.Contains(children[i].Data))
            {
                children[i].Remove();
            }
        }   
        foreach (var item in futureChildren)
        {
            parentEntity.AddChild(item);
        }

        List<GameObject> childGameObjects = new List<GameObject>();
        foreach (var item in futureChildren)
        {
            EntityInformation childPair = null;
            MessagesHandler.EntitiesRepository?.Entities.TryGetValue(item, out childPair);
            if (childPair != null)
            {
                childGameObjects.Add(childPair.gameObject);
            }
        }
        // create new scrip - done
        // assign childGameObjects to new script-done
        // copy downstairs to make the down script work and update position - done
        // maybe store later all squad scripts to prevent the use of getcomponent
        // working fine besides on civs because are not added to the entities repository
        try
        {
            EntitiesRepository.Entities[parentEntity.Data].gameObject.GetComponent<Squad>().members = childGameObjects;
        }
        catch
        {
            //Debug.Log(parentEntity.Data);
        }
    }
    public static void DeleteEntity(ObjectDeletionMessage message)
    {
        Debug.LogFormat("[DELETED MESSAGE] Delete {0}", message.ObjectName);
        string name = message.ObjectName.Replace(':', '_');
        EntityInformation pair = null;
        MessagesHandler.EntitiesRepository?.Entities.TryGetValue(name, out pair);
        if (pair != null && pair.gameObject != null)
        {
            Destroy(pair.gameObject);
        }
        MessagesHandler.EntitiesRepository.Entities.Remove(name);
        TreeNode<string> nodeToRemove = EntitiesRepository.Hierarchy.FindTreeNode(node => node.Data != null && node.Data.Contains(name));
        nodeToRemove?.Remove();
    }
}
