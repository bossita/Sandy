﻿using System.Collections.Generic;
using UnityEngine;

public class EntitiesRepository : MonoBehaviour
{
    [HideInInspector] // using [SerializeField] can be seen in inspector - Use Carefully - has a huge impact on performance
    private EntitiesRepositoryDictionary _entities;

    [HideInInspector]
    private TreeNode<string> _hierarchy;

    public EntitiesRepositoryDictionary Entities
    {
        get { return _entities; }
        set { _entities = value; }
    }

    public TreeNode<string> Hierarchy
    {
        get { return _hierarchy; }
        set { _hierarchy = value; }
    }

    private void Start()
    {
        Entities = new EntitiesRepositoryDictionary();
        Hierarchy = new TreeNode<string>("DummyRoot");
    }
}

[System.Serializable]
public class EntitiesRepositoryDictionary : SerializableDictionary<string, EntityInformation>
{
}

[System.Serializable]
public class EntityInformation
{
    public GameObject gameObject;
    public EntitiyComponentHolder holder;
    public ReflectedEntity reflectedEntity;
}
