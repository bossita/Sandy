﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class ChangeShaderOnMiniMap : MonoBehaviour
{
    public Shader shaderBeingSeenByCamera;
    private Camera cameraUsedUpon;
    private const string TAG_OF_REPLACEMENT = "RenderType";
    private void Start()
    {
        cameraUsedUpon = GetComponent<Camera>();
        // replaces all the shaders having the tag of TAG_OF_REPLACEMENT to the shaderToChange
        cameraUsedUpon.SetReplacementShader(shaderBeingSeenByCamera, TAG_OF_REPLACEMENT);
    }
    //private void OnRenderImage(RenderTexture source, RenderTexture destination)
    //{
    //    source.
    //    Graphics.Blit(source, destination);
    //}
    //private void OnRenderImage(RenderTexture source, RenderTexture destination)
    //{
    //    cameraUsedUpon.SetReplacementShader(shaderToChangeTo, "RenderType");
    //    Graphics.Blit(source, destination);
    //}
}
