﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[AddComponentMenu("Rendering/SetRenderQueue")]
public class SetRenderQueue : MonoBehaviour {
    [SerializeField]
    protected int[] m_queues = new int[] { 3000 };
    protected void Awake()
    {
        Material[] materials = GetComponent<Renderer>().materials;
        for(int indexMaterial = 0;indexMaterial < materials.Length &&
                                  indexMaterial < m_queues.Length; indexMaterial++)
        {
            materials[indexMaterial].renderQueue = m_queues[indexMaterial];
        }
    }
}
