﻿using UnityEngine;

public class EransCompassScript : MonoBehaviour
{
    [SerializeField]
    public Transform mapHandler;

    [SerializeField]
    public GameObject CompassItemsHolder;

    private bool visibilityState      = true;
    private bool inMiddleOfButtonPush = false;

    private void CheckForButtonPush()
    {
        bool buttonPushRegistered = ButtonPushRegistered();
        if (!inMiddleOfButtonPush && buttonPushRegistered)
        {
            inMiddleOfButtonPush = true;
            ToggleDisplay();
        }
        else if (!buttonPushRegistered)
        {
            inMiddleOfButtonPush = false;
        }
    }

    private void ToggleDisplay()
    {
        visibilityState = !visibilityState;
        SetCompassItemsVisibility(visibilityState);
    }

    private void SetCompassItemsVisibility(bool visibilityState)
    {
        CompassItemsHolder.SetActive(visibilityState);
    }

    public bool ButtonPushRegistered()
    {
        return ControllerInputsHolder.XButtonPush();
    } 

    void Start()
    {
        visibilityState = true;
        SetCompassItemsVisibility(visibilityState);
    }

    void Update()
    {
        transform.eulerAngles = mapHandler.eulerAngles;
        CheckForButtonPush();
    }
}
