﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Orientation
{
    public double x;
    public double y;
    public double z;
    public Vector3 eular;
}
