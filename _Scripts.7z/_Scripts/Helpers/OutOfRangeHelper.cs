﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Game._Scripts.Helpers
{
    public static class OutOfRangeHelper
    {
        public static Vector3 ClampingVectorWithinRange(Vector3 newScale, Vector3 minScale, Vector3 maxScale)
        {
            Vector3 currentMapLocalScale = newScale;
            currentMapLocalScale.x = Mathf.Clamp(currentMapLocalScale.x, minScale.x, maxScale.x);
            currentMapLocalScale.y = Mathf.Clamp(currentMapLocalScale.y, minScale.y, maxScale.y);
            currentMapLocalScale.z = Mathf.Clamp(currentMapLocalScale.z, minScale.z, maxScale.z);

            return currentMapLocalScale;
        }
        public static bool IsPointWhitinRect(Vector3[] rect, Vector3 point)
        {
            // calculated in the x,z plane
            bool isWithinRect = false;
            // not wise preformance wise tho more readable
            //float maxXValue = rect.Max((vec) => vec.x);
            //float maxZValue = rect.Max((vec) => vec.z);
            //float minXValue = rect.Min((vec) => vec.x);
            //float minZValue = rect.Min((vec) => vec.z);

            float maxXValue = rect[0].x;
            float minXValue = rect[0].x;
            float maxZValue = rect[0].z;
            float minZValue = rect[0].z;
            for (int index = 1; index < rect.Length; index++)
            {
                if (rect[index].x > maxXValue)
                {
                    maxXValue = rect[index].x;
                }
                else if (rect[index].x < minXValue)
                {
                    minXValue = rect[index].x;
                }
                if (rect[index].z > maxZValue)
                {
                    maxZValue = rect[index].z;
                }
                else if (rect[index].z < minZValue)
                {
                    minZValue = rect[index].z;
                }
            }

            if (IsValueApproxWithinRange(point.x, minXValue, maxXValue))
            {
                if (IsValueApproxWithinRange(point.z, minZValue, maxZValue))
                {
                    isWithinRect = true;
                }
            }
            return isWithinRect;
        }
        public static bool TryFindingTheFarthestPointOutOfRange(Vector3[] smallerVolumePoints, Vector3[] largerVolumePoints, BoxCollider largerCollider,
                                             bool shouldTakeMaxDistanceFromOutOfRange, out Vector3 farthestPoint)
        {
            // TODO : check why sometimes the values of points are 0.000001 apart away, to eliminate the use
            // of Mathf.Approximetly and use = instead.
            bool isWithinArea = true;
            bool mapIsOutOfRange = false;
            Vector3 POINT_DEFAULT_VALUE = Vector3.zero;
            Vector3 pointFarthestFromCollider = POINT_DEFAULT_VALUE;
            float maxDistanceFromCollider = -1.0f;
            // usement for testing
            //int indexOutOfRange;
            Bounds largerColliderBounds = largerCollider.bounds;
            for (int indexPoint = 0; indexPoint < smallerVolumePoints.Length; indexPoint++)
            {
                Vector3 currentPoint = smallerVolumePoints[indexPoint];
                isWithinArea = IsPointWhitinRect(largerVolumePoints, currentPoint);
                if (!isWithinArea)
                {
                    Debug.DrawRay(currentPoint, Vector3.up * 10000, Color.black, 10f);
                    mapIsOutOfRange = true;
                    if (!shouldTakeMaxDistanceFromOutOfRange)
                    {
                        pointFarthestFromCollider = currentPoint;
                        //indexOutOfRange = indexPoint;
                        break;
                    }
                    else
                    {
                        // take max distance impact point
                        float currentDistance = largerColliderBounds.SqrDistance(currentPoint);
                        if (currentDistance > maxDistanceFromCollider)
                        {
                            //indexOutOfRange = indexPoint;
                            pointFarthestFromCollider = currentPoint;
                            maxDistanceFromCollider = currentDistance;
                        }
                    }
                }
            }
            farthestPoint = pointFarthestFromCollider;
            return mapIsOutOfRange;
        }
        private static bool IsValueApproxWithinRange(float valueToCheck, float minRange, float maxRange)
        {
            return (valueToCheck >= minRange || ApproximetlyEqual(valueToCheck, minRange)) &&
                   (valueToCheck <= maxRange || ApproximetlyEqual(valueToCheck, maxRange));
        }
        public static bool ApproximetlyEqual(float firstValue, float secondValue)
        {
            return Mathf.Approximately(firstValue, secondValue);
        }
        public static bool IsOutOfRange(Vector3[] smallerVolumePoints, Vector3[] largerVolumePoints)
        {
            bool isWithinArea = true;
            for (int indexPoint = 0; indexPoint < smallerVolumePoints.Length && isWithinArea; indexPoint++)
            {
                Vector3 currentPoint = smallerVolumePoints[indexPoint];
                isWithinArea = IsPointWhitinRect(largerVolumePoints, currentPoint);
            }
            return isWithinArea;
        }
    }
}
