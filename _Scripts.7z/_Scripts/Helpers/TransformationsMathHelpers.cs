﻿using Assets.Game._Scripts.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Game._Scripts.Helpers
{
    public static class TransformationsMathHelpers
    {
        public static void ScaleAroundPivot(Transform target, Transform pivot, Vector3 scale)
        {
            Vector3 A = target.localPosition;
            Vector3 B = pivot.position;

            Vector3 C = A - B; // diff from object pivot to desired pivot/origin

            float RS = scale.x / target.transform.localScale.x; // relative scale factor

            // calc final position post-scale
            Vector3 FP = B + C * RS;
            FP.y = target.localPosition.y;
            // finally, actually perform the scale/translation
            target.localScale = scale;
            target.localPosition = FP;
        }
        // Calculated in the x z plane
        public static bool IsWithinDirectionMagnitude(Vector3 startingPoint, Vector3 direction, Vector3 endingPoint)
        {
            Vector3 directionToPoint = endingPoint - startingPoint;
            directionToPoint.y = 0;
            direction.y = 0;
            float firstFactorOfMultiplication = FactorOfMultiplicationOfParallelVectors(directionToPoint, direction);
            // not checking if the directions are parallel (all components share the same factor m(x,y,z) = (x1,y1,z1)), because, using the function only on parallel vectors
            // and within the direction magnitude area ( 0 < m <= 1)
            return ((firstFactorOfMultiplication >= 0.0f) && firstFactorOfMultiplication <= 1.0f);
        }
        private static float FactorOfMultiplicationOfParallelVectors(Vector3 firstVec, Vector3 secondVec)
        {
            float factor = 0.0f;
            if (firstVec.x != 0 && secondVec.x != 0)
            {
                factor = firstVec.x / secondVec.x;
            }
            else if (firstVec.z != 0 && secondVec.z != 0)
            {
                factor = firstVec.z / secondVec.z;
            }
            return factor;
        }
        public static bool AreaOfVisiblityBiggerThanMapArea(Vector3 visibilitySize, Vector3 mapSize)
        {
            // calculated in the x,z plane
            return visibilitySize.x > mapSize.x && visibilitySize.z > mapSize.z;
        }
        public static bool AreaOfVisiblityBiggerThanMapArea(Collider visibilityCollider, Collider mapCollider)
        {
            Vector3 visibilitSize = visibilityCollider.bounds.size;
            Vector3 mapSize = mapCollider.bounds.size;
            return AreaOfVisiblityBiggerThanMapArea(visibilitSize, mapSize);
        }
        public static Vector3 FindIntersectionXZPlane(Vector3 firstVecStart, Vector3 firstVecEnd,
                                        Vector3 secondVecStart, Vector3 secondVecEnd)
        {
            double a1 = firstVecEnd.z - firstVecStart.z;
            double b1 = firstVecStart.x - firstVecEnd.x;
            double c1 = a1 * firstVecStart.x + b1 * firstVecStart.z;
            double a2 = secondVecEnd.z - secondVecStart.z;
            double b2 = secondVecStart.x - secondVecEnd.x;
            double c2 = a2 * secondVecStart.x + b2 * secondVecStart.z;
            double delta = a1 * b2 - a2 * b1;
            // the lines are parallel, thus, no intersection 
            if (delta == 0)
            {
                throw new LinesAreParallelException();
            }
            float vectorXValue = CutDoubleValues((b2 * c1 - b1 * c2) / delta);
            float vectorZValue = CutDoubleValues((a1 * c2 - a2 * c1) / delta);


            return new Vector3(vectorXValue, 0, vectorZValue);
        }

        private static float CutDoubleValues(double value)
        {
            const float DIVIDER = 100000;
            double valueWithDividerDigits = value * DIVIDER;
            value = (((int)valueWithDividerDigits) / DIVIDER);
            return (float)value;
        }
    }
}
