﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public static class CombinationsGenerator
{

    public static IEnumerable<IEnumerable<T>> CombinationsOfLengthGiven<T>(IEnumerable<T> list, int length)
    {
        if(length == 1)
        {
            return list.Select((t) => (new T[] { t}).AsEnumerable());
        }
        return CombinationsOfLengthGiven(list, length - 1).SelectMany((t) =>

             list.Where(o => !t.Contains(o)), (t1, t2) => t1.Concat((new T[] { t2 }).AsEnumerable()));
    }
    public static List<T[]> CombinationByMovement<T>(List<T> list)
    {
        List<T[]> combinationOfValues = new List<T[]>();
        for (int currentMovement = 0;currentMovement < list.Count ;currentMovement++)
        {
            T[] currentList = CopiedArrayBeforeListMovement(list);
            combinationOfValues.Add(currentList);
        }
        return combinationOfValues;
    }
    private static T[] CopiedArrayBeforeListMovement<T>(List<T> listToMove)
    {
        T[] movedList = new T[listToMove.Count];
        listToMove.CopyTo(movedList);
        for(int indexArray = 0;indexArray < listToMove.Count - 1;indexArray++)
        {
            SwapValues(listToMove, indexArray, indexArray + 1);
        }
        return movedList;
    }
    private static void SwapValues<T>(List<T> listValues, int firstIndex, int secondIndex)
    {
        int listLength = listValues.Count;
        if (ValueWithinRange(firstIndex, 0, listLength) && ValueWithinRange(secondIndex, 0, listLength))
        {
            T valueSaved = listValues[firstIndex];
            listValues[firstIndex] = listValues[secondIndex];
            listValues[secondIndex] = valueSaved;
        }
        else
        {
            Debug.LogWarning("one of the indices is not within lists' length");
        }
    }
    private static bool ValueWithinRange(int valueToCheck, int minRange, int maxRange)
    {
        return valueToCheck >= minRange && valueToCheck < maxRange;
    }
}
