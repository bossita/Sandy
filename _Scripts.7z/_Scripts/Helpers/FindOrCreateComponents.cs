﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
namespace Assets.Game._Scripts.Helpers
{
    public static class FindOrCreateComponents
    {
        public static T Component<T>(GameObject objectToOperateOn) where T : Component
        {
            T component = objectToOperateOn.GetComponent<T>();
            if(component == null)
            {
                component = objectToOperateOn.AddComponent<T>();
            }
            return component;
        }
    }
}
