﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets.Game._Scripts.Helpers
{
    public static class BOX_COLLIDER_VERTICES
    {
        private const int NUMBER_OF_VERTICES_IN_BOX_COLLIDER = 8;
        private static Vector3[]   directionsFromCenterToVetices = InitializeDirectionsFromCenter();
        private static VertexKey[] valuesOfVertexKeysEnum = (VertexKey[])Enum.GetValues(typeof(VertexKey));
        
        // when initializing vertices keys they should be continues vertices for example ( (-1,1) -> (1,1) -> (1,-1) -> (-1,-1))
        // and not ((-1,1) -> (-1,-1) -> (1,-1) -> (1,1)) 
        private static VertexKey[] frontKeysOfVertices = InitializeFrontVerticesKeys();
        private static VertexKey[] topKeysOfVertices   = InitializeTopVerticesKeys();

        private static Vector3[] InitializeDirectionsFromCenter()
        {
            const int NUMBER_OF_VERTICES = 8;
            Vector3[] arrayOfDirections = new Vector3[NUMBER_OF_VERTICES];
            arrayOfDirections[(int)VertexKey.FRONT_UP_RIGHT]     = new Vector3(1, 1, 1);
            arrayOfDirections[(int)VertexKey.BACK_UP_RIGHT]      = new Vector3(1, 1, -1);
            arrayOfDirections[(int)VertexKey.FRONT_BOTTOM_RIGHT] = new Vector3(1, -1, 1);
            arrayOfDirections[(int)VertexKey.BACK_BOTTOM_RIGHT]  = new Vector3(1, -1, -1);
            arrayOfDirections[(int)VertexKey.FRONT_UP_LEFT]      = new Vector3(-1, 1, 1);
            arrayOfDirections[(int)VertexKey.BACK_UP_LEFT]       = new Vector3(-1, 1, -1);
            arrayOfDirections[(int)VertexKey.FRONT_BOTTOM_LEFT]  = new Vector3(-1, -1, 1);
            arrayOfDirections[(int)VertexKey.BACK_BOTTOM_LEFT]   = new Vector3(-1, -1, -1);

            return arrayOfDirections;
        }
        private static VertexKey[] InitializeFrontVerticesKeys()
        {
            const int NUMBER_OF_VERTICES_IN_FRONT = 4;
            frontKeysOfVertices = new VertexKey[NUMBER_OF_VERTICES_IN_FRONT];
            frontKeysOfVertices[0] = VertexKey.FRONT_UP_RIGHT;
            frontKeysOfVertices[1] = VertexKey.FRONT_UP_LEFT;
            frontKeysOfVertices[2] = VertexKey.FRONT_BOTTOM_LEFT;
            frontKeysOfVertices[3] = VertexKey.FRONT_BOTTOM_RIGHT;
            return frontKeysOfVertices;
        }
        private static VertexKey[] InitializeTopVerticesKeys()
        {
            const int NUMBER_OF_VERTICES_IN_FRONT = 4;
            frontKeysOfVertices = new VertexKey[NUMBER_OF_VERTICES_IN_FRONT];
            frontKeysOfVertices[0] = VertexKey.BACK_UP_LEFT;
            frontKeysOfVertices[1] = VertexKey.BACK_UP_RIGHT;
            frontKeysOfVertices[2] = VertexKey.FRONT_UP_RIGHT;
            frontKeysOfVertices[3] = VertexKey.FRONT_UP_LEFT;
            return frontKeysOfVertices;
        }
        public static Vector3[] ConstructShapeOutOfSpecificVerticesKeys(VertexKey [] verticesKeys, Vector3[] arrayToTakeDataFrom)
        {
            Vector3[] verticesSpecificKeys = new Vector3[verticesKeys.Length];
            int indexSpecificVertex = 0;
            foreach (VertexKey specificVertex in verticesKeys)
            {
                verticesSpecificKeys[indexSpecificVertex] = arrayToTakeDataFrom[(int)specificVertex];
                verticesSpecificKeys[indexSpecificVertex] = arrayToTakeDataFrom[(int)specificVertex];
                indexSpecificVertex++;
            }
            return verticesSpecificKeys;
        }

        public static VertexKey[] FrontVerticesOfBoxCollider()
        {
            return frontKeysOfVertices;
        }
        public static VertexKey[] TopVerticesOfBoxCollider()
        {
            return topKeysOfVertices;
        }
        public enum VertexKey
        {
            FRONT_UP_RIGHT = 0,
            FRONT_UP_LEFT,
            BACK_UP_LEFT,
            BACK_UP_RIGHT,
            BACK_BOTTOM_RIGHT,
            BACK_BOTTOM_LEFT,
            FRONT_BOTTOM_LEFT,
            FRONT_BOTTOM_RIGHT
        }
        public static Vector3[] ConstructVerticesDirectionOfCollider(BoxCollider colliderToUpdate, VertexKey[] verticesKeys)
        {
            Vector3[] verticesDirectionOfWholeMapBox = VerticiesDirectionsFromCenterOfBoxCollider(colliderToUpdate);
            return ConstructShapeOutOfSpecificVerticesKeys(verticesKeys, verticesDirectionOfWholeMapBox);
        }
        public static Vector3 DirectionFromCenter(VertexKey vertexKey)
        {
            return directionsFromCenterToVetices[(int)vertexKey];
        }
        public static void AdjustVerticesPosition(Vector3[] verticesDirections, Vector3[] verticesPositions,BoxCollider collider, Vector3 directionMovement)
        {
            Vector3 newCenter = collider.transform.TransformPoint(collider.center) + directionMovement;
            for (int indexVertex = 0; indexVertex < verticesDirections.Length; indexVertex++)
            {
                verticesPositions[indexVertex] = newCenter + verticesDirections[indexVertex];
            }
        }
        public static Vector3[] VerticesPosition(Vector3[] verticesDirections, BoxCollider collider)
        {
            Vector3 positionToAddDirection = collider.transform.TransformPoint(collider.center);
            Vector3[] verticesPositions = new Vector3[verticesDirections.Length];
            for (int indexVertex = 0; indexVertex < verticesDirections.Length; indexVertex++)
            {
                verticesPositions[indexVertex] = positionToAddDirection + verticesDirections[indexVertex];
            }
            return verticesPositions;
        }
        public static Vector3[] VerticiesDirectionsFromCenterOfBoxCollider(BoxCollider boxCollider)
        {
            // rounds the boxCollider before using, when getting the vectors that composite the collider unity will return rounded values -> 1.71586 -> 1.7
            Vector3 sizeOfColliderRounded = boxCollider.size;
            boxCollider.size              = sizeOfColliderRounded;

            Vector3[] verticiesOfBoxCollider = new Vector3[NUMBER_OF_VERTICES_IN_BOX_COLLIDER];

            Vector3 boxColliderCenter   = boxCollider.center;
            Vector3 extentOfBoxCollider = boxCollider.size * 0.5f;
            
            foreach (VertexKey vertexKey in valuesOfVertexKeysEnum)
            {
                InitializeVertexDirectionFromCenter(boxCollider.transform, verticiesOfBoxCollider,
                                                    extentOfBoxCollider, boxColliderCenter, vertexKey);
            }
            return verticiesOfBoxCollider;
        }
        private static void InitializeVertexDirectionFromCenter(Transform boxCollidersTransform, Vector3[] verticiesOfBoxCollider, Vector3 extentOfBoxCollider,
                                                                Vector3 boxColliderCenter, VertexKey positionToInitialize)
        {
            Vector3 directionDependingOnVertexKey = DirectionFromCenter(positionToInitialize);
            Vector3 scaleOfObject = boxCollidersTransform.lossyScale;
            directionDependingOnVertexKey.Scale(scaleOfObject);
            Vector3 extentMultipliedByScale = MultiplyVectorComponentsByValuesGiven(extentOfBoxCollider, directionDependingOnVertexKey);
            verticiesOfBoxCollider[(int)positionToInitialize] = Quaternion.Euler(boxCollidersTransform.eulerAngles) * extentMultipliedByScale;
        }
        private static Vector3 MultiplyVectorComponentsByValuesGiven(Vector3 vectorToMultiply, Vector3 vectorMultipication)
        {
            return new Vector3(vectorToMultiply.x * vectorMultipication.x, vectorToMultiply.y * vectorMultipication.y, vectorToMultiply.z * vectorMultipication.z);
        }
    }
}
