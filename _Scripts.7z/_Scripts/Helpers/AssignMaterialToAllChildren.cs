﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AssignMaterialToAllChildren : MonoBehaviour
{
    [SerializeField]
    public Material materialToAssignToChilds;

    void Start()
    {
        Renderer[] renderedChilds = transform.GetComponentsInChildren<Renderer>();
        foreach (Renderer renderer in renderedChilds)
        {
            renderer.sharedMaterial = materialToAssignToChilds;
        }
    }
}
