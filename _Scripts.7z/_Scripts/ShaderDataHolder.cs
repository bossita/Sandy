﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShaderDataHolder
{
    public Shader                ShaderUsed         { get; private set; }
    public int                   AmountOfProperties { get; private set; }
    public Material              SharedMaterial     { get; private set; }
    public List<ColorProperty>   ColorsProperties   { get; private set; }
    public List<FloatProperty>   FloatsProperties   { get; private set; }
    public List<TextureProperty> TextureProperties  { get; private set; }

    public ShaderDataHolder(Material sharedMaterialUsed)
    {
        SharedMaterial = sharedMaterialUsed;
        Initialization(sharedMaterialUsed.shader);
    }
    public ShaderDataHolder(ShaderDataHolder other, Material matUsed)
    {

    }
    private void Initialization(Shader shaderUsed)
    {
        this.ColorsProperties = new List<ColorProperty>();
        this.FloatsProperties = new List<FloatProperty>();
        this.TextureProperties = new List<TextureProperty>();
        AmountOfProperties = 0;
        ShaderUsed = shaderUsed;
    }
    

    public void AddColorProperty(string propertyName, Color colorVariable)
    {
        ColorsProperties.Add(new ColorProperty(colorVariable, propertyName));
        AmountOfProperties++;
    }
    public void AddFloatProperty(string propertyName, float floatVariable)
    {
        FloatsProperties.Add(new FloatProperty(floatVariable, propertyName));
        AmountOfProperties++;
    }
    public void AddTextureProperty(string propertyName, Texture textureVariable)
    {
        TextureProperties.Add(new TextureProperty(textureVariable, propertyName));
        AmountOfProperties++;
    }
    public bool HasLessOrEqualAmountOfProperties(ShaderDataHolder other)
    {
        bool thisPropertiesCanBePutInOther = false;
        if (this.AmountOfProperties <= other.AmountOfProperties)
        {
            if(FirstListHasLessThanSecondList(this.ColorsProperties, other.ColorsProperties))
            {
                if (FirstListHasLessThanSecondList(this.FloatsProperties, other.FloatsProperties))
                {
                    if(FirstListHasLessThanSecondList(this.TextureProperties, other.TextureProperties))
                    {
                        thisPropertiesCanBePutInOther = true;
                    }
                }
            }
        }
        return thisPropertiesCanBePutInOther;
    }
    private bool FirstListHasLessThanSecondList <T>(List<T> firstList, List<T> secondList)
    {
        return firstList.Count <= secondList.Count;
    }
    public override string ToString()
    {
        string allFloats = "floats : ";
        FloatsProperties.ForEach((floatVar) => allFloats += floatVar.floatName + " ");
        string allColors = "colors : ";
        ColorsProperties.ForEach((colorVar) => allColors += colorVar.colorName + " ");
        string allTextures = "textures : ";
        FloatsProperties.ForEach((textureVar) => allTextures += textureVar.floatName + " ");
        return allFloats + allColors + allTextures;
    }
}
// maybe change to struct later
public class ColorProperty 
{
    public Color colorVariable;
    public string colorName;

    public ColorProperty(Color colorVariable, string colorName)
    {
        this.colorVariable = colorVariable;
        this.colorName = colorName;
    }
}
public class FloatProperty
{
    public float floatVariable;
    public string floatName;
    public FloatProperty(float floatVariable, string floatName)
    {
        this.floatVariable = floatVariable;
        this.floatName = floatName;
    }
}
public class TextureProperty
{
    public Texture textureVariable;
    public string textureName;
    public TextureProperty(Texture textureVariable, string textureName)
    {
        this.textureVariable = textureVariable;
        this.textureName = textureName;
    }
}
