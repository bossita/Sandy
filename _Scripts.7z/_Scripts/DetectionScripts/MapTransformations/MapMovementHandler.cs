using Assets.Game._Scripts.DetectionScripts.MapTransformations;
using System.Collections;
using UnityEngine;
using Assets.Game._Scripts.Helpers;

public class MapMovementHandler : MapAction
{

    #region inspector public variables
    [Header("Variables")]
    private float AnimationSpan          = 5.0f;
    private float AnimationSpeed         = 2.0f;
    private float AnimationMovementSpeed = 2.0f;
    private float KickFactor             = 150.0f;
    private float FactorMovement         = 1.0f;
    private float precentageKickBoost    = 0.1f;
    private float FactorByScale          = 0.25f;
    #endregion

    public bool MapMovementFunctionalityAccoured { get; private set; }

    #region const variables
    private const int LAYER_OF_MAP             = 10;
    private const int LAYER_OF_VISIBILITY_AREA = 11;
    private const int FINISHED_LERPING         = 1;
    #endregion
    private Bounds  mapsBounds;
    private Vector3 mapInitialPosition;

    private Vector3 targetDirection;
    private Vector3 currentMovementDirection;
    private float   precentageComplete;
    private bool    didStartAnotherAction;
    private BoxCollider virtualSpaceBoxCollider;
    private bool movementOccured;
    private Vector3 previousMapPosition;
    private MonoBehaviour CoroutineMaker;
    private TransformationsSharedData transformationsSharedData;
    public MapMovementHandler(TransformationsSharedData transformationsSharedData, MonoBehaviour monoScript)
    {
        this.CoroutineMaker = monoScript;
        this.transformationsSharedData = transformationsSharedData;
        InitializingMovementVariables();
        mapsBounds = transformationsSharedData.mapCollider.bounds;

        for (int index = 0; index < transformationsSharedData.verticesPositionVisibilityArea.Length; index++)
        {
            Debug.DrawRay(transformationsSharedData.verticesPositionVisibilityArea[index], Vector3.up * 10000f, Color.cyan, 100f);
        }
        for (int index = 0; index < transformationsSharedData.verticesPositionWholeMap.Length; index++)
        {
            Debug.DrawRay(transformationsSharedData.verticesPositionWholeMap[index], Vector3.up * 10000f, Color.yellow, 100f);
        }
        InitializeVirtualBoxCollider();
    }

    //private void Start()
    //{
    //    InitializingMovementVariables();
    //    mapsBounds = mapCollider.bounds;
        
    //    for (int index = 0; index < verticesPositionVisibilityArea.Length; index++)
    //    {
    //        Debug.DrawRay(verticesPositionVisibilityArea[index], Vector3.up * 10f, Color.cyan, 100f);
    //    }
    //    InitializeVirtualBoxCollider();
    //}
    // the map boxCollider adjustments accours on awake function thus,
    // the initialization of virtualSpaceBoxCollider should always be called on Start method
    private void InitializeVirtualBoxCollider()
    {
        virtualSpaceBoxCollider = transformationsSharedData.SharedMap.gameObject.AddComponent<BoxCollider>();
        virtualSpaceBoxCollider.center = transformationsSharedData.mapCollider.center;
        virtualSpaceBoxCollider.size   = transformationsSharedData.mapCollider.size;
        virtualSpaceBoxCollider.enabled = false;
    }
    private void InitializingMovementVariables()
    {
        mapInitialPosition       = transformationsSharedData.SharedMap.position;
        targetDirection          = Vector3.zero;
        currentMovementDirection = Vector3.zero;
        didStartAnotherAction    = false;
    }
    public Vector3 DirectionControllerInput()
    {
        // currently movement is taken place only with right controller
        return ControllerInputsHolder.DirectionMovementByRightJoysticMovement();
    }
    
    public override bool IsActionOccouring()
    {
        return DirectionControllerInput() != Vector3.zero;
    }

    public override void OnActionEnable()
    {
        MapMovementFunctionalityAccoured = true;
        if (!movementOccured)
        {
            CoroutineMaker.StartCoroutine(MoveUntilStoppedPinching());
            movementOccured = true;
        }
    }
    public override void OnActionDisable()
    {
        MapMovementFunctionalityAccoured = false;
        if(previousMapPosition != transformationsSharedData.SharedMap.position)
        {
            BOX_COLLIDER_VERTICES.AdjustVerticesPosition(transformationsSharedData.verticesDirectionOfWholeMap, transformationsSharedData.verticesPositionWholeMap, transformationsSharedData.mapCollider, Vector3.zero);
            previousMapPosition = transformationsSharedData.SharedMap.position;
        }
    }

    private IEnumerator MoveUntilGotToDestinationOrInterapted(float timeStartedMovementPush)
    {
        Debug.Log("moving the map");
        while (precentageComplete < FINISHED_LERPING && !didStartAnotherAction) 
        {
            float timeSinceStarted = Time.time - timeStartedMovementPush;
            precentageComplete = precentageKickBoost + timeSinceStarted / AnimationSpan * AnimationMovementSpeed;
            //precentageComplete = Mathf.Min(precentageComplete, FINISHED_LERPING);
            currentMovementDirection = Vector3.Lerp(currentMovementDirection, targetDirection, precentageComplete);
            transformationsSharedData.SharedMap.position = mapInitialPosition + currentMovementDirection;
            yield return null;
        }
        Debug.Log("..............");
        Debug.Log("ended movement");
        //instead of clamping the precntageComplete in the while changing it to the target position.
        if (precentageComplete > FINISHED_LERPING)
        {
            transformationsSharedData.SharedMap.position = mapInitialPosition + targetDirection;
        }
        targetDirection          = Vector3.zero;
        precentageComplete       = 0.0f;
        mapInitialPosition       = transformationsSharedData.SharedMap.position;
        //animationMovementSpeed   = DEFAULT_SPEED;
    }

    private Vector3 MovementToApplyToMap(Vector3 directionMovement)
    {
        // dont move the map in the y direction
        directionMovement.y = 0;
        Vector3 xDirectionMovement = new Vector3(directionMovement.x, 0, 0);
        Vector3 zDirectionMovement = new Vector3(0, 0, directionMovement.z);
        Vector3 movementToApplyToMap = ClampWithinBorders(xDirectionMovement);/*SecondGenerationClampWithinBorders(xDirectionMovement);*/
        movementToApplyToMap += ClampWithinBorders(zDirectionMovement);/*SecondGenerationClampWithinBorders(zDirectionMovement);*/
        //Debug.Log("final movement" + movementToApplyToMap + " " + (movementToApplyToMap != Vector3.zero));
        return movementToApplyToMap;
    }

    //private Vector3 SecondGenerationClampWithinBorders(Vector3 directionMovement)
    //{
    //    BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, Map.transform.position);
    //    Vector3 minimalMovementToStayInBorders = directionMovement;
    //    for(int indexMapPoint = 0;indexMapPoint < verticesPositionWholeMap.Length;indexMapPoint++)
    //    {
    //        Vector3 vertexMapPos = verticesPositionWholeMap[indexMapPoint];
    //        //vertexMapPos.x = CutDoubleValues(vertexMapPos.x);
    //        //vertexMapPos.z = CutDoubleValues(vertexMapPos.z);

    //        // new Position checked V
    //        Vector3 newPositionOfMapPoint = vertexMapPos + directionMovement;
    //        //Debug.DrawRay(newPositionOfMapPoint, Vector3.up * 100f, Color.grey, 10f);
    //        //Debug.DrawRay(vertexMapPos, directionMovement * 1000f, Color.blue, 10f);
    //        for (int indexFirstVisibilityPoint = 0, indexSecondVisibilityPoint = verticesPositionVisibilityArea.Length - 1;
    //                 indexFirstVisibilityPoint < verticesPositionVisibilityArea.Length;
    //                 indexSecondVisibilityPoint = indexFirstVisibilityPoint++)
    //        {
    //            Vector3 firstVisibilityPoint  = verticesPositionVisibilityArea[indexFirstVisibilityPoint];
    //            //firstVisibilityPoint.x = CutDoubleValues(firstVisibilityPoint.x);
    //            //firstVisibilityPoint.z = CutDoubleValues(firstVisibilityPoint.z);
    //            Vector3 secondVisibilityPoint = verticesPositionVisibilityArea[indexSecondVisibilityPoint];
    //            //Debug.DrawLine(firstVisibilityPoint, (secondVisibilityPoint - firstVisibilityPoint) * 1000f, Color.yellow, 10f);
    //            //Debug.DrawLine(secondVisibilityPoint, (firstVisibilityPoint - secondVisibilityPoint) * 1000f, Color.yellow, 10f);

    //            try
    //            {
    //                Vector3 intersectionPoint = TransformationsMathHelpers.FindIntersectionXZPlane(vertexMapPos, newPositionOfMapPoint,
    //                                                                                                firstVisibilityPoint, secondVisibilityPoint);
                    
    //                //Debug.DrawRay(intersectionPoint, Vector3.up * 100f, Color.white, 10f);
    //                if(TransformationsMathHelpers.IsWithinDirectionMagnitude(vertexMapPos, directionMovement, intersectionPoint))
    //                {
    //                    Debug.Log("fixing out of range...");
    //                    Vector3 newDirectionToCheck = intersectionPoint - vertexMapPos;

    //                    if (minimalMovementToStayInBorders.magnitude > newDirectionToCheck.magnitude)
    //                    {
    //                        //Debug.DrawRay(firstVisibilityPoint, Vector3.down * 30f, Color.red, 10f);
    //                        //Debug.DrawRay(secondVisibilityPoint, Vector3.down * 30f, Color.red, 10f);
    //                        minimalMovementToStayInBorders = newDirectionToCheck;
    //                        if (OutOfRangeHelper.ApproximetlyEqual(firstVisibilityPoint.x, vertexMapPos.x + newDirectionToCheck.x))
    //                        {
    //                            minimalMovementToStayInBorders.x = 0;
    //                        }
    //                        if (OutOfRangeHelper.ApproximetlyEqual(firstVisibilityPoint.z, vertexMapPos.z + newDirectionToCheck.z))
    //                        {
    //                            minimalMovementToStayInBorders.z = 0;
    //                        }
    //                    }
    //                }
    //            }
    //            catch(LinesAreParallelException)
    //            {
    //            }

    //        }
    //    }
    //    return minimalMovementToStayInBorders;
    //}
    private Vector3 ClampWithinBorders(Vector3 directionMovement)
    {
        Vector3 movementToApplyToMap = directionMovement;
        Vector3 mapDesiredPosition = transformationsSharedData.SharedMap.transform.position + movementToApplyToMap;
        int layerMask = 1 << LAYER_OF_MAP;
        // TODO: could be risky if later two actions could happen simutaniously
        BOX_COLLIDER_VERTICES.AdjustVerticesPosition(transformationsSharedData.verticesDirectionOfWholeMap, transformationsSharedData.verticesPositionWholeMap, transformationsSharedData.mapCollider, movementToApplyToMap);
        bool shouldTakeMaxDistanceFromOutOfRange = transformationsSharedData.SharedMap.rotation != transformationsSharedData.SharedVisibilityArea.rotation;
        bool directionOffsetAsDirectionMovement  = true;
        for (int index = 0; index < transformationsSharedData.verticesPositionWholeMap.Length; index++)
        {
            Debug.DrawRay(transformationsSharedData.verticesPositionWholeMap[index], Vector3.up * 100f, Color.red, 10f);
        }
        Vector3[] smallerVolumePositions = transformationsSharedData.verticesPositionVisibilityArea;
        Vector3[] largerVolumePositions  = transformationsSharedData.verticesPositionWholeMap;
        BoxCollider largerCollider       = transformationsSharedData.mapCollider;
        Vector3 directionToCalculateOffset = directionMovement;
        //Debug.Log(sizeOfVisibilityArea.magnitude + " " + sizeOfMap.magnitude);
        if (TransformationsMathHelpers.AreaOfVisiblityBiggerThanMapArea(transformationsSharedData.visibilityAreaCollider, transformationsSharedData.mapCollider))
        {
            largerCollider = transformationsSharedData.visibilityAreaCollider;
            smallerVolumePositions = transformationsSharedData.verticesPositionWholeMap;
            largerVolumePositions = transformationsSharedData.verticesPositionVisibilityArea;
            layerMask = 1 << LAYER_OF_VISIBILITY_AREA;
            directionToCalculateOffset = -directionToCalculateOffset;
            directionOffsetAsDirectionMovement = false;
            Debug.Log("verticesPositionWholeMap is the smaller");
        }
        Vector3 pointFarthestFromCollider;
        if (OutOfRangeHelper.TryFindingTheFarthestPointOutOfRange(smallerVolumePositions, largerVolumePositions,
                                                                  largerCollider, shouldTakeMaxDistanceFromOutOfRange,
                                                                  out pointFarthestFromCollider))
        {
            virtualSpaceBoxCollider.enabled = true;
            float directionDividerByScale = transformationsSharedData.SharedMap.localScale.magnitude / Vector3.one.magnitude;
            virtualSpaceBoxCollider.center = transformationsSharedData.mapCollider.center + (directionMovement / directionDividerByScale);
            virtualSpaceBoxCollider.size = transformationsSharedData.mapCollider.size;
            transformationsSharedData.mapCollider.enabled = false;
            Debug.DrawRay(pointFarthestFromCollider, directionMovement, Color.red, 8f);
            RaycastHit hitInfo;
            if (Physics.Raycast(pointFarthestFromCollider, directionToCalculateOffset, out hitInfo, directionToCalculateOffset.magnitude, layerMask))
            {
                Debug.Log("rayCasting");
                Vector3 impactPoint = hitInfo.point;
                Debug.DrawLine(pointFarthestFromCollider, impactPoint, Color.white, 10f);
                Vector3 directionOffsetFromBeingWithinArea = impactPoint - pointFarthestFromCollider;
                if (directionOffsetAsDirectionMovement)
                {
                    movementToApplyToMap = movementToApplyToMap - directionOffsetFromBeingWithinArea;
                }
                else
                {
                    movementToApplyToMap = movementToApplyToMap + directionOffsetFromBeingWithinArea;
                }
            }
            else
            {
                movementToApplyToMap = Vector3.zero;
            }
            transformationsSharedData.mapCollider.enabled = true;
            virtualSpaceBoxCollider.enabled = false;
        }
        virtualSpaceBoxCollider.enabled = false;
        //Debug.Log("movementToApplyToMap" + movementToApplyToMap);
        return movementToApplyToMap;
    }

    public IEnumerator MoveUntilStoppedPinching()
    {
        float   timeSinceStartedMoving  = Time.time;
        Vector3 movementToApplyToMap    = Vector3.zero;
        while (MapMovementFunctionalityAccoured)
        {
            Debug.Log("moving it..");
            didStartAnotherAction = true;
            Vector3 directionMovement = DirectionControllerInput();
            transformationsSharedData.SharedMap.position   += MovementToApplyToMap(directionMovement * FactorMovement * Time.deltaTime);
            #region testing if not moved out of range
            //Vector3[] smallerVolumePositions = verticesPositionVisibilityArea;
            //Vector3[] largerVolumePositions = verticesPositionWholeMap;
            //if (TransformationsMathHelpers.AreaOfVisiblityBiggerThanMapArea(visibilityAreaCollider, mapCollider))
            //{
            //    smallerVolumePositions = verticesPositionWholeMap;
            //    largerVolumePositions  = verticesPositionVisibilityArea;
            //}
            //bool shouldTakeMaxDistanceFromOutOfRange = false;
            //Vector3 pointFarthestFromCollider;
            //BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, Map.transform.position);

            //if (TryFindingTheFarthestPointOutOfRange(smallerVolumePositions, largerVolumePositions,
            //                                                    shouldTakeMaxDistanceFromOutOfRange, out pointFarthestFromCollider))
            //{
            //    if (TryFindingTheFarthestPointOutOfRange(smallerVolumePositions, largerVolumePositions,
            //                                                    shouldTakeMaxDistanceFromOutOfRange, out pointFarthestFromCollider))
            //    {
            //            Debug.LogWarning("wtf its already out of range");
            //    }
            //}
            #endregion
            yield return null;
        }
        mapInitialPosition = transformationsSharedData.SharedMap.position;
        movementOccured = false;
        //ConstructInertiaKickAfterMovement(previousDirection, firstPositionMovement, timeSinceStartedMoving, movementToApplyToMap);
    }
    // inertia -> might use it later, currently not using it.
    //private void ConstructInertiaKickAfterMovement(Vector3 endingPosition, Vector3 firstPosition, float timeSinceStartedMoving,
    //                                                                                              Vector3 lastMovementApplied)
    //{
    //    float   timeStartedMovementPush = Time.time;
    //    Vector3 deltaPosition  = endingPosition - firstPosition;
    //    float   deltaTime      = timeStartedMovementPush - timeSinceStartedMoving;
    //    Vector3 velocityFactor = (deltaPosition) / (deltaTime);
    //    // TODO: add a thrashhold later -> if velocityFactor.magnitude > some value (not important right now)
    //    targetDirection = lastMovementApplied * KickFactor * (Map.transform.localScale.magnitude * FactorByScale) * (1 + velocityFactor.magnitude) * Time.deltaTime;
    //    targetDirection = MovementToApplyToMap(targetDirection);
    //    if (targetDirection != Vector3.zero)
    //    {
    //        didStartAnotherAction = false;
    //        StartCoroutine(MoveUntilGotToDestinationOrInterapted(timeStartedMovementPush));
    //    }
    //}
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      