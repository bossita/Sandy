﻿using System.Collections;
using UnityEngine;

namespace Assets.Game._Scripts.DetectionScripts.MapTransformations
{
    public class MapRotationHandler : MapAction
    {
        private float RotationMultiplier = 35.0f;

        public bool RotationFunctionalityAccoured { get; private set; }

        private const float CLOCK_WISE_MULTIPLIER = 1.0f;
        private const float COUNTER_CLOCK_WISE_MULTIPLIER = -1.0f;
        private const float DEFUALT_CLOCK_DIRECTION = 0.0f;

        private Coroutine rotationCoroutine;
        private Vector3 rotationPivot;
        private Vector3 previousRotation;
        private TransformationsSharedData transformationsSharedData;
        private MonoBehaviour monoScript;
        public MapRotationHandler(TransformationsSharedData transformationsSharedData, MonoBehaviour monoScript)
        {
            this.transformationsSharedData = transformationsSharedData;
            this.monoScript = monoScript;
            rotationPivot = transformationsSharedData.SharedVisibilityArea.position;
            previousRotation = transformationsSharedData.SharedMap.rotation.eulerAngles;
        }
        public bool IsRotatingClockWise()
        {
            return ClockWiseMovement() != 0.0f;
        }
        public bool IsRotatingCounterClockWise()
        {
            return CounterClockWiseMovement() != 0.0f;
        }
        private float ClockWiseMovement()
        {
            return ControllerInputsHolder.RTMovement();
        }
        private float CounterClockWiseMovement()
        {
            return ControllerInputsHolder.LTMovement();
        }
        public override bool IsActionOccouring()
        {
            return IsRotatingClockWise() || IsRotatingCounterClockWise();
        }
        public float ClockWiseDirection()
        {
            //float clockDirection = DEFUALT_CLOCK_DIRECTION;
            //if (IsRotatingClockWise())
            //{
            //    clockDirection = CLOCK_WISE_MULTIPLIER;
            //}
            //else if (IsRotatingCounterClockWise())
            //{
            //    clockDirection = COUNTER_CLOCK_WISE_MULTIPLIER;
            //}
            float clockDirection = ClockWiseMovement();
            if(clockDirection == 0.0f)
            {
                clockDirection = CounterClockWiseMovement();
            }
            return clockDirection;
        }
        public IEnumerator RotateUntilStoppedPinching()
        {
            while (RotationFunctionalityAccoured)
            {
                float clockWiseDirection = ClockWiseDirection();
                if (clockWiseDirection != DEFUALT_CLOCK_DIRECTION)
                {
                    transformationsSharedData.SharedMap.RotateAround(rotationPivot, Vector3.up, Time.deltaTime * clockWiseDirection * RotationMultiplier);
                    Debug.DrawRay(rotationPivot, Vector3.up * 10f, Color.red, 10f);
                }
                yield return null;
            }
            rotationCoroutine = null;
        }
        public override void OnActionEnable()
        {
            RotationFunctionalityAccoured = true;
            if (rotationCoroutine == null)
            {
                rotationCoroutine = monoScript.StartCoroutine(RotateUntilStoppedPinching());
            }
        }
        public override void OnActionDisable()
        {
            RotationFunctionalityAccoured = false;
            if (transformationsSharedData.SharedMap.rotation.eulerAngles != previousRotation)
            {
                transformationsSharedData.UpdateVerticesOfMapCollider();
                previousRotation = transformationsSharedData.SharedMap.rotation.eulerAngles;
            }
        }
    }
}
