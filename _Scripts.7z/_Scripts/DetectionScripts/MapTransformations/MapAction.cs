﻿using Assets.Game._Scripts.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
namespace Assets.Game._Scripts.DetectionScripts.MapTransformations
{
    public abstract class MapAction : /*MonoBehaviour,*/ IAction
    {
        //[SerializeField]
        //private Transform MyVisibilityAreaTrans;

        //[SerializeField]
        //private Transform MyMapTrans;

        //private static bool didInitializeSharedVariables = false;

        //protected static Transform SharedMap;
        //protected static Transform SharedVisibilityArea;
        //protected static BoxCollider mapCollider;
        //protected static BoxCollider visibilityAreaCollider;
        //protected static BOX_COLLIDER_VERTICES.VertexKey[] topVertices = BOX_COLLIDER_VERTICES.TopVerticesOfBoxCollider();
        //protected static Vector3[] verticesDirectionOfWholeMap;
        //protected static Vector3[] verticesPositionWholeMap;
        //protected static Vector3[] verticesPositionVisibilityArea;

        //public MapAction(Transform MyVisibilityAreaTrans, Transform MyMapTrans)
        //{
        //    //Debug.Log("awake at " + name);
        //    if (!didInitializeSharedVariables)
        //    {
        //        SharedMap = MyMapTrans;
        //        SharedVisibilityArea = MyVisibilityAreaTrans;

        //        mapCollider            = FindOrCreateComponents.Component<BoxCollider>(SharedMap.gameObject);
        //        visibilityAreaCollider = FindOrCreateComponents.Component<BoxCollider>(SharedVisibilityArea.gameObject);
        //        Vector3 mapPosition    = SharedMap.position;
        //        Vector3 visibilityAreaPosition = SharedVisibilityArea.position;

        //        verticesDirectionOfWholeMap = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(mapCollider, topVertices);
        //        verticesPositionWholeMap    = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirectionOfWholeMap, mapPosition);

        //        // assuming the scale of the visibility area wont change mid game, thus not using it as private
        //        Vector3[] verticesDirectionOfVisibilityArea = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(visibilityAreaCollider,
        //                                                                                                                    topVertices);
        //        verticesPositionVisibilityArea = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirectionOfVisibilityArea, visibilityAreaPosition);
        //        didInitializeSharedVariables = true;
        //    }
        //    //else
        //    //{
        //    //    CheckForActionsUsingDifferentVariables();
        //    //}
        //}
        //private void CheckForActionsUsingDifferentVariables()
        //{
        //    const string format = "the object {0} is using different {1} object than other {1} action";
        //    string objectTypeName = "";
        //    if(SharedMap != MyMapTrans)
        //    {
        //        objectTypeName = "map ";
        //        Debug.LogWarningFormat(format, this.name, objectTypeName);
        //    }
        //    if (SharedVisibilityArea != MyVisibilityAreaTrans)
        //    {
        //        objectTypeName = "visibility area ";
        //        Debug.LogWarningFormat(format, this.name, objectTypeName);
        //    }
           
        //}
        //protected void UpdateVerticesOfMapCollider()
        //{
        //    // TODO: change the Construct to adjust later
        //    verticesDirectionOfWholeMap = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(mapCollider, topVertices);
        //    BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, SharedMap.transform.position);
        //}
       
        public abstract void OnActionDisable();
        public abstract void OnActionEnable();
        public abstract bool IsActionOccouring();
        //#region getters
        //public Transform MapBeingUsed()
        //{
        //    return MyMapTrans;
        //}
        //public Transform VisibilityAreaBeingUsed()
        //{
        //    return MyVisibilityAreaTrans;
        //}
        //#endregion
    }
    /*
     *  public abstract class MapAction : MonoBehaviour, IAction
    {
        [SerializeField]
        private Transform MyVisibilityAreaTrans;

        [SerializeField]
        private Transform MyMapTrans;

        private static bool didInitializeSharedVariables = false;

        protected static Transform SharedMap;
        protected static Transform SharedVisibilityArea;
        protected static BoxCollider mapCollider;
        protected static BoxCollider visibilityAreaCollider;
        protected static BOX_COLLIDER_VERTICES.VertexKey[] topVertices = BOX_COLLIDER_VERTICES.TopVerticesOfBoxCollider();
        protected static Vector3[] verticesDirectionOfWholeMap;
        protected static Vector3[] verticesPositionWholeMap;
        protected static Vector3[] verticesPositionVisibilityArea;

        public void Awake()
        {
            //Debug.Log("awake at " + name);
            if (!didInitializeSharedVariables)
            {
                SharedMap = MyMapTrans;
                SharedVisibilityArea = MyVisibilityAreaTrans;

                mapCollider            = FindOrCreateComponents.Component<BoxCollider>(SharedMap.gameObject);
                visibilityAreaCollider = FindOrCreateComponents.Component<BoxCollider>(SharedVisibilityArea.gameObject);
                Vector3 mapPosition    = SharedMap.position;
                Vector3 visibilityAreaPosition = SharedVisibilityArea.position;

                verticesDirectionOfWholeMap = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(mapCollider, topVertices);
                verticesPositionWholeMap    = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirectionOfWholeMap, mapPosition);

                // assuming the scale of the visibility area wont change mid game, thus not using it as private
                Vector3[] verticesDirectionOfVisibilityArea = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(visibilityAreaCollider,
                                                                                                                            topVertices);
                verticesPositionVisibilityArea = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirectionOfVisibilityArea, visibilityAreaPosition);
                didInitializeSharedVariables = true;
            }
            else
            {
                CheckForActionsUsingDifferentVariables();
            }
        }
        private void CheckForActionsUsingDifferentVariables()
        {
            const string format = "the object {0} is using different {1} object than other {1} action";
            string objectTypeName = "";
            if(SharedMap != MyMapTrans)
            {
                objectTypeName = "map ";
                Debug.LogWarningFormat(format, this.name, objectTypeName);
            }
            if (SharedVisibilityArea != MyVisibilityAreaTrans)
            {
                objectTypeName = "visibility area ";
                Debug.LogWarningFormat(format, this.name, objectTypeName);
            }
           
        }
        protected void UpdateVerticesOfMapCollider()
        {
            // TODO: change the Construct to adjust later
            verticesDirectionOfWholeMap = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(mapCollider, topVertices);
            BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, SharedMap.transform.position);
        }
       
        public abstract void OnActionDisable();
        public abstract void OnActionEnable();
        public abstract bool IsActionAccouring();
        #region getters
        public Transform MapBeingUsed()
        {
            return MyMapTrans;
        }
        public Transform VisibilityAreaBeingUsed()
        {
            return MyVisibilityAreaTrans;
        }
        #endregion
    }
    */
}
