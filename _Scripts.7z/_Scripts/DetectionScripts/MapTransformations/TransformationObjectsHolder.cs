﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Game._Scripts.Helpers
{
    public static class TransformationObjectsHolder
    {
        public static Transform Map { get; set; }
        public static Transform VisibilityArea { get; set; }
    }
}
