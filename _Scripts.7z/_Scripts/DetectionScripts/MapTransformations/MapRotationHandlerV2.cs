﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapRotationHandlerV2 : MonoBehaviour
{
    //    [Header("Variables")]
    //    public float RotationMultiplier  = 5.0f;

    //    public bool RotationFunctionalityAccoured { get; private set; }

    //    private const float CLOCK_WISE_MULTIPLIER = 1.0f;
    //    private const float COUNTER_CLOCK_WISE_MULTIPLIER = -1.0f;
    //    private const float DEFUALT_CLOCK_DIRECTION = 0.0f;

    //    private Coroutine rotationCoroutine;
    //    private Vector3 rotationPivot;
    //    private Vector3 previousRotation;
    //    private new void Awake()
    //    {
    //        base.Awake();
    //        rotationPivot = SharedVisibilityArea.position;
    //        previousRotation = SharedMap.rotation.eulerAngles;
    //    }
    //    public bool IsRotatingClockWise()
    //    {
    //        return ControllerInputsHolder.RBButtonPush();
    //    }
    //    public bool IsRotatingCounterClockWise()
    //    {
    //        return ControllerInputsHolder.LBButtonPush();
    //    }
    //    public override bool IsActionOccouring()
    //    {
    //        return IsRotatingClockWise() || IsRotatingCounterClockWise();
    //    }
    //    public float ClockWiseDirection()
    //    {
    //        float clockDirection = DEFUALT_CLOCK_DIRECTION;
    //        if (IsRotatingClockWise())
    //        {
    //            clockDirection = CLOCK_WISE_MULTIPLIER;
    //        }
    //        else if (IsRotatingCounterClockWise())
    //        {
    //            clockDirection = COUNTER_CLOCK_WISE_MULTIPLIER;
    //        }
    //        return clockDirection;
    //    }
    //    public IEnumerator RotateUntilStoppedPinching()
    //    {
    //        while (RotationFunctionalityAccoured)
    //        {
    //            float clockWiseDirection = ClockWiseDirection();
    //            if (clockWiseDirection != DEFUALT_CLOCK_DIRECTION)
    //            {
    //                SharedMap.RotateAround(rotationPivot, Vector3.up, Time.deltaTime * clockWiseDirection * RotationMultiplier);
    //                Debug.DrawRay(rotationPivot, Vector3.up * 10f, Color.red, 10f);
    //            }
    //            yield return null;
    //        }
    //        rotationCoroutine = null;
    //    }
    //    public override void OnActionEnable()
    //    {
    //        RotationFunctionalityAccoured = true;
    //        if (rotationCoroutine == null)
    //        {
    //            rotationCoroutine = StartCoroutine(RotateUntilStoppedPinching());
    //        }
    //    }
    //    public override void OnActionDisable()
    //    {
    //        RotationFunctionalityAccoured = false;
    //        if(SharedMap.rotation.eulerAngles != previousRotation)
    //        {
    //            UpdateVerticesOfMapCollider();
    //            previousRotation = SharedMap.rotation.eulerAngles;
    //        }
    //    }
}
