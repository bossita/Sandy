﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapZoomHandlerV2 : MonoBehaviour
{
    //[Header("Variables")]
    //public float  FactorScalingByTime = 20f;
    //public float  AnimationSpan       = 5.0f;
    //public float  AnimationSpeed      = 2.0f;
    //public float  SpeedMultiplication = 1.2f;
    //public float  MapZoomMultiplier   = 0.6f;

    //[Header("Scale limits")]
    //public  Vector3 MAX_SCALE_MAP = new Vector3(5.0f, 5.0f, 5.0f);
    //public  Vector3 MIN_SCALE_MAP = new Vector3(1.0f, 1.0f, 1.0f);

    //public bool ZoomingFunctionalityAccoured { get; private set; }

    //private const float DEFAULT_SCALE_MULTIPLIER = 1.0f;
    //private const int   MAX_NUMBER_OF_MOVEMENTS = 2;

    //private float timeStartedScaling;
    //private Vector3 previousScaleMeasured;
    //private Coroutine scalingCoroutine;

    //private new void Awake()
    //{
    //    base.Awake();
    //    ZoomingFunctionalityAccoured = false;
    //    AdjustInitialScaleToBeWithinScaleRange();
    //    previousScaleMeasured = SharedMap.lossyScale;
    //}
    //private void AdjustInitialScaleToBeWithinScaleRange()
    //{
    //    Vector3 currentScale = SharedMap.transform.localScale;
    //    Vector3 mapInitialScale = OutOfRangeHelper.ClampingVectorWithinRange(currentScale, MIN_SCALE_MAP, MAX_SCALE_MAP);
    //    SharedMap.transform.localScale = mapInitialScale;
    //}

    //public bool IsZoomInRegistered(Vector3 rightJoysticMovement, Vector3 leftJoysticMovement)
    //{
    //    return rightJoysticMovement.z < 0 && leftJoysticMovement.z > 0;
    //}
    //public bool IsZoomOutRegistered(Vector3 rightJoysticMovement, Vector3 leftJoysticMovement)
    //{
    //    return rightJoysticMovement.z > 0 && leftJoysticMovement.z < 0;
    //}
    //private Vector3 RightControllerDirection()
    //{
    //    return ControllerInputsHolder.DirectionMovementByRightJoysticMovement();
    //}
    //private Vector3 LeftControllerDirection()
    //{
    //    return ControllerInputsHolder.DirectionMovementByLeftJoysticMovement();
    //}
    //public float ControllerDistanceFromOrigin()
    //{
    //    Vector3 rightJoysticMovement = RightControllerDirection();
    //    Vector3 leftJoysticMovement  = LeftControllerDirection();
    //    const float MAX_DISTANCE_BETWEEN_JOYSTICKS = 2.0f;
    //    float controllerDistance = Vector3.Distance(rightJoysticMovement, leftJoysticMovement) /
    //                                                                                MAX_DISTANCE_BETWEEN_JOYSTICKS;
    //    controllerDistance = controllerDistance * Time.deltaTime * MapZoomMultiplier;
    //    controllerDistance += 1.0f;

    //    if (IsZoomOutRegistered(rightJoysticMovement, leftJoysticMovement))
    //    {
    //        controllerDistance = 1.0f / controllerDistance;
    //        Debug.Log("zoom out");
    //    }
    //    else if(!IsZoomInRegistered(rightJoysticMovement, leftJoysticMovement))
    //    {
    //        Debug.Log("no zoom");
    //        controllerDistance = 0.0f;
    //    }
    //    return controllerDistance;
    //}
    //public IEnumerator ScalingUntilStoppedPinching()
    //{
    //    while (ZoomingFunctionalityAccoured)
    //    {
    //        float currentTargetScale = ControllerDistanceFromOrigin();
    //        if (currentTargetScale > 0.0f)
    //        {
    //            Debug.Log("currentTargetScale : " + currentTargetScale);
    //            Vector3 newScale = SharedMap.transform.localScale * currentTargetScale;
    //            Vector3 endUpScale = OutOfRangeHelper.ClampingVectorWithinRange(
    //                                                        newScale, MIN_SCALE_MAP, MAX_SCALE_MAP);

    //            TransformationsMathHelpers.ScaleAroundPivot(SharedMap.transform, SharedVisibilityArea, endUpScale);
    //        }
    //        yield return null;
    //    }
    //    scalingCoroutine = null;
    //}

    //public void AdjustPositionIfOutOfRange()
    //{
    //    bool shouldTakeMaxDistanceFromOutOfRange = SharedMap.transform.rotation != visibilityAreaCollider.transform.rotation;
    //    Vector3[] smallerVolumePositions = verticesPositionVisibilityArea;
    //    Vector3[] largerVolumePositions  = verticesPositionWholeMap;
    //    BoxCollider biggerCollider = mapCollider;
    //    bool isVisibilitAreaBigger = false;
    //    // smaller and larger vertices test
    //    //for (int index = 0; index < smallerVolumePositions.Length; index++)
    //    //{
    //    //    Debug.DrawRay(smallerVolumePositions[index], Vector3.up * 100f, Color.red, 10f);
    //    //    Debug.DrawRay(largerVolumePositions[index], Vector3.up * 100f, Color.yellow, 10f);
    //    //}
    //    if (TransformationsMathHelpers.AreaOfVisiblityBiggerThanMapArea(visibilityAreaCollider, mapCollider))
    //    {
    //        smallerVolumePositions = verticesPositionWholeMap;
    //        largerVolumePositions = verticesPositionVisibilityArea;
    //        biggerCollider = visibilityAreaCollider;
    //        isVisibilitAreaBigger = true;
    //    }
    //    Vector3 pointFarthestFromCollider;
    //    // TODO: maybe change it to be at one calculation later
    //    //int numberOfTimesMoving = 1;
    //    bool isStillOutOfRange = true;
    //    for (int numberOfTimesMoving = 1;numberOfTimesMoving <= MAX_NUMBER_OF_MOVEMENTS && isStillOutOfRange; numberOfTimesMoving++)
    //    {
    //        isStillOutOfRange = OutOfRangeHelper.TryFindingTheFarthestPointOutOfRange(smallerVolumePositions,
    //                                                                                  largerVolumePositions, biggerCollider,
    //                                                                                  shouldTakeMaxDistanceFromOutOfRange,
    //                                                                                  out pointFarthestFromCollider);
    //        Vector3 closestPoint = biggerCollider.bounds.ClosestPoint(pointFarthestFromCollider);
    //        Vector3 directionOfCorrection = pointFarthestFromCollider - closestPoint;

    //        if (isVisibilitAreaBigger)
    //        {
    //            directionOfCorrection = -directionOfCorrection;
    //        }
    //        directionOfCorrection.y = 0;
    //        SharedMap.transform.position += directionOfCorrection;

    //        BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, SharedMap.transform.position);
    //        Debug.LogFormat("map out of range by zoom, updated position : {0}", SharedMap.transform.position);
    //    }
    //}
    //public override bool IsActionOccouring()
    //{
    //    Vector3 rightJoysticMovement = RightControllerDirection();
    //    Vector3 leftJoysticMovement  = LeftControllerDirection();
    //    return rightJoysticMovement != Vector3.zero && leftJoysticMovement != Vector3.zero;
    //}
    //public override void OnActionEnable()
    //{
    //    ZoomingFunctionalityAccoured = true;
    //    if(scalingCoroutine == null)
    //    {
    //        scalingCoroutine = StartCoroutine(ScalingUntilStoppedPinching());
    //    }
    //}
    //public override void OnActionDisable()
    //{
    //    ZoomingFunctionalityAccoured = false;
    //    if (previousScaleMeasured != SharedMap.lossyScale)
    //    {
    //        UpdateVerticesOfMapCollider();
    //        AdjustPositionIfOutOfRange();
    //        previousScaleMeasured = SharedMap.lossyScale;
    //    }
    //}
}
