﻿using Assets.Game._Scripts.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Game._Scripts.DetectionScripts.MapTransformations
{
    public class TransformationsSharedData
    {

        public Transform SharedMap            { get; private set; }
        public Transform SharedVisibilityArea { get; private set; }
        public BoxCollider mapCollider            { get; private set; }
        public BoxCollider visibilityAreaCollider { get; private set; }
        public  Vector3[] verticesDirectionOfWholeMap    { get; private set; }
        public  Vector3[] verticesPositionWholeMap       { get; private set; }
        public  Vector3[] verticesPositionVisibilityArea { get; private set; }
        private BOX_COLLIDER_VERTICES.VertexKey[] topVertices = BOX_COLLIDER_VERTICES.TopVerticesOfBoxCollider();

        public TransformationsSharedData(Transform MyVisibilityAreaTrans, Transform MyMapTrans)
        {
            SharedMap = MyMapTrans;
            SharedVisibilityArea = MyVisibilityAreaTrans;

            mapCollider = FindOrCreateComponents.Component<BoxCollider>(SharedMap.gameObject);
            visibilityAreaCollider = FindOrCreateComponents.Component<BoxCollider>(SharedVisibilityArea.gameObject);
            Vector3 mapPosition = SharedMap.position;
            Vector3 visibilityAreaPosition = SharedVisibilityArea.position;

            verticesDirectionOfWholeMap = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(mapCollider, topVertices);
            verticesPositionWholeMap = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirectionOfWholeMap, mapCollider);

            // assuming the scale of the visibility area wont change mid game, thus not using it as private
            Vector3[] verticesDirectionOfVisibilityArea = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(visibilityAreaCollider,
                                                                                                                        topVertices);
            verticesPositionVisibilityArea = BOX_COLLIDER_VERTICES.VerticesPosition(verticesDirectionOfVisibilityArea, visibilityAreaCollider);

        }

        public void UpdateVerticesOfMapCollider()
        {
            // TODO: change the Construct to adjust later
            verticesDirectionOfWholeMap = BOX_COLLIDER_VERTICES.ConstructVerticesDirectionOfCollider(mapCollider, topVertices);
            BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, mapCollider, Vector3.zero);
        }
    }
}
