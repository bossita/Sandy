﻿using System.Collections;
using UnityEngine;
using Assets.Game._Scripts.Helpers;
using Assets.Game._Scripts.DetectionScripts.MapTransformations;

public class MapZoomHandler : /*MonoBehaviour*/ MapAction
{
    [Header("Variables")]
    public float FactorScalingByTime = 20f;
    public float AnimationSpan = 5.0f;
    public float AnimationSpeed = 2.0f;
    public float SpeedMultiplication = 1.2f;
    public float MapZoomMultiplier = 0.4f;
    [Header("Scale limits")]
    public Vector3 MAX_SCALE_MAP = new Vector3(5.0f, 5.0f, 5.0f);
    public Vector3 MIN_SCALE_MAP = new Vector3(0.01f, 0.01f, 0.01f);

    public bool ZoomingFunctionalityAccoured { get; private set; }

    private const float INITIAL_LINE_RENDERER_SIZE = 5.0f;
    private const float DEFAULT_SCALE_MULTIPLIER = 1.0f;
    private const int MAX_NUMBER_OF_MOVEMENTS = 2;

    private float timeStartedScaling;
    private Vector3 previousScaleMeasured;
    private Coroutine scalingCoroutine;
    private TransformationsSharedData transformationsSharedData;
    private MonoBehaviour monoScript;
    private LineRenderer[] mapUILines;

    public MapZoomHandler(TransformationsSharedData transformationsSharedData, MonoBehaviour monoScript, LineRenderer[] uiLinesElements)
    {
        this.mapUILines = uiLinesElements;
        this.transformationsSharedData = transformationsSharedData;
        this.monoScript = monoScript;
        ZoomingFunctionalityAccoured = false;
        AdjustInitialScaleToBeWithinScaleRange();
        previousScaleMeasured = transformationsSharedData.SharedMap.lossyScale;
    }
    private void AdjustInitialScaleToBeWithinScaleRange()
    {
        Vector3 currentScale = transformationsSharedData.SharedMap.transform.localScale;
        Vector3 mapInitialScale = OutOfRangeHelper.ClampingVectorWithinRange(currentScale, MIN_SCALE_MAP, MAX_SCALE_MAP);
        transformationsSharedData.SharedMap.localScale = mapInitialScale;
    }

    public bool IsZoomInRegistered(Vector3 rightJoysticMovement, Vector3 leftJoysticMovement)
    {
        return rightJoysticMovement.z < 0 && leftJoysticMovement.z > 0;
    }
    public bool IsZoomOutRegistered(Vector3 rightJoysticMovement, Vector3 leftJoysticMovement)
    {
        return rightJoysticMovement.z > 0 && leftJoysticMovement.z < 0;
    }
    private Vector3 RightControllerDirection()
    {
        return ControllerInputsHolder.DirectionMovementByRightJoysticMovement();
    }
    private Vector3 LeftControllerDirection()
    {
        return ControllerInputsHolder.DirectionMovementByLeftJoysticMovement();
    }
    public float ControllerDistanceFromOrigin()
    {
        Vector3 rightJoysticMovement = RightControllerDirection();
        Vector3 leftJoysticMovement = LeftControllerDirection();
        const float MAX_DISTANCE_BETWEEN_JOYSTICKS = 2.0f;
        float controllerDistance = Vector3.Distance(rightJoysticMovement, leftJoysticMovement) /
                                                                                    MAX_DISTANCE_BETWEEN_JOYSTICKS;
        controllerDistance = controllerDistance * Time.deltaTime * MapZoomMultiplier;
        controllerDistance += 1.0f;

        if (IsZoomOutRegistered(rightJoysticMovement, leftJoysticMovement))
        {
            controllerDistance = 1.0f / controllerDistance;
            Debug.Log("zoom out");
        }
        else if (!IsZoomInRegistered(rightJoysticMovement, leftJoysticMovement))
        {
            Debug.Log("no zoom");
            controllerDistance = 0.0f;
        }
        return controllerDistance;
    }
    public IEnumerator ScalingUntilStoppedPinching()
    {
        while (ZoomingFunctionalityAccoured)
        {
            float currentTargetScale = ControllerDistanceFromOrigin();
            if (currentTargetScale > 0.0f)
            {
                Debug.Log("currentTargetScale : " + currentTargetScale);
                Vector3 newScale = transformationsSharedData.SharedMap.localScale * currentTargetScale;
                Vector3 endUpScale = OutOfRangeHelper.ClampingVectorWithinRange(
                                                            newScale, MIN_SCALE_MAP, MAX_SCALE_MAP);

                TransformationsMathHelpers.ScaleAroundPivot(transformationsSharedData.SharedMap, transformationsSharedData.SharedVisibilityArea, endUpScale);
                AdjustLinesWidthByMapScale();
            }
            yield return null;
        }
        scalingCoroutine = null;
    }
    private void AdjustLinesWidthByMapScale()
    {
        foreach(LineRenderer line in mapUILines)
        {
            float newWidth  = INITIAL_LINE_RENDERER_SIZE * transformationsSharedData.SharedMap.lossyScale.x;
            line.startWidth = newWidth;
            line.endWidth   = newWidth;
        }
    }
    public void AdjustPositionIfOutOfRange()
    {
        bool shouldTakeMaxDistanceFromOutOfRange = transformationsSharedData.SharedMap.rotation != transformationsSharedData.SharedVisibilityArea.rotation;
        Vector3[] smallerVolumePositions = transformationsSharedData.verticesPositionVisibilityArea;
        Vector3[] largerVolumePositions = transformationsSharedData.verticesPositionWholeMap;
        BoxCollider biggerCollider = transformationsSharedData.mapCollider;
        bool isVisibilitAreaBigger = false;
        // smaller and larger vertices test
        //for (int index = 0; index < smallerVolumePositions.Length; index++)
        //{
        //    Debug.DrawRay(smallerVolumePositions[index], Vector3.up * 100f, Color.red, 10f);
        //    Debug.DrawRay(largerVolumePositions[index], Vector3.up * 100f, Color.yellow, 10f);
        //}
        if (TransformationsMathHelpers.AreaOfVisiblityBiggerThanMapArea(transformationsSharedData.visibilityAreaCollider, transformationsSharedData.mapCollider))
        {
            smallerVolumePositions = transformationsSharedData.verticesPositionWholeMap;
            largerVolumePositions = transformationsSharedData.verticesPositionVisibilityArea;
            biggerCollider = transformationsSharedData.visibilityAreaCollider;
            isVisibilitAreaBigger = true;
        }
        Vector3 pointFarthestFromCollider;
        // TODO: maybe change it to be at one calculation later
        //int numberOfTimesMoving = 1;
        bool isStillOutOfRange = true;
        for (int numberOfTimesMoving = 1; numberOfTimesMoving <= MAX_NUMBER_OF_MOVEMENTS && isStillOutOfRange; numberOfTimesMoving++)
        {
            isStillOutOfRange = OutOfRangeHelper.TryFindingTheFarthestPointOutOfRange(smallerVolumePositions,
                                                                                      largerVolumePositions, biggerCollider,
                                                                                      shouldTakeMaxDistanceFromOutOfRange,
                                                                                      out pointFarthestFromCollider);
            Vector3 closestPoint = biggerCollider.bounds.ClosestPoint(pointFarthestFromCollider);
            Vector3 directionOfCorrection = pointFarthestFromCollider - closestPoint;

            if (isVisibilitAreaBigger)
            {
                directionOfCorrection = -directionOfCorrection;
            }
            directionOfCorrection.y = 0;
            transformationsSharedData.SharedMap.position += directionOfCorrection;

            BOX_COLLIDER_VERTICES.AdjustVerticesPosition(transformationsSharedData.verticesDirectionOfWholeMap, transformationsSharedData.verticesPositionWholeMap, transformationsSharedData.mapCollider, Vector3.zero);
            Debug.LogFormat("map out of range by zoom, updated position : {0}", transformationsSharedData.SharedMap.position);
        }
    }
    public override bool IsActionOccouring()
    {
        Vector3 rightJoysticMovement = RightControllerDirection();
        Vector3 leftJoysticMovement = LeftControllerDirection();
        return rightJoysticMovement != Vector3.zero && leftJoysticMovement != Vector3.zero;
    }
    public override void OnActionEnable()
    {
        ZoomingFunctionalityAccoured = true;
        if (scalingCoroutine == null)
        {
            scalingCoroutine = monoScript.StartCoroutine(ScalingUntilStoppedPinching());
        }
    }
    public override void OnActionDisable()
    {
        ZoomingFunctionalityAccoured = false;
        if (previousScaleMeasured != transformationsSharedData.SharedMap.lossyScale)
        {
            transformationsSharedData.UpdateVerticesOfMapCollider();
            AdjustPositionIfOutOfRange();
            previousScaleMeasured = transformationsSharedData.SharedMap.lossyScale;
        }
    }
}
