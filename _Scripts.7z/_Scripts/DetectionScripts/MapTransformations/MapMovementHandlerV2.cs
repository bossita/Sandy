﻿using Assets.Game._Scripts.DetectionScripts.MapTransformations;
using Assets.Game._Scripts.Helpers;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapMovementHandlerV2 : MonoBehaviour
{

    //#region inspector public variables
    //[Header("Variables")]
    //public float AnimationSpan = 5.0f;
    //public float AnimationSpeed = 2.0f;
    //public float AnimationMovementSpeed = 2.0f;
    //public float KickFactor = 150.0f;
    //public float FactorMovement = 30.0f;
    //public float precentageKickBoost = 0.1f;
    //public float FactorByScale = 0.9f;
    //#endregion

    //public bool MapMovementFunctionalityAccoured { get; private set; }

    //#region const variables
    //private const int LAYER_OF_MAP = 10;
    //private const int LAYER_OF_VISIBILITY_AREA = 11;
    //private const int FINISHED_LERPING = 1;
    //#endregion
    //private Bounds mapsBounds;
    //private Vector3 mapInitialPosition;

    //private Vector3 targetDirection;
    //private Vector3 currentMovementDirection;
    //private float precentageComplete;
    //private bool didStartAnotherAction;

    //private BoxCollider virtualSpaceBoxCollider;
    //private Coroutine movementCoroutine;
    //private Vector3 previousMapPosition;

    //private void Start()
    //{
    //    InitializingMovementVariables();
    //    mapsBounds = mapCollider.bounds;

    //    for (int index = 0; index < verticesPositionVisibilityArea.Length; index++)
    //    {
    //        Debug.DrawRay(verticesPositionVisibilityArea[index], Vector3.up * 10f, Color.cyan, 100f);
    //    }
    //    InitializeVirtualBoxCollider();
    //}
    //// the map boxCollider adjustments accours on awake function thus,
    //// the initialization of virtualSpaceBoxCollider should always be called on Start method
    //private void InitializeVirtualBoxCollider()
    //{
    //    virtualSpaceBoxCollider = SharedMap.gameObject.AddComponent<BoxCollider>();
    //    virtualSpaceBoxCollider.center = mapCollider.center;
    //    virtualSpaceBoxCollider.size = mapCollider.size;
    //    virtualSpaceBoxCollider.enabled = false;
    //}
    //private void InitializingMovementVariables()
    //{
    //    mapInitialPosition = SharedMap.position;
    //    targetDirection = Vector3.zero;
    //    currentMovementDirection = Vector3.zero;
    //    didStartAnotherAction = false;
    //}
    //public Vector3 DirectionControllerInput()
    //{
    //    return ControllerInputsHolder.DirectionMovementByRightJoysticMovement();
    //}

    //public override bool IsActionAccouring()
    //{
    //    return DirectionControllerInput() != Vector3.zero;
    //}

    //public override void OnActionEnable()
    //{
    //    MapMovementFunctionalityAccoured = true;
    //    if (movementCoroutine == null)
    //    {
    //        movementCoroutine = StartCoroutine(MoveUntilStoppedPinching());
    //    }
    //}
    //public override void OnActionDisable()
    //{
    //    MapMovementFunctionalityAccoured = false;
    //    if (previousMapPosition != SharedMap.position)
    //    {
    //        BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, SharedMap.transform.position);
    //        previousMapPosition = SharedMap.position;
    //    }
    //}

    //private IEnumerator MoveUntilGotToDestinationOrInterapted(float timeStartedMovementPush)
    //{
    //    Debug.Log("moving the map");
    //    while (precentageComplete < FINISHED_LERPING && !didStartAnotherAction)
    //    {
    //        float timeSinceStarted = Time.time - timeStartedMovementPush;
    //        precentageComplete = precentageKickBoost + timeSinceStarted / AnimationSpan * AnimationMovementSpeed;
    //        //precentageComplete = Mathf.Min(precentageComplete, FINISHED_LERPING);
    //        currentMovementDirection = Vector3.Lerp(currentMovementDirection, targetDirection, precentageComplete);
    //        SharedMap.transform.position = mapInitialPosition + currentMovementDirection;
    //        yield return null;
    //    }
    //    Debug.Log("..............");
    //    Debug.Log("ended movement");
    //    //instead of clamping the precntageComplete in the while changing it to the target position.
    //    if (precentageComplete > FINISHED_LERPING)
    //    {
    //        SharedMap.transform.position = mapInitialPosition + targetDirection;
    //    }
    //    targetDirection = Vector3.zero;
    //    precentageComplete = 0.0f;
    //    mapInitialPosition = SharedMap.transform.position;
    //    //animationMovementSpeed   = DEFAULT_SPEED;
    //}

    //private Vector3 MovementToApplyToMap(Vector3 directionMovement)
    //{
    //    // dont move the map in the y direction
    //    directionMovement.y = 0;
    //    Vector3 xDirectionMovement = new Vector3(directionMovement.x, 0, 0);
    //    Vector3 zDirectionMovement = new Vector3(0, 0, directionMovement.z);
    //    Vector3 movementToApplyToMap = ClampWithinBorders(xDirectionMovement);/*SecondGenerationClampWithinBorders(xDirectionMovement);*/
    //    movementToApplyToMap += ClampWithinBorders(zDirectionMovement);/*SecondGenerationClampWithinBorders(zDirectionMovement);*/
    //    //Debug.Log("final movement" + movementToApplyToMap + " " + (movementToApplyToMap != Vector3.zero));
    //    return movementToApplyToMap;
    //}

    ////private Vector3 SecondGenerationClampWithinBorders(Vector3 directionMovement)
    ////{
    ////    BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, Map.transform.position);
    ////    Vector3 minimalMovementToStayInBorders = directionMovement;
    ////    for(int indexMapPoint = 0;indexMapPoint < verticesPositionWholeMap.Length;indexMapPoint++)
    ////    {
    ////        Vector3 vertexMapPos = verticesPositionWholeMap[indexMapPoint];
    ////        //vertexMapPos.x = CutDoubleValues(vertexMapPos.x);
    ////        //vertexMapPos.z = CutDoubleValues(vertexMapPos.z);

    ////        // new Position checked V
    ////        Vector3 newPositionOfMapPoint = vertexMapPos + directionMovement;
    ////        //Debug.DrawRay(newPositionOfMapPoint, Vector3.up * 100f, Color.grey, 10f);
    ////        //Debug.DrawRay(vertexMapPos, directionMovement * 1000f, Color.blue, 10f);
    ////        for (int indexFirstVisibilityPoint = 0, indexSecondVisibilityPoint = verticesPositionVisibilityArea.Length - 1;
    ////                 indexFirstVisibilityPoint < verticesPositionVisibilityArea.Length;
    ////                 indexSecondVisibilityPoint = indexFirstVisibilityPoint++)
    ////        {
    ////            Vector3 firstVisibilityPoint  = verticesPositionVisibilityArea[indexFirstVisibilityPoint];
    ////            //firstVisibilityPoint.x = CutDoubleValues(firstVisibilityPoint.x);
    ////            //firstVisibilityPoint.z = CutDoubleValues(firstVisibilityPoint.z);
    ////            Vector3 secondVisibilityPoint = verticesPositionVisibilityArea[indexSecondVisibilityPoint];
    ////            //Debug.DrawLine(firstVisibilityPoint, (secondVisibilityPoint - firstVisibilityPoint) * 1000f, Color.yellow, 10f);
    ////            //Debug.DrawLine(secondVisibilityPoint, (firstVisibilityPoint - secondVisibilityPoint) * 1000f, Color.yellow, 10f);

    ////            try
    ////            {
    ////                Vector3 intersectionPoint = TransformationsMathHelpers.FindIntersectionXZPlane(vertexMapPos, newPositionOfMapPoint,
    ////                                                                                                firstVisibilityPoint, secondVisibilityPoint);

    ////                //Debug.DrawRay(intersectionPoint, Vector3.up * 100f, Color.white, 10f);
    ////                if(TransformationsMathHelpers.IsWithinDirectionMagnitude(vertexMapPos, directionMovement, intersectionPoint))
    ////                {
    ////                    Debug.Log("fixing out of range...");
    ////                    Vector3 newDirectionToCheck = intersectionPoint - vertexMapPos;

    ////                    if (minimalMovementToStayInBorders.magnitude > newDirectionToCheck.magnitude)
    ////                    {
    ////                        //Debug.DrawRay(firstVisibilityPoint, Vector3.down * 30f, Color.red, 10f);
    ////                        //Debug.DrawRay(secondVisibilityPoint, Vector3.down * 30f, Color.red, 10f);
    ////                        minimalMovementToStayInBorders = newDirectionToCheck;
    ////                        if (OutOfRangeHelper.ApproximetlyEqual(firstVisibilityPoint.x, vertexMapPos.x + newDirectionToCheck.x))
    ////                        {
    ////                            minimalMovementToStayInBorders.x = 0;
    ////                        }
    ////                        if (OutOfRangeHelper.ApproximetlyEqual(firstVisibilityPoint.z, vertexMapPos.z + newDirectionToCheck.z))
    ////                        {
    ////                            minimalMovementToStayInBorders.z = 0;
    ////                        }
    ////                    }
    ////                }
    ////            }
    ////            catch(LinesAreParallelException)
    ////            {
    ////            }

    ////        }
    ////    }
    ////    return minimalMovementToStayInBorders;
    ////}
    //private Vector3 ClampWithinBorders(Vector3 directionMovement)
    //{
    //    Vector3 movementToApplyToMap = directionMovement;
    //    Vector3 mapDesiredPosition = SharedMap.transform.position + movementToApplyToMap;
    //    int layerMask = 1 << LAYER_OF_MAP;
    //    // TODO: could be risky if later two actions could happen simutaniously
    //    BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, mapDesiredPosition);
    //    bool shouldTakeMaxDistanceFromOutOfRange = SharedMap.transform.rotation != visibilityAreaCollider.transform.rotation;
    //    bool directionOffsetAsDirectionMovement = true;

    //    Vector3[] smallerVolumePositions = verticesPositionVisibilityArea;
    //    Vector3[] largerVolumePositions = verticesPositionWholeMap;
    //    BoxCollider largerCollider = mapCollider;
    //    Vector3 directionToCalculateOffset = directionMovement;
    //    //Debug.Log(sizeOfVisibilityArea.magnitude + " " + sizeOfMap.magnitude);
    //    if (TransformationsMathHelpers.AreaOfVisiblityBiggerThanMapArea(visibilityAreaCollider, mapCollider))
    //    {
    //        largerCollider = visibilityAreaCollider;
    //        smallerVolumePositions = verticesPositionWholeMap;
    //        largerVolumePositions = verticesPositionVisibilityArea;
    //        layerMask = 1 << LAYER_OF_VISIBILITY_AREA;
    //        directionToCalculateOffset = -directionToCalculateOffset;
    //        directionOffsetAsDirectionMovement = false;
    //        Debug.Log("verticesPositionWholeMap is the smaller");
    //    }
    //    Vector3 pointFarthestFromCollider;
    //    if (OutOfRangeHelper.TryFindingTheFarthestPointOutOfRange(smallerVolumePositions, largerVolumePositions,
    //                                                              largerCollider, shouldTakeMaxDistanceFromOutOfRange,
    //                                                              out pointFarthestFromCollider))
    //    {
    //        virtualSpaceBoxCollider.enabled = true;
    //        float directionDividerByScale = mapCollider.transform.localScale.magnitude / Vector3.one.magnitude;
    //        virtualSpaceBoxCollider.center = mapCollider.center + (directionMovement / directionDividerByScale);
    //        virtualSpaceBoxCollider.size = mapCollider.size;
    //        mapCollider.enabled = false;
    //        Debug.DrawRay(pointFarthestFromCollider, directionMovement, Color.red, 8f);
    //        RaycastHit hitInfo;
    //        if (Physics.Raycast(pointFarthestFromCollider, directionToCalculateOffset, out hitInfo, directionToCalculateOffset.magnitude, layerMask))
    //        {
    //            Debug.Log("rayCasting");
    //            Vector3 impactPoint = hitInfo.point;
    //            Debug.DrawLine(pointFarthestFromCollider, impactPoint, Color.white, 10f);
    //            Vector3 directionOffsetFromBeingWithinArea = impactPoint - pointFarthestFromCollider;
    //            if (directionOffsetAsDirectionMovement)
    //            {
    //                movementToApplyToMap = movementToApplyToMap - directionOffsetFromBeingWithinArea;
    //            }
    //            else
    //            {
    //                movementToApplyToMap = movementToApplyToMap + directionOffsetFromBeingWithinArea;
    //            }
    //        }
    //        else
    //        {
    //            movementToApplyToMap = Vector3.zero;
    //        }
    //        mapCollider.enabled = true;
    //        virtualSpaceBoxCollider.enabled = false;
    //    }
    //    virtualSpaceBoxCollider.enabled = false;
    //    //Debug.Log("movementToApplyToMap" + movementToApplyToMap);
    //    return movementToApplyToMap;
    //}

    //public IEnumerator MoveUntilStoppedPinching()
    //{
    //    float timeSinceStartedMoving = Time.time;
    //    Vector3 movementToApplyToMap = Vector3.zero;
    //    while (MapMovementFunctionalityAccoured)
    //    {
    //        didStartAnotherAction = true;
    //        Vector3 directionMovement = DirectionControllerInput();
    //        SharedMap.transform.position += MovementToApplyToMap(directionMovement * FactorMovement * Time.deltaTime);
    //        #region testing if not moved out of range
    //        //Vector3[] smallerVolumePositions = verticesPositionVisibilityArea;
    //        //Vector3[] largerVolumePositions = verticesPositionWholeMap;
    //        //if (TransformationsMathHelpers.AreaOfVisiblityBiggerThanMapArea(visibilityAreaCollider, mapCollider))
    //        //{
    //        //    smallerVolumePositions = verticesPositionWholeMap;
    //        //    largerVolumePositions  = verticesPositionVisibilityArea;
    //        //}
    //        //bool shouldTakeMaxDistanceFromOutOfRange = false;
    //        //Vector3 pointFarthestFromCollider;
    //        //BOX_COLLIDER_VERTICES.AdjustVerticesPosition(verticesDirectionOfWholeMap, verticesPositionWholeMap, Map.transform.position);

    //        //if (TryFindingTheFarthestPointOutOfRange(smallerVolumePositions, largerVolumePositions,
    //        //                                                    shouldTakeMaxDistanceFromOutOfRange, out pointFarthestFromCollider))
    //        //{
    //        //    if (TryFindingTheFarthestPointOutOfRange(smallerVolumePositions, largerVolumePositions,
    //        //                                                    shouldTakeMaxDistanceFromOutOfRange, out pointFarthestFromCollider))
    //        //    {
    //        //            Debug.LogWarning("wtf its already out of range");
    //        //    }
    //        //}
    //        #endregion
    //        yield return null;
    //    }
    //    mapInitialPosition = SharedMap.transform.position;
    //    movementCoroutine = null;
    //    //ConstructInertiaKickAfterMovement(previousDirection, firstPositionMovement, timeSinceStartedMoving, movementToApplyToMap);
    //}
    //// inertia -> might use it later, currently not using it.
    ////private void ConstructInertiaKickAfterMovement(Vector3 endingPosition, Vector3 firstPosition, float timeSinceStartedMoving,
    ////                                                                                              Vector3 lastMovementApplied)
    ////{
    ////    float   timeStartedMovementPush = Time.time;
    ////    Vector3 deltaPosition  = endingPosition - firstPosition;
    ////    float   deltaTime      = timeStartedMovementPush - timeSinceStartedMoving;
    ////    Vector3 velocityFactor = (deltaPosition) / (deltaTime);
    ////    // TODO: add a thrashhold later -> if velocityFactor.magnitude > some value (not important right now)
    ////    targetDirection = lastMovementApplied * KickFactor * (Map.transform.localScale.magnitude * FactorByScale) * (1 + velocityFactor.magnitude) * Time.deltaTime;
    ////    targetDirection = MovementToApplyToMap(targetDirection);
    ////    if (targetDirection != Vector3.zero)
    ////    {
    ////        didStartAnotherAction = false;
    ////        StartCoroutine(MoveUntilGotToDestinationOrInterapted(timeStartedMovementPush));
    ////    }
    ////}
}
