﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Game._Scripts.DetectionScripts.MapTransformations
{
    public interface IAction
    {
        void OnActionDisable();
        void OnActionEnable();
        bool IsActionOccouring();
    }
}
