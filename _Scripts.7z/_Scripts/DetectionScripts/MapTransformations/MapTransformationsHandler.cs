﻿using Assets.Game._Scripts.DetectionScripts.MapTransformations;
using UnityEngine;

public class MapTransformationsHandler : MonoBehaviour
{
    private MapZoomHandler     mapZoomHandler;
    private MapMovementHandler mapMovementHandler;
    private MapRotationHandler mapRotationHandler;

    [SerializeField]
    public Transform VisibilityArea;

    [SerializeField]
    public Transform Map;

    [SerializeField]
    public GameObject allUILinessHolder;

    // currently not using
    //private AdjustHandActionIcons mapActionsIcons;

    // the function has to be on start, because the map collider adjustment is being applied on the awake function.
    private void Start()
    {
        LineRenderer[] allUILines = allUILinessHolder.GetComponentsInChildren<LineRenderer>();
        TransformationsSharedData transformationsSharedData = new TransformationsSharedData(VisibilityArea, Map);
        mapMovementHandler = new MapMovementHandler(transformationsSharedData, this);
        mapRotationHandler = new MapRotationHandler(transformationsSharedData, this);
        mapZoomHandler     = new MapZoomHandler(transformationsSharedData, this, allUILines);
    }
    public GameObject MapBeingUsed()
    {
        return Map.gameObject;
    }

    public bool ZoomingIsAccouring()
    {
        return mapZoomHandler.IsActionOccouring();
    }
    public bool MapMovementIsOccouring()
    {
        return mapMovementHandler.IsActionOccouring() && !ZoomingIsAccouring();
    }
    public bool RotationIsAccouring()
    {
        return mapRotationHandler.IsActionOccouring();
    }

    private void Update()
    {
        CheckForMapMovement();
        CheckForMapZooming();
        CheckForMapRotation();
    }

    public void CheckForMapMovement()
    {
        if (MapMovementIsOccouring())
        {
            Debug.Log("started moving");
            //mapActionsIcons.EnableMapMovementIcon();
            mapMovementHandler.OnActionEnable();
        }
        else
        {
            mapMovementHandler.OnActionDisable();
        }
    }
    public void CheckForMapZooming()
    {
        if (ZoomingIsAccouring())
        {
            Debug.Log("started zooming");
            //mapActionsIcons.EnableMapZoomingIcon();
            mapZoomHandler.OnActionEnable();

            mapMovementHandler.OnActionDisable();
        }
        else
        {
            mapZoomHandler.OnActionDisable();
        }
    }
    public void CheckForMapRotation()
    {
        if (RotationIsAccouring())
        {
            Debug.Log("started rotating");
            mapRotationHandler.OnActionEnable();
        }
        else
        {
            mapRotationHandler.OnActionDisable();
        }
    }
    //public void DisableHandPinch(RiggedHand riggedHand)
    //{
    //    if(riggedHand != null)
    //    {
    //        ChangeStateOfHandPinch(riggedHand.Handedness, false);
    //        mapActionsIcons.DisableIcon();

    //        if (mapZoomHandler.ZoomingFunctionalityAccoured)
    //        {
    //            Debug.Log("stopped zooming");
    //            mapZoomHandler.DisableScale();

    //            mapMovementHandler.UpdateVerticesOfMapCollider();

    //            RiggedHand potentialEnabledHand = ComplementaryHand(riggedHand);
    //            CheckForMapMovement(/*potentialEnabledHand);

    //            // should be in mapZoom disableScalePinched later
    //            mapMovementHandler.AdjustPositionIfOutOfRange();
    //        }
    //        else if (mapMovementHandler.MapMovementFunctionalityAccoured)
    //        {
    //            Debug.Log("stopped moving");
    //            mapMovementHandler.DisablePinchedIfReleased();
    //        }
    //    }
    //    else
    //    {
    //        Debug.LogWarning("rigged hand is null");
    //    }
    //}
}
