﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FittingCameraToMapSize : MonoBehaviour
{
    [SerializeField]
    public Camera CameraToFit;

    [SerializeField]
    public BoxCollider MapCollider;

    private Bounds mapBounds;
    private Vector3 ROTATION_TOP_VIEW = new Vector3(90.0f, 0.0f, 0.0f);

	void Start ()
    {
        //mapBounds = MapCollider.bounds;
        //Vector3 cameraNewPosition = /*mapBounds.center*/ MapCollider.transform.position;
        //const float FACTOR_TO_BE_HIGHER_THAN_MAP = 10f;
        //Vector3 mapSize = mapBounds.size;
        //cameraNewPosition.y += mapSize.y * FACTOR_TO_BE_HIGHER_THAN_MAP;
        //transform.position = /*cameraNewPosition*/ new Vector3(0,0,0);
        ////CameraToFit.transform.rotation = Quaternion.Euler(ROTATION_TOP_VIEW);
        //Debug.Log(CameraToFit.transform.rotation);
        //CameraToFit.orthographicSize = ((mapSize.x + mapSize.z) / 2.0f);
        ////CameraToFit.orthographicSize = ((mapSize.x + mapSize.z) / 4.0f);
        //Debug.Log(cameraNewPosition + " " + CameraToFit.transform.position);
    }

    void Update ()
    {
        //mapBounds = MapCollider.bounds;
        //Vector3 cameraNewPosition = /*mapBounds.center*/ MapCollider.transform.position;
        //const float FACTOR_TO_BE_HIGHER_THAN_MAP = 10f;
        //Vector3 mapSize = mapBounds.size;
        //cameraNewPosition.y += mapSize.y * FACTOR_TO_BE_HIGHER_THAN_MAP;
        //CameraToFit.transform.position = cameraNewPosition;
        //CameraToFit.transform.rotation = Quaternion.Euler(ROTATION_TOP_VIEW);
        //Debug.Log(CameraToFit.transform.rotation);
        //CameraToFit.orthographicSize = ((mapSize.x + mapSize.z) / 2.0f);
        ////CameraToFit.orthographicSize = ((mapSize.x + mapSize.z) / 4.0f);
        //Debug.Log(cameraNewPosition + " " + CameraToFit.transform.position);
    }
}
