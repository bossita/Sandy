﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

public class CombineTextures : Editor
{
    //[SerializeField]
    //public Shader AtlasShader;

    private const int MAIN_TEXTURE_INDEX = 0;
    private const int MAX_PIXEL_TEXTURE_SIZE = 8192;
    private const int PADDING_BETWEEN_TEXTURES = 2;
    private const string STANDARD_SHADER_NAME = "Standard";
    //[MenuItem("E.S. Tools/Combine textures")]
    //static void AtlasCombineTextures()
    //{
    //    GameObject objSelected = (GameObject)Selection.activeObject;
    //    MeshRenderer[] meshRenderers = objSelected.GetComponentsInChildren<MeshRenderer>();
    //    Dictionary<Texture2D, List<MeshRenderer>> meshesUsingTexture = new Dictionary<Texture2D, List<MeshRenderer>>();
    //    foreach (MeshRenderer currentMeshRenderer in meshRenderers)
    //    {
    //        Material[] materials = currentMeshRenderer.sharedMaterials;
    //        for (int indexMat = 0; indexMat < materials.Length; indexMat++)
    //        {
    //            Material matUsed = materials[indexMat];
    //            //Texture2D mainTex  = (Texture2D)matUsed.GetTexture(MAIN_TEXTURE_INDEX);
    //            Texture2D mainTex = (Texture2D)matUsed.mainTexture;
    //            if (mainTex != null)
    //            {
    //                List<MeshRenderer> meshRenderersUsingTexture;
    //                if (meshesUsingTexture.TryGetValue(mainTex, out meshRenderersUsingTexture))
    //                {
    //                    meshRenderersUsingTexture.Add(currentMeshRenderer);
    //                }
    //                else
    //                {
    //                    meshRenderersUsingTexture = new List<MeshRenderer>() { currentMeshRenderer };
    //                    meshesUsingTexture.Add(mainTex, meshRenderersUsingTexture);
    //                }
    //            }
    //        }
    //    }

    //    Texture2D atlasTex = new Texture2D(MAX_PIXEL_TEXTURE_SIZE, MAX_PIXEL_TEXTURE_SIZE);
    //    Material newMaterial = new Material(Shader.Find(STANDARD_SHADER_NAME));
    //    newMaterial.mainTexture = atlasTex;

    //    Texture2D[] distinctTextures = meshesUsingTexture.Keys.ToArray();
    //    // Rectangles for individual atlas textures.
    //    Rect[] uvs = atlasTex.PackTextures(distinctTextures, PADDING_BETWEEN_TEXTURES, MAX_PIXEL_TEXTURE_SIZE);
    //    int indexdRect = 0;

    //    Vector2[] uva, uvb;


    //    foreach (KeyValuePair<Texture2D, List<MeshRenderer>> textureByMeshes in meshesUsingTexture)
    //    {
    //        Rect currentUVRect = uvs[indexdRect];
    //        foreach(MeshRenderer renderer in textureByMeshes.Value)
    //        {


    //                //filters[j].gameObject.renderer.material = newMaterial;





    //            MeshFilter meshFilter = renderer.GetComponent<MeshFilter>();
    //            renderer.sharedMaterial = newMaterial;
    //            uva = (Vector2[])(((MeshFilter)meshFilter).sharedMesh.uv);
    //            uvb = new Vector2[uva.Length];
    //            for (int k = 0; k < uva.Length; k++)
    //            {
    //                uvb[k] = new Vector2((uva[k].x * uvs[indexdRect].width) + uvs[indexdRect].x, (uva[k].y * uvs[indexdRect].height) + uvs[indexdRect].y);
    //            }
    //            (meshFilter).sharedMesh.uv = uvb;



    //            //if (meshFilter != null)
    //            //{
    //            //    renderer.sharedMaterial = newMaterial;

    //            //    //renderer.sharedMaterial.mainTextureScale  = new Vector2(currentUVRect.width, currentUVRect.height);
    //            //    //renderer.sharedMaterial.mainTextureOffset = new Vector2(currentUVRect.x, currentUVRect.y);
    //            //    List<Vector2> oldUVs = new List<Vector2>();
    //            //    meshFilter.sharedMesh.GetUVs(0, oldUVs);
    //            //    List<Vector2> newUvs = new List<Vector2>();
    //            //    for (int indexUv = 0;indexUv < oldUVs.Count;indexUv++)
    //            //    {
    //            //        newUvs[indexUv] = new Vector2((oldUVs[indexUv].x * currentUVRect.width) + currentUVRect.x,
    //            //                                      (oldUVs[indexUv].y * currentUVRect.height) + currentUVRect.y);
    //            //    }
    //            //    meshFilter.sharedMesh.SetUVs(0,newUvs);
    //            //}
    //        }
    //    }
    //}


    [MenuItem("E.S. Tools/Combine textures")]
    static void Combiner()
    {
        Dictionary<Shader, List<Material>> shaderToMaterial = new Dictionary<Shader, List<Material>>();
        Dictionary<Shader, Material> generatedMaterials = new Dictionary<Shader, Material>();
        Dictionary<Material, Rect> generatedUVs = new Dictionary<Material, Rect>();
        Dictionary<Material, Rect> generatedUV2s = new Dictionary<Material, Rect>();
        bool generateLightMapUVs = true;
        bool generateColorTextures = true;
        Color generatedMaterialColor = Color.white;
        GameObject objSelected = (GameObject)Selection.activeObject;
        List<Component> filters = new List<Component>();
        filters.AddRange(objSelected.GetComponentsInChildren(typeof(MeshFilter)));

        Vector2[] uv, uv2;

        // Find all unique shaders in hierarchy.
        for (int i = 0; i < filters.Count; i++)
        {
            Renderer curRenderer = filters[i].GetComponent<Renderer>();

            uv2 = (Vector2[])(((MeshFilter)filters[i]).sharedMesh.uv2);
            if ((uv2 == null || uv2.Length == 0) && generateLightMapUVs)
            {
                uv = (Vector2[])(((MeshFilter)filters[i]).sharedMesh.uv);
                uv2 = new Vector2[uv.Length];
                Array.Copy(uv, uv2, uv.Length);
                ((MeshFilter)filters[i]).sharedMesh.uv2 = uv2;
            }

            bool noTex = true;
            if (curRenderer != null && curRenderer.enabled && curRenderer.sharedMaterial != null)
            {
                Material[] materials = curRenderer.sharedMaterials;

                if (materials != null)
                {
                    foreach (Material mat in materials)
                    {
                        if (generateColorTextures)
                        {
                            if (mat.mainTexture == null)
                            {

                                Texture2D colorTex = new Texture2D(4, 4);

                                for (int y = 0; y < colorTex.height; ++y)
                                {
                                    for (int x = 0; x < colorTex.width; ++x)
                                    {
                                        colorTex.SetPixel(x, y, mat.color);
                                    }
                                }
                                // Apply all SetPixel calls
                                colorTex.Apply();

                                mat.SetTexture("_MainTex", colorTex);
                                mat.color = Color.white;
                            }
                            else
                            {
                                noTex = false;
                            }
                        }

                        if (((mat.HasProperty("_LightMap") && (!(((MeshFilter)filters[i]).sharedMesh.uv2.Length == 0) || generateLightMapUVs) && mat.GetTexture("_LightMap") != null) || !(mat.HasProperty("_LightMap"))) &&
                            (mat.mainTextureScale == new Vector2(1.0f, 1.0f) &&
                            (mat.mainTextureOffset == Vector2.zero))
                        )
                        {
                            if (mat.shader != null && mat.mainTexture != null)
                            {
                                if (shaderToMaterial.ContainsKey(mat.shader))
                                {
                                    shaderToMaterial[mat.shader].Add(mat);
                                }
                                else
                                {
                                    shaderToMaterial[mat.shader] = new List<Material>();
                                    shaderToMaterial[mat.shader].Add(mat);
                                }
                            }
                        }
                    }

                    if (generateColorTextures && noTex)
                    {
                        Vector2[] uvv = (Vector2[])(((MeshFilter)filters[i]).sharedMesh.uv);
                        for (int j = 0; j < uvv.Length; j++)
                        {
                            uvv[j] = new Vector2(0.5f, 0.5f);
                        }

                        ((MeshFilter)filters[i]).sharedMesh.uv = uvv;
                    }
                }
            }
        }

        // Pack textures per shader basis and generate UV rect and material dictinaries. 
        foreach (Shader key in shaderToMaterial.Keys)
        {
            Texture2D packedTexture = new Texture2D(MAX_PIXEL_TEXTURE_SIZE / 2, MAX_PIXEL_TEXTURE_SIZE / 2);
            Texture2D[] texs = new Texture2D[shaderToMaterial[key].Count];
            generatedMaterials[key] = new Material(key);
            for (int i = 0; i < texs.Length; i++)
            {
                texs[i] = shaderToMaterial[key][i].mainTexture as Texture2D;
            }
            Rect[] uvs = packedTexture.PackTextures(texs, 0, MAX_PIXEL_TEXTURE_SIZE);
            packedTexture.Apply();

            generatedMaterials[key].CopyPropertiesFromMaterial(shaderToMaterial[key][0]);
            generatedMaterials[key].mainTexture = packedTexture;
            generatedMaterials[key].color = generatedMaterialColor;

            for (int i = 0; i < texs.Length; i++)
            {
                if (shaderToMaterial[key][i].HasProperty("_LightMap"))
                {
                    texs[i] = shaderToMaterial[key][i].GetTexture("_LightMap") as Texture2D;
                }
            }
            packedTexture = new Texture2D(MAX_PIXEL_TEXTURE_SIZE / 2, MAX_PIXEL_TEXTURE_SIZE / 2);
            Rect[] uvs2 = packedTexture.PackTextures(texs, 0, MAX_PIXEL_TEXTURE_SIZE);
            packedTexture.Apply();
            if (generatedMaterials[key].HasProperty("_LightMap"))
            {
                generatedMaterials[key].SetTexture("_LightMap", packedTexture);
            }

            for (int i = 0; i < texs.Length; i++)
            {
                generatedUVs[shaderToMaterial[key][i]] = uvs[i];
                generatedUV2s[shaderToMaterial[key][i]] = uvs2[i];
            }
        }

        // Calculate new UVs for all submeshes and assign generated materials.
        for (int i = 0; i < filters.Count; i++)
        {

            int subMeshCount = ((MeshFilter)filters[i]).sharedMesh.subMeshCount;

            Material[] mats = filters[i].GetComponent<MeshRenderer>().sharedMaterials;
            uv = (Vector2[])(((MeshFilter)filters[i]).sharedMesh.uv);
            uv2 = (Vector2[])(((MeshFilter)filters[i]).sharedMesh.uv2);
            for (int j = 0; j < subMeshCount; j++)
            {
                if (generatedUVs.ContainsKey(mats[j]))
                {
                    Rect uvs = generatedUVs[mats[j]];
                    Rect uvs2 = generatedUV2s[mats[j]];
                    int[] subMeshVertices = DeleteDuplicates(((MeshFilter)filters[i]).sharedMesh.GetTriangles(j)) as int[];
                    mats[j] = generatedMaterials[filters[i].GetComponent<MeshRenderer>().sharedMaterials[j].shader];
                    foreach (int vert in subMeshVertices)
                    {
                        uv[vert] = new Vector2((uv[vert].x * uvs.width) + uvs.x, (uv[vert].y * uvs.height) + uvs.y);
                        if (uv2 != null && !(uv2.Length == 0))
                        {
                            uv2[vert] = new Vector2((uv2[vert].x * uvs2.width) + uvs2.x, (uv2[vert].y * uvs2.height) + uvs2.y);
                        }
                    }
                }
            }
            filters[i].GetComponent<MeshRenderer>().sharedMaterials = mats;
            ((MeshFilter)filters[i]).sharedMesh.uv = uv;
            if (uv2 != null && !(uv2.Length == 0))
            {
                ((MeshFilter)filters[i]).sharedMesh.uv2 = uv2;
            }
        }
    }
    public static Array DeleteDuplicates(Array arr)
    {
        // this procedure works only with vectors
        if (arr.Rank != 1)
            throw new ArgumentException("Multiple-dimension arrays are not supported");

        // we use a hashtable to track duplicates
        // make the hash table large enough to avoid memory re-allocations
        Hashtable ht = new Hashtable(arr.Length * 2);
        // we will store unique elements in this ArrayList
        ArrayList elements = new ArrayList();

        foreach (object Value in arr)
        {
            if (!ht.Contains(Value))
            {
                // we've found a non duplicate
                elements.Add(Value);
                // remember it for later
                ht.Add(Value, null);
            }
        }
        // return an array of same type as the original array
        return elements.ToArray(arr.GetType().GetElementType());
    }
}
