﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ControllerInputsHolder 
{
    // ctrl + shift + u -> change to upper case
    #region const input system names 
    private const string RIGHT_JOYSTIC_HORIZONTAL = "RightJoysticHorizontal";
    private const string RIGHT_JOYSTIC_VERTICAL   = "RightJoysticVertical";
    private const string LEFT_JOYSTIC_HORIZONTAL  = "LeftJoysticHorizontal";
    private const string LEFT_JOYSTIC_VERTICAL    = "LeftJoysticVertical";
    private const string B_CONTROLLER_BUTTON      = "BControllerButton";
    private const string X_CONTROLLER_BUTTON      = "XControllerButton";
    private const string Y_CONTROLLER_BUTTON      = "YControllerButton";
    private const string A_CONTROLLER_BUTTON      = "AControllerButton";
    private const string RB_CONTROLLER_BUTTON     = "RBControllerButton";
    private const string LB_CONTROLLER_BUTTON     = "LBControllerButton";
    private const string RT_LT_MOVEMENT = "RTLTTriggers";

    #endregion
    #region Button Pushes
    private static bool ButtonPush(string buttonName)
    {
        return Input.GetButton(buttonName);
    }
    public static bool AButtonPush()
    {
        return ButtonPush(A_CONTROLLER_BUTTON);
    }
    public static bool BButtonPush()
    {
        return ButtonPush(B_CONTROLLER_BUTTON);
    }
    public static bool YButtonPush()
    {
        return ButtonPush(Y_CONTROLLER_BUTTON);
    }
    public static bool XButtonPush()
    {
        return ButtonPush(X_CONTROLLER_BUTTON);
    }
    public static bool RBButtonPush()
    {
        return ButtonPush(RB_CONTROLLER_BUTTON);
    }
    public static bool LBButtonPush()
    {
        return ButtonPush(LB_CONTROLLER_BUTTON);
    }
    #endregion

    #region joyistic movements
    private static float JoyisticPush(string joysticName)
    {
        return Input.GetAxis(joysticName);
    }
    public static float RightJoysticHorizontalMovement()
    {
        return JoyisticPush(RIGHT_JOYSTIC_HORIZONTAL);
    }
    public static float RightJoysticVerticalMovement()
    {
        return JoyisticPush(RIGHT_JOYSTIC_VERTICAL);
    }
    public static float LeftJoysticHorizontalMovement()
    {
        return JoyisticPush(LEFT_JOYSTIC_HORIZONTAL);
    }
    public static float LeftJoysticVerticalMovement()
    {
        return JoyisticPush(LEFT_JOYSTIC_VERTICAL);
    }
    private static bool RTMovementOccuring(float input)
    {
        return input > 0.0f;
    }
    private static bool LTMovementOccuring(float input)
    {
        return input < 0.0f;
    }
    //public static bool RTMovementOccuring()
    //{
    //    float inputMade = JoyisticPush(RT_MOVEMENT);
    //    return RTMovementOccuring(inputMade);
    //}
    //public static bool LTMovementOccuring()
    //{
    //    float inputMade = JoyisticPush(LT_MOVEMENT);
    //    return LTMovementOccuring(inputMade);
    //}
    public static float RTMovement()
    {
        float inputMade = JoyisticPush(RT_LT_MOVEMENT);
        if(!RTMovementOccuring(inputMade))
        {
            inputMade = 0.0f;
        }
        return inputMade;
    }
    public static float LTMovement()
    {
        float inputMade = JoyisticPush(RT_LT_MOVEMENT);
        if (!LTMovementOccuring(inputMade))
        {
            inputMade = 0.0f;
        }
        return inputMade;
    }
    #endregion
    private static Vector3 DirectionMovementByJoysticMovement(Func<float> horinzontalMovement, Func<float> verticalMovement)
    {
        float horizontalJoyisticMovement = horinzontalMovement();
        float verticalJoyisticMovement   = verticalMovement();
        return new Vector3(-verticalJoyisticMovement, 0, -horizontalJoyisticMovement);
    }
    public static Vector3 DirectionMovementByRightJoysticMovement()
    {
        return DirectionMovementByJoysticMovement(RightJoysticHorizontalMovement, RightJoysticVerticalMovement);
    }
    public static Vector3 DirectionMovementByLeftJoysticMovement()
    {
        return DirectionMovementByJoysticMovement(LeftJoysticHorizontalMovement, LeftJoysticVerticalMovement);
    }
    public static bool BothJoysticsMoving()
    {
        Vector3 directionRightJoystic = DirectionMovementByRightJoysticMovement();
        Vector3 directionLeftJoystic  = DirectionMovementByLeftJoysticMovement();
        return BothJoysticsMoving(directionRightJoystic, directionLeftJoystic);
    }
    public static bool BothJoysticsMoving(Vector3 directionRightJoystic, Vector3 directionLeftJoystic)
    {
        //Debug.Log("directionRightJoystic" + directionRightJoystic + " directionLeftJoystic" + directionLeftJoystic);
        return directionRightJoystic != Vector3.zero && directionLeftJoystic != Vector3.zero;
    }
}
