﻿using System.Collections.Generic;

public interface IParentMessage
{
    WebLVCMessage Transform(string message);
}