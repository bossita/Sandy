﻿internal interface IChildMessage
{
    WebLVCMessage Parse(string message);
    void HandleMessage();
}