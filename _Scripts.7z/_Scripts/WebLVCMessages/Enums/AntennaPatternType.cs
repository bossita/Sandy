﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for Radio Communication Antenna Pattern.
/// </summary>
public enum AntennaPatternType
{
    OmniDirectional = 0,
    Beam = 1,
    SphericalHarmonic = 2
}
