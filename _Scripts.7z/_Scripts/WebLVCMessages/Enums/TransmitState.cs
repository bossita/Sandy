﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for Radio Communication Transmission State.
/// </summary>
public enum TransmitState
{
    Off= 0,
    OnButNotTransmitting= 1,
    OnAndTransmitting= 2
}
