﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for dead reckoning values in entities and aggregates according to DIS and RPR.
/// </summary>
public enum DeadReckoning
{
    Other = 0,
    Static = 1,
    DrmFpw = 2,
    DrmRpw = 3,
    DrmRvw = 4,
    DrmFvw = 5,
    DrmFpb = 6,
    DrmRpb = 7,
    DrmRvb = 8,
    DrmFvb = 9
}
