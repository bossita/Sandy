﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for scenario control.
/// </summary>
public enum ScenarioControlState
{

    Rewind = 0,
    Pause = 1,
    Play = 2
}
