﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for Radio Communication Modulation.
/// </summary>
public enum MajorModulation
{
    NoStatement = 0,
    Amplitude = 1,
    AmplitudeAndAngle = 2,
    Angle = 3,
    Combination = 4,
    Pulse = 5,
    Unmodulated = 6,
    CarrierPhaseShiftModulation = 7
}
