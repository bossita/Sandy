﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for the source of the Radio Communication
/// </summary>
public enum InputSource
{
    Other = 0,
    Pilot = 1,
    Copilot = 2,
    FirstOfficer = 3,
    Driver = 4,
    Loader = 5,
    Gunner = 6,
    Commander = 7,
    DigitalDataDevice = 8,
    Intercom = 9,
    AudioJammer = 10,
    DataJammer = 11,
    GPSJammer = 12,
    GPSMeaconer = 13
}