﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for force type.
/// </summary>
public enum Force
{
    Other = 0,
    Friendly = 1,
    Opposing = 2,
    Neutral = 3
}