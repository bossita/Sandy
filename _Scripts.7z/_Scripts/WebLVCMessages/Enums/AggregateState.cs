﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for state values in aggregate objects.
/// </summary>
public enum AggregateState
{
    Other = 0,
    Aggregated = 1,
    Disaggregated = 2,
    FullyDisaggregated = 3,
    PseudoDisaggregated = 4,
    PartiallyDisaggregated = 5
}
