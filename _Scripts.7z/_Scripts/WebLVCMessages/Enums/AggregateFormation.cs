﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Enum for formation values in aggregate objects.
/// </summary>
public enum AggregateFormation
{
    Other = 0,
    Assembly = 1,
    Vee = 2,
    Wedge = 3,
    Line = 4,
    Column = 5
}
