﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.TestTools;
using Newtonsoft.Json;
using UnityEngine.Assertions;

public class StandartMessagesTest
{
        //[UnityTest]
        //public void ConnectMessageDoubleTest()
        //{
        //    ConnectMessage connectMessage = new ConnectMessage() { ClientName = "client", WebLVCVersion = 1.0f };
        //    string serializedConnectMessage = Newtonsoft.Json.JsonConvert.SerializeObject(connectMessage);
        //    ConnectMessage DeserializedConnectMessage = (Newtonsoft.Json.JsonConvert.DeserializeObject(serializedConnectMessage) as ConnectMessage);
        //    Assert.IsTrue(connectMessage.Equals(DeserializedConnectMessage));
        //}

        //[UnityTest]
        //public void ConnectMessageSerializeTest()
        //{
        //    string connectMessage = "{\n“MessageKind” : 2,\n“InteractionType” : “WebLVC: RadioSignalInteraction”,\n“RadioIdentifier” : ““[1, 1, 3001]-1”,\n“EncodingClass” : “Tank2”,\n“EncodingType” : 0,\n“SampleRate” : 44056,\n“SampleData” : “base64:...”\n}";
        //    WebLVCRadioSignalInteractionMessage DeserializedConnectMessage = (Newtonsoft.Json.JsonConvert.DeserializeObject(connectMessage) as WebLVCRadioSignalInteractionMessage);
        //    Assert.IsFalse(DeserializedConnectMessage == null);
        //}
}
