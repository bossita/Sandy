﻿using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

namespace Tests
{
    //public class MessageTest
    //{
    //    // A Test behaves as an ordinary method
    //    [UnityTest]
    //    public IEnumerator MessageTestSimplePasses()
    //    {
    //        string physicalEntityMessage = @"{'MessageKind' : 1,'ObjectName' : 'F-16 Alpha','ObjectType' : 'WebLVC:PhysicalEntity','EntityIdentifier' : [1,2,1],'EntityType' : [1,2,225,1,3,0,0],'WorldLocation' : [4437182.0232, -395338.0731, 873923.4663],'VelocityVector' : [57.04, 32.77, 89.263],'Orientation' : [-1.65, 2.234, -0.771],'Marking' : 'F-16','DamageState' : 1,'EngineSmokeOn' : true,'IsConcealed' : false}";
    //        WebLVCPhysicalEntityMessage deserializedConnectMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<WebLVCPhysicalEntityMessage>(physicalEntityMessage);
    //        Debug.Log(JsonConvert.SerializeObject(deserializedConnectMessage, Formatting.Indented));
    //        Assert.IsFalse(deserializedConnectMessage == null);
    //        return null;
    //    }
    //}
}
