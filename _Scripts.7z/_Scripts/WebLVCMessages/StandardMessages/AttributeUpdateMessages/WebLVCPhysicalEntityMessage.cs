﻿using System;
using System.Linq;
using Newtonsoft.Json;
using UnityEngine;

/// <summary>
/// The WebLVC:PhysicalEntity attribute message is used to represent the DIS/RPR
/// concept of an individual simulated vehicle or human.
/// </summary>
[System.Serializable]
public class WebLVCPhysicalEntityMessage : AttributeUpdateMessage, IChildMessage
{
    /// <summary>
    /// DIS-style simulation object identifier expressed as an array of three
    /// numbers representing SiteID, ApplicationID, and EntityNumber, for example,
    /// [1,2,3].
    /// </summary>
    [JsonProperty("EntityIdentifier")]
    public int[] EntityIdentifier { get; set; }

    #region EntityIdentifier helper functions
    public int GetSiteID()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[0];
    }

    public int GetApplicationID()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[1];
    }

    public int GetEntityNumber()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[2];
    }
    #endregion

    /// <summary>
    /// DIS-style simulation object type expressed as an array of seven
    /// numbers representing EntityKind, Domain, CountryCode, Category, Subcategory,
    /// Specific, and Extra, as defined by the SISO Enumerations document, for example,
    /// [1,2,225,1,6,0,0]. Required only in the first update sent for a particular simulation
    /// object, or upon change.
    /// </summary>
    [JsonProperty("EntityType")]
    public int[] EntityType { get; set; }

    #region EntityType helper functions
    public int GetEntityKind()
    {
        return this.EntityType == null ? 0 : this.EntityType[0];
    }

    public int GetDomain()
    {
        return this.EntityType == null ? 0 : this.EntityType[1];
    }

    public int GetCountryCode()
    {
        return this.EntityType == null ? 0 : this.EntityType[2];
    }

    public int GetCategory()
    {
        return this.EntityType == null ? 0 : this.EntityType[3];
    }

    public int GetSubcategory()
    {
        return this.EntityType == null ? 0 : this.EntityType[4];
    }

    public int GetSpecific()
    {
        return this.EntityType == null ? 0 : this.EntityType[5];
    }

    public int GetExtra()
    {
        return this.EntityType == null ? 0 : this.EntityType[6];
    }
    #endregion

    /// <summary>
    /// A number representing the dead-reckoning algorithm
    /// to use for the simulation object, as defined by the SISO Enumerations document,
    /// for example, 4 for “DRM(RVW)”.
    /// </summary>
    [JsonProperty("DeadReckoningAlgorithm")]
    public int DeadReckoningAlgorithm { get; set; }

    /// <summary>
    /// Arrays of three numbers representing
    /// the X, Y, and Z components of world location, velocity, and acceleration, as
    /// defined by DIS/RPR, for example, [4437182.0232, -395338.0731, 873923.4663].
    /// </summary>
    [JsonProperty("WorldLocation")]
    public double[] WorldLocationXYZ { get; set; }

    /// <summary>
    /// Arrays of three numbers representing
    /// the X, Y, and Z components of world location, velocity, and acceleration, as
    /// defined by DIS/RPR, for example, [4437182.0232, -395338.0731, 873923.4663].
    /// </summary>
    [JsonProperty("VelocityVector")]
    public double[] VelocityVectorXYZ { get; set; }

    /// <summary>
    /// Arrays of three numbers representing
    /// the X, Y, and Z components of world location, velocity, and acceleration, as
    /// defined by DIS/RPR, for example, [4437182.0232, -395338.0731, 873923.4663].
    /// </summary>
    [JsonProperty("AccelerationVector")]
    public double[] AccelerationVectorXYZ { get; set; }

    /// <summary>
    /// An array of three numbers representing the psi, theta, and phi components
    /// of the simulation object’s orientation as defined by DIS/RPR, for example,
    /// [-1.65, 2.234, -0.771].
    /// </summary>
    [JsonProperty("Orientation")]
    public double[] OrientationPsiThetaPhi { get; set; }

    /// <summary>
    /// An array of three numbers representing the X, Y, and Z components
    /// of angular velocity, as defined by DIS/RPR, for example, [0.37, 1.30, -1.43].
    /// </summary>
    [JsonProperty("AngularVelocity")]
    public double[] AngularVelocityXYZ { get; set; }

    /// <summary>
    /// A number representing the ForceIdentifier of the simulation object,
    /// as defined by DIS/RPR.
    /// </summary>
    [JsonProperty("ForceIdentifier")]
    public int ForceIdentifier { get; set; }

    /// <summary>
    /// A string representing the marking text of the simulation object, as
    /// defined by DIS/RPR.
    /// </summary>
    [JsonProperty("Marking")]
    public string Marking { get; set; }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<WebLVCPhysicalEntityMessage>(message);
    }

    public void HandleMessage()
    {
        // create manager that holds all objects and positions in double[]
        // change this function to be based on the manager
        // change create entity function to actually create entity
        // check which other messages we need to know how to use
        // check which other messages we know how to use
        string objectName = this.ObjectName.Replace(':', '_');
        GameObject gameObjectEntity = null;
        EntityInformation pair = null;
        MessagesHandler.EntitiesRepository?.Entities.TryGetValue(objectName, out pair);
        bool firstTime = false;
        gameObjectEntity = pair?.gameObject;
        if (gameObjectEntity == null)
        {
            gameObjectEntity = MessagesHandler.CreateEntity(this);
            firstTime = true;
        }
        if (gameObjectEntity != null)
        {
            MessagesHandler.UpdateEntity(this, gameObjectEntity, firstTime);
        }
    }

    public ReflectedEntity ToReflectedEntity()
    {
        return new ReflectedEntity(this.ObjectName)
        {
            entityIdentifier = new EntityIdentifierDIS()
            {
                SiteID = this.GetSiteID(),
                ApplicationID = this.GetApplicationID(),
                EntityNumber = this.GetEntityNumber(),
            },
            entityType = new EntityTypeDIS()
            {
                EntityKind = this.GetEntityKind(),
                Domain = this.GetDomain(),
                CountryCode = this.GetCountryCode(),
                Category = this.GetCategory(),
                Subcategory = this.GetSubcategory(),
                Specific = this.GetSpecific(),
                Extra = this.GetExtra(),
            },
            forceIdentifier = this.ForceIdentifier,
            marking = this.Marking,
            damageState = this.DamageState,
            lastWorldLocation = Vector3d.From3DArray(this.WorldLocationXYZ),
            lastVelocity = Vector3d.From3DArray(this.VelocityVectorXYZ),
            lastAcceleration = Vector3d.From3DArray(this.AccelerationVectorXYZ),
            lastRotation = Vector3d.From3DArray(this.OrientationPsiThetaPhi),
            lastAngularVelocity = Vector3d.From3DArray(this.AngularVelocityXYZ),
            lastTimeUpdatedUnity = Time.realtimeSinceStartup,
    };
    }

    // use for less resource allocations
    public void AssignToReflectedEntity(ReflectedEntity reflectedEntity)
    {
        AssignToReflectedEntity(reflectedEntity, Time.realtimeSinceStartup);
    }

    public void AssignToReflectedEntity(ReflectedEntity reflectedEntity, float lastTimeUpdatedUnity)
    {
        // EntityIdentifier
        reflectedEntity.entityIdentifier.SiteID = this.GetSiteID();
        reflectedEntity.entityIdentifier.ApplicationID = this.GetApplicationID();
        reflectedEntity.entityIdentifier.EntityNumber = this.GetEntityNumber();

        // EntityType
        reflectedEntity.entityType.EntityKind = this.GetEntityKind();
        reflectedEntity.entityType.Domain = this.GetDomain();
        reflectedEntity.entityType.CountryCode = this.GetCountryCode();
        reflectedEntity.entityType.Category = this.GetCategory();
        reflectedEntity.entityType.Subcategory = this.GetSubcategory();
        reflectedEntity.entityType.Specific = this.GetSpecific();
        reflectedEntity.entityType.Extra = this.GetExtra();

        reflectedEntity.forceIdentifier = this.ForceIdentifier;
        reflectedEntity.marking = this.Marking;
        reflectedEntity.damageState = this.DamageState;
        reflectedEntity.lastWorldLocation = Vector3d.From3DArray(this.WorldLocationXYZ);
        reflectedEntity.lastVelocity = Vector3d.From3DArray(this.VelocityVectorXYZ);
        reflectedEntity.lastAcceleration = Vector3d.From3DArray(this.AccelerationVectorXYZ);
        reflectedEntity.lastRotation = Vector3d.From3DArray(this.OrientationPsiThetaPhi);
        reflectedEntity.lastAngularVelocity = Vector3d.From3DArray(this.AngularVelocityXYZ);

        reflectedEntity.lastTimeUpdatedUnity = lastTimeUpdatedUnity;
    }

    // TODO: probably not used for DIS based WebLVC
    #region Appearance Attributes (defined by the RPRFOM)
    [JsonProperty("DamageState")]
    public DamageStateEnum DamageState { get; set; }

    [JsonProperty("EngineSmokeOn")]
    public bool EngineSmokeOn { get; set; }

    [JsonProperty("FlamesPresent")]
    public bool FlamesPresent { get; set; }

    [JsonProperty("HatchState")]
    public int HatchState { get; set; }

    [JsonProperty("Immobilized")]
    public bool Immobilized { get; set; }

    [JsonProperty("PersonStanceCode")]
    public int PersonStanceCode { get; set; }

    [JsonProperty("PowerPlantOn")]
    public bool PowerPlantOn { get; set; }

    [JsonProperty("RampDeployed")]
    public bool RampDeployed { get; set; }

    [JsonProperty("SmokePlumePresent")]
    public bool SmokePlumePresent { get; set; }

    [JsonProperty("TentDeployed")]
    public bool TentDeployed { get; set; }

    [JsonProperty("TrailingEffectsCode")]
    public int TrailingEffectsCode { get; set; }

    [JsonProperty("CamouflageType")]
    public int CamouflageType { get; set; }

    [JsonProperty("FirePowerDisabled")]
    public bool FirePowerDisabled { get; set; }

    [JsonProperty("IsConcealed")]
    public bool IsConcealed { get; set; }
    #endregion
}
