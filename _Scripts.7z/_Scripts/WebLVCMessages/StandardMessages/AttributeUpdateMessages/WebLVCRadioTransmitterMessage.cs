﻿using Newtonsoft.Json;

/// <summary>
/// The WebLVC:RadioTransmitter attribute update message is used to represent a device
/// that transmits electromagnetic energy in the radio frequency range.
/// </summary>
public class WebLVCRadioTransmitterMessage : AttributeUpdateMessage, IChildMessage
{
    /// <summary>
    /// String representing the object that this radio is attached to. This
    /// identifier is unique across the simulation.
    /// </summary>
    [JsonProperty("HostObjectName")]
    public string HostObjectName { get; set; }

    /// <summary>
    /// DIS-style entity identifier expressed as an array of three numbers
    /// representing SiteID, ApplicationID, and EntityNumber, for example, [1,2,3].
    /// Identifies the ID of the radio.This is the same as the host object name when the
    /// radio is coming from DIS.
    /// </summary>
    [JsonProperty("EntityIdentifier")]
    public int[] EntityIdentifier { get; set; }

    #region EntityIdentifier helper functions
    public int GetSiteID()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[0];
    }

    public int GetApplicationID()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[1];
    }

    public int GetEntityNumber()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[2];
    }
    #endregion

    /// <summary>
    /// A number used to identify the radio transmitter within the scope of
    /// the entity.
    /// </summary>
    [JsonProperty("RadioIndex")]
    public int RadioIndex { get; set; }

    /// <summary>
    /// DIS-style radio type expressed as an array of six numbers representing
    /// entity kind domain, country, category, nomenclature version, and nomenclature.
    /// See Radio in the SISO Enumerations document.
    /// </summary>
    [JsonProperty("RadioEntityType")]
    public int[] RadioEntityType { get; set; }

    #region RadioEntityType helper functions
    public int GetEntityKindDomain()
    {
        return this.RadioEntityType == null ? 0 : this.RadioEntityType[0];
    }

    public int GetCountry()
    {
        return this.RadioEntityType == null ? 0 : this.RadioEntityType[1];
    }

    public int GetCategory()
    {
        return this.RadioEntityType == null ? 0 : this.RadioEntityType[2];
    }

    public int GetNomenclatureVersion()
    {
        return this.RadioEntityType == null ? 0 : this.RadioEntityType[3];
    }

    public int GetNomenclature()
    {
        return this.RadioEntityType == null ? 0 : this.RadioEntityType[4];
    }
    #endregion

    /// <summary>
    /// A number indicating the state of the transmitter (whether it is off,
    /// on but not transmitting, or on and transmitting), as defined by the SISO enumerations
    /// document(see Transmit State).
    /// </summary>
    [JsonProperty("TransmitState")]
    public int TransmitState { get; set; }

    /// <summary>
    /// A number representing the source of the radio transmission (for
    /// example, pilot, copilot, driver, and so on), as defined in the SISO Enumerations
    /// document(see Input Source).
    /// </summary>
    [JsonProperty("InputSource")]
    public int InputSource { get; set; }

    /// <summary>
    /// An array of three numbers representing the world location
    /// of the radiating portion of the transmitter, as defined by the coordinate reference
    /// system, for example, [4437182.0232, - 395338.0731, 873923.4663] for ECEF as
    /// in DIS/RPR.
    /// </summary>
    [JsonProperty("WorldAntennaLocation")]
    public double[] WorldAntennaLocation { get; set; }

    /// <summary>
    /// Arrays of three numbers representing the X, Y, and Z
    /// components of relative location of the radiating portion of the transmitter, as
    /// defined by DIS/RPR, for example, [1.0, 0.0, -3.0].
    /// </summary>
    [JsonProperty("RelativeAntennaLocation")]
    public double[] RelativeAntennaLocationXYZ { get; set; }

    /// <summary>
    /// A number representing the radiation pattern of the antenna,
    /// as defined in the SISO Enumerations document(see Antenna Pattern Type). Its
    /// value determines the content of the AntennaPatternParameters property.
    /// </summary>
    [JsonProperty("AntennaPatternType")]
    public int AntennaPatternType { get; set; }

    /// <summary>
    /// A number representing the center frequency used by the radio in transmission.
    /// Expressed as a positive integer number in units of hertz.
    /// </summary>
    [JsonProperty("Frequency")]
    public long Frequency { get; set; }

    /// <summary>
    /// A number representing the bandpass of the radio, expressed as
    /// a position floating point number in units of hertz.
    /// </summary>
    [JsonProperty("TransmitBandwidth")]
    public int TransmitBandwidth { get; set; }

    /// <summary>
    /// A number representing the average power being transmitted in units of
    /// decibel-milliwatts.
    /// </summary>
    [JsonProperty("Power")]
    public double Power { get; set; }

    /// <summary>
    /// A JSON object representing the type of modulation used for
    /// radio transmission.
    /// </summary>
    [JsonProperty("ModulationType")]
    public ModulationType ModulationType { get; set; }

    /// <summary>
    /// A number representing the crypto mode (baseband or phase), as
    /// defined in the SISO Enumerations document.
    /// </summary>
    [JsonProperty("CryptoMode")]
    public int CryptoMode { get; set; }

    /// <summary>
    /// A number representing the use of crypto or secure voice equipment,
    /// as defined in the SISO Enumerations document.
    /// </summary>
    [JsonProperty("CryptoSystem")]
    public int CryptoSystem { get; set; }

    /// <summary>
    /// A number representing the encryption key (if encryption is in use),
    /// zero otherwise.
    /// </summary>
    [JsonProperty("CryptoKey")]
    public long CryptoKey { get; set; }

    /// <summary>
    /// A JSON object that may be present, depending on the
    /// value of the AntennaPatternType property(DIS/RPR Beam Antenna Pattern
    /// record).
    /// </summary>
    [JsonProperty("AntennaPatternParameters")]
    public AntennaPatternParameters AntennaPatternParameters { get; set; }

    /// <summary>
    /// A Boolean indicating whether or not frequency hopping is in use.
    /// </summary>
    [JsonProperty("FrequencyHopInUse")]
    public bool FrequencyHopInUse { get; set; }

    /// <summary>
    /// A Boolean indicating whether or not pseudo noise is in use.
    /// </summary>
    [JsonProperty("PseudoNoiseInUse")]
    public bool PseudoNoiseInUse { get; set; }

    /// <summary>
    /// A Boolean indicating whether or not time hopping is in use.
    /// </summary>
    [JsonProperty("TimeHopInUse")]
    public bool TimeHopInUse { get; set; }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<WebLVCRadioTransmitterMessage>(message);
    }

    public void HandleMessage()
    {
        throw new System.NotImplementedException();
    }
}

/// <summary>
/// A JSON object representing the type of modulation used for
/// radio transmission.
/// </summary>
public class ModulationType
{
    /// <summary>
    /// A number representing the spread spectrum technique in use,
    /// as defined in the SISO Enumerations document.
    /// </summary>
    [JsonProperty("SpreadSpectrum")]
    public int SpreadSpectrum { get; set; }

    /// <summary>
    /// A number representing the major classification of the modulation type, as
    /// defined in the SISO Enumerations document.
    /// </summary>
    [JsonProperty("Major")]
    public int Major { get; set; }

    /// <summary>
    /// A number representing certain detailed information depending on the
    /// major modulation type, as defined in the SISO Enumerations document.
    /// </summary>
    [JsonProperty("Detail")]
    public int Detail { get; set; }

    /// <summary>
    /// A number used to specify the interpretation of the Modulation Parameter
    /// fields in the RadioTransmitterUpdate message, as defined in the SISO
    /// Enumerations document.
    /// </summary>
    [JsonProperty("System")]
    public int System { get; set; }
}

/// <summary>
/// A JSON object that may be present, depending on the
/// value of the AntennaPatternType property(DIS/RPR Beam Antenna Pattern
/// record).
/// </summary>
public class AntennaPatternParameters
{
    /// <summary>
    /// An array of three numbers representing the psi, theta, and phi
    /// components of the beam direction as defined by DIS/RPR, e.g. [-1.65, 2.234,
    /// -0.771].
    /// </summary>
    [JsonProperty("BeamDirection")]
    public double[] BeamDirectionPsiThetaPhi { get; set; }

    /// <summary>
    /// A number representing the full width of the beam to the -3
    /// dB power density points in the x-y plane of the beam coordinate system, in
    /// radians.
    /// </summary>
    [JsonProperty("AzimuthBeamwidth")]
    public double AzimuthBeamwidth { get; set; }

    /// <summary>
    /// A number representing the full width of the beam to the
    /// -3 dB power density points in the x-z plane of the beam coordinate system, in
    /// radians.
    /// </summary>
    [JsonProperty("ElevationBeamwidth")]
    public double ElevationBeamwidth { get; set; }

    /// <summary>
    /// A number specifying the reference coordinate system with
    /// respect to which the beam direction is specified, as defined in the SISO Enumerations
    /// document.
    /// </summary>
    [JsonProperty("ReferenceSystem")]
    public int ReferenceSystem { get; set; }

    /// <summary>
    /// A number representing the DIS/RPR concept of the magnitude of the
    /// Z-component(in beam coordinates) of the Electrical field.
    /// </summary>
    [JsonProperty("Ez")]
    public double Ez { get; set; }

    /// <summary>
    /// A number representing the DIS/RPR concept of the magnitude of the
    /// X-component(in beam coordinates) of the Electrical field.
    /// </summary>
    [JsonProperty("Ex")]
    public double Ex { get; set; }

    /// <summary>
    /// A number representing the phase angle between Ez and Ex in radians.
    /// </summary>
    [JsonProperty("Phase")]
    public double Phase { get; set; }
}