﻿using Newtonsoft.Json;

/// <summary>
/// The WebLVC:EnvironmentalEntity attribute message is used to represent the
/// DIS/RPR concept of an environmental process object.
/// </summary>
public class WebLVCEnvironmentalEntityMessage : AttributeUpdateMessage, IChildMessage
{
    /// <summary>
    /// DIS-style entity type expressed as an array of seven numbers representing Entity-
    /// Kind, Domain, CountryCode, Category, Subcategory, Specific, and Extra, as defined
    /// by the SISO Enumerations document, for example, [1,4,0,0,0,0,0]. Required only in
    /// the first update sent for a particular environmental entity, or upon change.
    /// </summary>
    [JsonProperty("Type")]
    public int[] Type { get; set; }

    #region Type helper functions
    public int GetEntityKind()
    {
        return this.Type == null ? 0 : this.Type[0];
    }

    public int GetDomain()
    {
        return this.Type == null ? 0 : this.Type[1];
    }

    public int GetCountryCode()
    {
        return this.Type == null ? 0 : this.Type[2];
    }

    public int GetCategory()
    {
        return this.Type == null ? 0 : this.Type[3];
    }

    public int GetSubcategory()
    {
        return this.Type == null ? 0 : this.Type[4];
    }

    public int GetSpecific()
    {
        return this.Type == null ? 0 : this.Type[5];
    }

    public int GetExtra()
    {
        return this.Type == null ? 0 : this.Type[6];
    }
    #endregion

    /// <summary>
    /// DIS-style identifier expressed as an array of three numbers representing
    /// SiteID, ApplicationID, and EntityNumber, for example, [1,2,3].
    /// </summary>
    [JsonProperty("ProcessIdentifier")]
    public int[] ProcessIdentifier { get; set; }

    #region ProcessIdentifier helper functions
    public int GetSiteID()
    {
        return this.ProcessIdentifier == null ? 0 : this.ProcessIdentifier[0];
    }

    public int GetApplicationID()
    {
        return this.ProcessIdentifier == null ? 0 : this.ProcessIdentifier[1];
    }

    public int GetEntityNumber()
    {
        return this.ProcessIdentifier == null ? 0 : this.ProcessIdentifier[2];
    }

    #endregion

    /// <summary>
    /// An unsigned integer identifier for the model used for generating this
    /// environmental process.The value is exercise-specific.
    /// </summary>
    [JsonProperty("ModelType")]
    public uint ModelType { get; set; }

    /// <summary>
    /// Boolean status of the environment process, indicating
    /// whether or not it is active.
    /// </summary>
    [JsonProperty("EnvironmentProcessActive")]
    public bool EnvironmentProcessActive { get; set; }

    // TODO: what to do with EP_NO_SEQUENCE - ??? - is it a value from SISO?

    /// <summary>
    /// An integer value used in tagging a series of attribute update
    /// messages with unique values.If used, the value should start with zero and increment
    /// by one for each update sent.If not used, the value should be set to
    /// EP_NO_SEQUENCE.
    /// </summary>
    [JsonProperty("SequenceNumber")]
    public int SequenceNumber { get; set; }

    /// <summary>
    /// An array of one or more GeometryRecords, used to describe the
    /// physical extent of the object.
    /// </summary>
    [JsonProperty("GeometryRecords")]
    public GeometryRecord[] GeometryRecords { get; set; }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<WebLVCEnvironmentalEntityMessage>(message);
    }

    public void HandleMessage()
    {
        //throw new System.NotImplementedException();
    }
}

/// <summary>
/// A GeometryRecord is a JSON object containing the following fields.
/// </summary>
public class GeometryRecord
{
    /// <summary>
    /// A string identifying the type of geometry record, “LineString”,
    /// “Polygon”, “Point”, or “Line”.
    /// </summary>
    [JsonProperty("Type")]
    public string Type { get; set; }

    /// <summary>
    /// The coordinates of the vertex or vertices of the object. The format
    /// of the contents of this field depends on the type and the coordinate reference
    /// system.Each coordinate vertex is expressed as an array of three numbers, either
    /// [x, y, z] for geocentric Cartesian coordinate reference systems, or[latitude, longitude,
    /// altitude] for geodetic coordinate reference systems.
    /// </summary>
    [JsonProperty("coordinates")]
    public double[,] Coordinates { get; set; }

    // TODO: add implementation for all 4 geometric types type
}