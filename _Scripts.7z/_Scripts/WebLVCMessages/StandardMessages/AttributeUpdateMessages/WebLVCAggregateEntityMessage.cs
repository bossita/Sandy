﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// The WebLVC:AggregateEntity attribute message is used to represent the DIS/RPR
/// concept of a hierarchical unit.
/// </summary>
public class WebLVCAggregateEntityMessage : AttributeUpdateMessage, IChildMessage
{
    /// <summary>
    /// DIS-style simulation object identifier expressed as an array of three
    /// numbers representing SiteID, ApplicationID, and EntityNumber, for example,
    /// [1,2,3].
    /// </summary>
    [JsonProperty("EntityIdentifier")]
    public int[] EntityIdentifier { get; set; }

    #region EntityIdentifier helper functions
    public int GetSiteID()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[0];
    }

    public int GetApplicationID()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[1];
    }

    public int GetEntityNumber()
    {
        return this.EntityIdentifier == null ? 0 : this.EntityIdentifier[2];
    }
    #endregion

    /// <summary>
    /// DIS-style simulation object type expressed as an array of seven
    /// numbers representing EntityKind, Domain, CountryCode, Category, Subcategory,
    /// Specific, and Extra, as defined by the SISO Enumerations document, for example,
    /// [1,2,225,1,6,0,0]. Required only in the first update sent for a particular simulation
    /// object, or upon change.
    /// </summary>
    [JsonProperty("EntityType")]
    public int[] EntityType { get; set; }

    #region EntityType helper functions
    public int GetEntityKind()
    {
        return this.EntityType == null ? 0 : this.EntityType[0];
    }

    public int GetDomain()
    {
        return this.EntityType == null ? 0 : this.EntityType[1];
    }

    public int GetCountryCode()
    {
        return this.EntityType == null ? 0 : this.EntityType[2];
    }

    public int GetCategory()
    {
        return this.EntityType == null ? 0 : this.EntityType[3];
    }

    public int GetSubcategory()
    {
        return this.EntityType == null ? 0 : this.EntityType[4];
    }

    public int GetSpecific()
    {
        return this.EntityType == null ? 0 : this.EntityType[5];
    }

    public int GetExtra()
    {
        return this.EntityType == null ? 0 : this.EntityType[6];
    }
    #endregion

    /// <summary>
    /// A number representing the dead-reckoning algorithm
    /// to use for the simulation object, as defined by the SISO Enumerations document,
    /// for example, 4 for “DRM(RVW)”.
    /// </summary>
    [JsonProperty("DeadReckoningAlgorithm")]
    public int DeadReckoningAlgorithm { get; set; }

    /// <summary>
    /// Arrays of three numbers representing
    /// the X, Y, and Z components of world location, velocity, and acceleration, as
    /// defined by DIS/RPR, for example, [4437182.0232, -395338.0731, 873923.4663].
    /// </summary>
    [JsonProperty("WorldLocation")]
    public double[] WorldLocationXYZ { get; set; }

    /// <summary>
    /// An array of three numbers representing the X, Y, and Z components
    /// of world velocity, as defined by DIS/RPR, for example, [89.0232, -38.5, 42.322]
    /// </summary>
    [JsonProperty("VelocityVector")]
    public double[] VelocityVectorXYZ { get; set; }

    /// <summary>
    /// An array of three numbers representing the psi, theta, and phi components
    /// of the simulation object’s orientation as defined by DIS/RPR, for example,
    /// [-1.65, 2.234, -0.771].
    /// </summary>
    [JsonProperty("Orientation")]
    public double[] OrientationPsiThetaPhi { get; set; }

    /// <summary>
    /// An array of three numbers representing the X, Y, and Z components
    /// of angular velocity, as defined by DIS/RPR, for example, [0.37, 1.30, -1.43].
    /// </summary>
    [JsonProperty("AngularVelocity")]
    public double[] AngularVelocityXYZ { get; set; }

    /// <summary>
    /// A number representing the ForceIdentifier of the simulation object,
    /// as defined by DIS/RPR.
    /// </summary>
    [JsonProperty("ForceIdentifier")]
    public int ForceIdentifier { get; set; }

    /// <summary>
    /// A string representing the marking text of the simulation object, as
    /// defined by DIS/RPR.
    /// </summary>
    [JsonProperty("Marking")]
    public string Marking { get; set; }

    /// <summary>
    /// A number representing the aggregation/disaggregation state of the
    /// unit, as defined by DIS/RPR.
    /// </summary>
    [JsonProperty("AggregateState")]
    public int AggregateState { get; set; }

    /// <summary>
    /// A number representing the formation of the unit, as defined by DIS/RPR.
    /// </summary>
    [JsonProperty("Formation")]
    public double Formation { get; set; }

    /// <summary>
    /// An array of three numbers representing the bounding box that the
    /// unit occupies, as defined by DIS/RPR.The values are measured from the center of
    /// mass of the unit to the edge of the X, Y, and Z axes of the body coordinate system
    /// of the unit, where the axes are aligned with the unit’s orientation, for example, [2.0,
    /// 2.5, 1.75].
    /// </summary>
    [JsonProperty("Dimensions")]
    public double[] DimensionsXYZ { get; set; }

    /// <summary>
    /// An array of ObjectName values for those constituent entities that are
    /// also represented by individual object instances.
    /// </summary>
    [JsonProperty("Subordinates")]
    public string[] Subordinates { get; set; }

    /// <summary>
    /// List of ObjectName values for those constituent sub-units
    /// that are also represented by individual object instances.
    /// </summary>
    [JsonProperty("AggregateSubordinates")]
    public List<string> AggregateSubordinates { get; set; }

    // TODO: check if using tuple is the right choice

    /// <summary>
    /// An array of objects of the form {ObjectType, count} that represent
    /// the type and number of subordinate entities that are not represented by individual
    /// object instances.
    /// </summary>
    [JsonProperty("SilentEntities")]
    public Tuple<string, long>[] SilentEntities { get; set; }

    /// <summary>
    /// An array of objects of the form {ObjectType, count} that represent
    /// the type and number of subordinate units that are not represented by individual
    /// object instances.
    /// </summary>
    [JsonProperty("SilentAggregates")]
    public Tuple<string, long>[] SilentAggregates { get; set; }

    /// <summary>
    /// An array of objects of form {ObjectType, DamageState,
    /// count} representing the damage status of unpublished subordinate simulation
    /// object types. DamageState is the DIS/RPR enumerated value for damage state.
    /// Only entries with a damage state other than the default DamageStateNone need to
    /// be specified.
    /// </summary>
    [JsonProperty("SilentEntitiesDamageState")]
    public Tuple<string, int, long>[] SilentEntitiesDamageState { get; set; }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<WebLVCAggregateEntityMessage>(message);
    }

    public void HandleMessage()
    {
        string objectName = this.ObjectName.Replace(':', '_');

        // if already exists
        TreeNode<string> parentEntity = MessagesHandler.EntitiesRepository.Hierarchy.FindTreeNode(node => node.Data != null && node.Data.Contains(objectName));
        if (parentEntity == null)
        {
            MessagesHandler.AddToHierarchy(this);
        }
        MessagesHandler.UpdateAggregatedParent(this);
    }
}
