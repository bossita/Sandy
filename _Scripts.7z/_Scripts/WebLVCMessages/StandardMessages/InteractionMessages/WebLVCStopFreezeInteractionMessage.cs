﻿using Newtonsoft.Json;

/// <summary>
/// The WebLVC:StopFreeze message directs one or more simulators to stop simulating, or
/// stop simulation of a specific entity.
/// </summary>
public class WebLVCStopFreezeInteractionMessage : InteractionMessage, IChildMessage
{
    /// <summary>
    /// The DIS/RPR simulation ID of the receiving simulations, or the
    /// entity ID of a specific entity, expressed as an array of three numbers.The allowable
    /// values for the ID follow the DIS/RPR rules.
    /// </summary>
    [JsonProperty("ReceivingEntity")]
    public int[] ReceivingEntity { get; set; }

    #region ReceivingEntity helper functions
    public int GetReceivingEntitySiteID()
    {
        return this.ReceivingEntity == null ? 0 : this.ReceivingEntity[0];
    }

    public int GetReceivingEntityApplicationID()
    {
        return this.ReceivingEntity == null ? 0 : this.ReceivingEntity[1];
    }

    public int GetReceivingEntityEntityNumber()
    {
        return this.ReceivingEntity == null ? 0 : this.ReceivingEntity[2];
    }
    #endregion

    /// <summary>
    /// The DIS/RPR simulation ID (Site ID, Application ID) of the simulator
    /// requesting the start/resume action, expressed as an array of two numbers.
    /// </summary>
    [JsonProperty("OriginatingEntity")]
    public int[] OriginatingEntity { get; set; }

    #region OriginatingEntity helper functions
    public int GetOriginatingEntitySiteID()
    {
        return this.OriginatingEntity == null ? 0 : this.OriginatingEntity[0];
    }

    public int GetOriginatingEntityApplicationID()
    {
        return this.OriginatingEntity == null ? 0 : this.OriginatingEntity[1];
    }
    #endregion

    /// <summary>
    /// A number representing the real world time of the request, as
    /// defined by DIS/RPR.
    /// </summary>
    [JsonProperty("RealWorldTime")]
    public long RealWorldTime { get; set; }

    /// <summary>
    /// A number indicating the reason for stopping the simulation. Allowed
    /// values are an enumeration defined by DIS/RPR.
    /// </summary>
    [JsonProperty("Reason")]
    public int Reason { get; set; }

    /// <summary>
    /// A Boolean indicating whether the entity or entities should continue
    /// to reflect attributes while frozen.
    /// </summary>
    [JsonProperty("ReflectValues")]
    public bool ReflectValues { get; set; }

    /// <summary>
    /// A Boolean indicating whether the entity or entities
    /// should continue to run their internal simulation clocks while frozen.
    /// </summary>
    [JsonProperty("RunInternalSimulationClock")]
    public bool RunInternalSimulationClock { get; set; }

    /// <summary>
    /// A Boolean indicating whether the entity or entities should
    /// continue to update attributes while frozen.
    /// </summary>
    [JsonProperty("UpdateAttributes")]
    public bool UpdateAttributes { get; set; }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<WebLVCStopFreezeInteractionMessage>(message);
    }

    public void HandleMessage()
    {
        throw new System.NotImplementedException();
    }
}
