﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;

public class MakVrfSet : InteractionMessage, IChildMessage
{
    /// <summary>
    /// The object name of the VR-Forces simulation object
    /// whose state is to be set, or the string DtBroadcast to designate all VR-Forces simu-
    /// lation objects.
    /// </summary>
    [JsonProperty("ReceivingApplicationName")]
    public string ReceivingApplicationName;

    /// <summary>
    /// An array of one or more objects. Each object represents an indi-
    /// vidual request to set state in a VR-Forces simulation object. An object in this array
    /// contains the following required property:
    /// – name.A string identifying the particular aspect of state to be set.The allowed
    /// values are:
    /// • Destroy.Set the damage status of the simulation object to destroyed.
    /// • Restore.Restore the simulation object to full health and replenish resources.
    /// • Speed.Set the ordered speed of the simulation object. The simulation object
    /// will attempt to maintain this speed in any movement behaviors it executes.
    /// • ReactiveTaskCancel.Cancel the current reactive task the simulation object is
    /// executing (if any). For more information about reactive tasks, please see VR-
    /// Forces Users Guide.
    /// An object in this array may contain the following optional properties:
    /// – type.A string identifying the type of value to set for state.See “Scripted Task
    /// Documentation” in VR-Forces Developer’s Guide, for a list of the possible values
    /// for type.
    /// – value.A string, Boolean, number, object, or array containing the value of the
    /// state to set.Table 3-3 lists the expected value/types for each of the given
    /// MAK:VrfSet name strings.
    /// </summary>
    [JsonProperty("DataVariables")]
    public DataVariable[] DataVariables;

    ///// <summary>
    ///// A string identifying the name of the sending application.
    ///// </summary>
    //[JsonProperty("OriginatingApplicationName")]
    //public string OriginatingApplicationName;

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<MakVrfSet>(message);
    }

    public void HandleMessage()
    {
    }
}

public class DataVariable
{
    /// <summary>
    /// A string identifying the particular aspect of state to be set. The allowed
    /// values are:
    /// • Destroy.Set the damage status of the simulation object to destroyed.
    /// • Restore.Restore the simulation object to full health and replenish resources.
    /// • Speed.Set the ordered speed of the simulation object. The simulation object
    /// will attempt to maintain this speed in any movement behaviors it executes.
    /// • ReactiveTaskCancel.Cancel the current reactive task the simulation object is
    /// </summary>
    [JsonProperty("name")]
    public string name;

    /// <summary>
    /// A string identifying the type of value to set for state. See “Scripted Task
    /// Documentation” in VR-Forces Developer’s Guide, for a list of the possible values
    /// for type.
    /// </summary>
    [JsonProperty("type")]
    public string type;

    /// <summary>
    /// A string, Boolean, number, object, or array containing the value of the
    /// state to set.Table 3-3 lists the expected value/types for each of the given
    /// MAK:VrfSet name strings.
    /// </summary>
    [JsonProperty("value")]
    public double[] value;
}
