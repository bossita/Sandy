﻿using Newtonsoft.Json;

/// <summary>
/// The WebLVC:RadioSignal interaction message represents the wireless transmission and
/// reception of audio or digital data via electromagnetic waves.
/// </summary>
public class WebLVCRadioSignalInteractionMessage : InteractionMessage, IChildMessage
{
    /// <summary>
    /// A string representing the particular transmitter that is transmitting.
    /// This identifier is unique across the simulation.
    /// </summary>
    [JsonProperty("RadioIdentifier")]
    public string RadioIdentifier { get; set; }

    /// <summary>
    /// A number representing the encoding scheme being used, as defined
    /// by the SISO Enumerations document(see the Radio signal encoding class).
    /// </summary>
    [JsonProperty("EncodingClass")]
    public int EncodingClass { get; set; }

    /// <summary>
    /// A number representing the type of TDL message. If set to zero, this
    /// is not a TDL message.When this is a positive number, the number represents the
    /// type of TDL message, as defined by the SISO Enumerations document scheme
    /// being used, as defined by the SISO Enumerations document as (see the Radio
    /// signal encoding type).
    /// </summary>
    [JsonProperty("EncodingType")]
    public int EncodingType { get; set; }

    /// <summary>
    /// A number representing the type of TDL message included in the signal
    /// message, as defined by the SISO Enumerations document(see TDL Type).
    /// </summary>
    [JsonProperty("TDLType")]
    public int TDLType { get; set; }

    /// <summary>
    /// A number representing sample rate in samples per second for audio
    /// data.The data rate is in bits per second for digital data.
    /// </summary>
    [JsonProperty("SampleRate")]
    public long SampleRate { get; set; }

    /// <summary>
    /// A number representing the number of samples in the audio data.
    /// </summary>
    [JsonProperty("SampleCount")]
    public long SampleCount { get; set; }

    /// <summary>
    /// A base64-encoded string representing the data content of the message.
    /// </summary>
    [JsonProperty("SampleData")]
    public string SampleData { get; set; }

    /// <summary>
    /// A number representing the index of a prerecorded audio file that is
    /// to be looked up in a known database for playing.
    /// </summary>
    [JsonProperty("DatabaseIndex")]
    public long DatabaseIndex { get; set; }

    /// <summary>
    /// The protocol id of the data stream.
    /// </summary>
    [JsonProperty("UserProtocolID")]
    public int UserProtocolID { get; set; }

    public void HandleMessage()
    {
        throw new System.NotImplementedException();
    }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<WebLVCRadioSignalInteractionMessage>(message);
    }
}
