﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;

public class MakVrfCreateObject : InteractionMessage, IChildMessage
{
    /// <summary>
    /// A DtSimulationAddress identifying the particular VR-Forces back-end to
    /// create the object.
    /// </summary>
    [JsonProperty("Address")]
    public int[] Address;

    /// <summary>
    /// A string used to uniquely identify the object. This string must be unique for
    /// all objects in the exercise.
    /// </summary>
    [JsonProperty("Name")]
    public string Name;

    /// <summary>
    /// The type of the new simulation object. This is a 7-tuple number that
    /// matches the DIS/RPR Entity Type value.
    /// </summary>
    [JsonProperty("ObjectType")]
    public int[] ObjectType;

    /// <summary>
    /// The force value for the new simulation object. 0 is other, 1 is friendly, 2
    /// is opposing, 3 is neutral.
    /// </summary>
    [JsonProperty("ForceType")]
    public Force ForceType;

    /// <summary>
    /// A string associated with the new object. This string provides an additional
    /// means to identify an object without the strict uniqueness requirement of object
    /// name.
    /// </summary>
    [JsonProperty("Label")]
    public string Label;

    /// <summary>
    /// A list of the vectors that make up the object's geometry (for example, the
    /// vertices that make up the points along a route). For simulation object position, the
    /// position is just an alias for the first vertex.Vertices must be specified in geocentric
    /// coordinates.
    /// </summary>
    [JsonProperty("Vertices")]
    public System.Array[] Vertices;

    /// <summary>
    /// A double value that is the initial heading of the object in radians. A value
    /// of 0.0 is north and positive values are clockwise.Default: 0.0.
    /// </summary>
    [JsonProperty("Heading")]
    public double Heading;

    /// <summary>
    /// A bool flag indicating whether or not the Z elements in the object's
    /// vertex list have meaning.For example, phase lines do not have meaningful Z
    /// elements.Default: false.
    /// </summary>
    [JsonProperty("Projection")]
    public bool Projection;

    /// <summary>
    /// A bool flag indicating whether the object's vertices make up a closed
    ///  figure(that is, does the last vertex connect with the first). A control area is an
    /// example of an object that is a closed figure.Default: false.
    /// </summary>
    [JsonProperty("ClosedFigure")]
    public bool ClosedFigure;

    /// <summary>
    /// A bool flag indicating whether or not you want to create a sub-
    /// object. The parameter file may contain a list of subobjects.When building from
    /// the bottom up(for example, using AggregateAs or explicitly calling addSubordi-
    /// nate) then the subobjects in the parameter list should be ignored.Default: false.
    /// </summary>
    [JsonProperty("CreateSubObjects")]
    public bool CreateSubObjects;

    ///// <summary>
    ///// not in the doc
    ///// </summary>
    //[JsonProperty("InteractionType")]
    //public string InteractionType;

    /// <summary>
    /// not in the doc
    /// </summary>
    [JsonProperty("ClampToGround")]
    public bool ClampToGround;

    public WebLVCMessage Parse(string message)
    {   
        return JsonConvert.DeserializeObject<MakVrfCreateObject>(message);
    }

    public void HandleMessage()
    {
    }
}
