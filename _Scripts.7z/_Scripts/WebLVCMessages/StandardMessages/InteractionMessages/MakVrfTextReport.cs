﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;

public class MakVrfTextReport : InteractionMessage, IChildMessage
{
    [JsonProperty("marking")]
    public string marking;

    [JsonProperty("diguyCharacter")]
    public string diguyCharacter;

    [JsonProperty("diguyAppearance")]
    public string diguyAppearance;

    [JsonProperty("diguyAnimation")]
    public string diguyAnimation;
    public WebLVCMessage Parse(string message)
    {
        //FillFields(message);
        //return this;
        return JsonConvert.DeserializeObject<WebLVCWeaponFireInteractionMessage>(message);
    }

    public void HandleMessage()
    {
        Debug.Log("got an MakVrfTextReport message");
    }
    private void FillFields(string diguyData)
    {
        string[] data = diguyData.Split(':');
        marking = data[0];
        diguyCharacter = data[1];
        diguyAppearance = data[2];
        diguyAnimation = data[3];
    }
}
