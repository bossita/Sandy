﻿using Newtonsoft.Json;

/// <summary>
/// The WebLVC:StartResume message directs one or more simulators to start or resume
/// simulating, or start or resume simulation of a specific entity.
/// </summary>
public class WebLVCStartResumeInteractionMessage : InteractionMessage, IChildMessage
{
    /// <summary>
    /// The DIS/RPR simulation ID of the receiving simulations, or the
    /// entity ID of a specific entity, expressed as an array of three numbers.The allowable
    /// values for the ID follow the DIS/RPR rules.
    /// </summary>
    [JsonProperty("ReceivingEntity")]
    public int[] ReceivingEntity { get; set; }

    #region ReceivingEntity helper functions
    public int GetReceivingEntitySiteID()
    {
        return this.ReceivingEntity == null ? 0 : this.ReceivingEntity[0];
    }

    public int GetReceivingEntityApplicationID()
    {
        return this.ReceivingEntity == null ? 0 : this.ReceivingEntity[1];
    }

    public int GetReceivingEntityEntityNumber()
    {
        return this.ReceivingEntity == null ? 0 : this.ReceivingEntity[2];
    }
    #endregion

    /// <summary>
    /// An integer used to identify a particular request. The value should
    /// be incremented for each request.
    /// </summary>
    [JsonProperty("RequestIdentifier")]
    public int RequestIdentifier { get; set; }

    /// <summary>
    /// A number representing the real world time of the request, as
    /// defined by DIS/RPR.
    /// </summary>
    [JsonProperty("RealWorldTime")]
    public long RealWorldTime { get; set; }

    /// <summary>
    /// A number representing the time of day in simulation time of the
    /// request, as defined by DIS/RPR.
    /// </summary>
    [JsonProperty("SimulationTime")]
    public long SimulationTime { get; set; }

    /// <summary>
    /// The DIS/RPR simulation ID (Site ID, Application ID) of the simulator
    /// requesting the start/resume action, expressed as an array of two numbers.
    /// </summary>
    [JsonProperty("OriginatingEntity")]
    public int[] OriginatingEntity { get; set; }

    #region OriginatingEntity helper functions
    public int GetOriginatingEntitySiteID()
    {
        return this.OriginatingEntity == null ? 0 : this.OriginatingEntity[0];
    }

    public int GetOriginatingEntityApplicationID()
    {
        return this.OriginatingEntity == null ? 0 : this.OriginatingEntity[1];
    }
    #endregion

    public void HandleMessage()
    {
        throw new System.NotImplementedException();
    }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<WebLVCStartResumeInteractionMessage>(message);
    }
}
