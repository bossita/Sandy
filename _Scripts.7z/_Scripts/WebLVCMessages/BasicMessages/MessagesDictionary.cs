﻿using System.Collections;
using System.Collections.Generic;

public static class MessagesDictionary
{
    public static Dictionary<string, WebLVCMessage> AttributeUpdateMessages = new Dictionary<string, WebLVCMessage>()
    {
        //{ WebLVCMessageKind.Any, new WebLVCAnyMessageParser() },
        //{ WebLVCMessageKind.Other, new WebLVCOtherMessageParser() },
        { "WebLVC:PhysicalEntity", new WebLVCPhysicalEntityMessage() },
        { "WebLVC:AggregateEntity", new WebLVCAggregateEntityMessage() },
        { "WebLVC:EnvironmentalEntity", new WebLVCEnvironmentalEntityMessage() },
        { "WebLVC:RadioTransmitter", new WebLVCRadioTransmitterMessage() },
        { "MAK:VRFAggregate", new WebLVCAggregateEntityMessage() },
    };

    public static Dictionary<string, WebLVCMessage> InteractionMessages = new Dictionary<string, WebLVCMessage>()
    {
        { "WebLVC:WeaponFire", new WebLVCWeaponFireInteractionMessage() },
        { "WebLVC:MunitionDetonation", new WebLVCMunitionDetonationInteractionMessage() },
        { "WebLVC:StartResume", new WebLVCStartResumeInteractionMessage() },
        { "WebLVC:StopFreeze", new WebLVCStopFreezeInteractionMessage() },
        { "WebLVC:RadioSignal", new WebLVCRadioSignalInteractionMessage() },
        { "MAK:VrfTextReport", new MakVrfTextReport() },
        { "MAK:VrfCreateObject", new MakVrfCreateObject() },
        { "MAK:VrfSet",  new MakVrfSet() },
    };

    public static Dictionary<WebLVCMessageKind, WebLVCMessage> WebLVCBasicMessages = new Dictionary<WebLVCMessageKind, WebLVCMessage>()
    {
    //    //{ WebLVCMessageKind.Any, new WebLVCAnyMessageParser() },
    //    //{ WebLVCMessageKind.Other, new WebLVCOtherMessageParser() },
        { WebLVCMessageKind.AttributeUpdate, new AttributeUpdateMessage() },
        { WebLVCMessageKind.Interaction, new InteractionMessage() },
        { WebLVCMessageKind.Connect, new ConnectMessage() },
        { WebLVCMessageKind.ObjectDeletion, new ObjectDeletionMessage() },
    };
}
