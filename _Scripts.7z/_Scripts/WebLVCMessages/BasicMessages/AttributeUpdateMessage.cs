﻿using Newtonsoft.Json;
using System.Collections.Generic;
/// <summary>
/// AttributeUpdate messages are used to convey values of the attributes of a WebLVC
/// object. While the names of the properties that carry the object’s state depend on the
/// object model, there are several common properties, such as ObjectName and Time-
/// Stamp, whose definitions are independent of the type of object being updated.The
/// rules that dictate when, or how frequently, an AttributeUpdate shall be sent depend on
/// the Object Model being used, and the type of object being updated.
/// </summary>
public class AttributeUpdateMessage : WebLVCMessage, IParentMessage
{
    /// <summary>
    /// The value of the ObjectName property is a string that uniquely identifies
    /// the WebLVC object for which the message is conveying an update. It is the responsibility
    /// of the application that is sending updates for an object (which might be either a
    /// client or the WebLVC Server) to ensure that it chooses a name that is not already in use.
    /// </summary>
    [JsonProperty("ObjectName")]
    public string ObjectName { get; set; }

    /// <summary>
    /// A string that indicates the Object Type of the WebLVC object for
    /// which the message is conveying an update(similar to the concept of HLA Object-
    /// Class or DIS PDU Kind). Based on the value of the ObjectType property, an application
    /// can determine what other properties it can expect the message to contain.
    /// For example, updates for objects of type WebLVC:PhysicalEntity may contain a
    /// WorldLocation property.
    /// </summary>
    [JsonProperty("ObjectType")]
    public string ObjectType { get; set; }

    /// <summary>
    /// The time at which the data is valid, using the DIS time stamp field
    /// format converted into hexadecimal ASCII character representation as defined by
    /// the RPR FOM. If time stamp is missing, the message is assumed to be valid at the
    /// time of receipt.
    /// </summary>
    [JsonProperty("Timestamp")]
    public string TimeStamp { get; set; }

    public override WebLVCMessage Transform(string message)
    {
        AttributeUpdateMessage convertedMessage = JsonConvert.DeserializeObject<AttributeUpdateMessage>(message);
        return MessagesDictionary.AttributeUpdateMessages[convertedMessage.ObjectType];
    }
}
