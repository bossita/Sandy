﻿using Newtonsoft.Json;
using System.Collections.Generic;
/// <summary>
/// Interaction messages send parameters of a simulation event or interaction. While the
/// names of the properties that carry the interactions parameters depend on the object
/// model, there are several common properties, such as TimeStamp, whose definitions are
/// independent of the type of interaction being sent.The rules that dictate when, or how
/// frequently, an interaction must be sent depend on the object model being used and the
/// type of interaction in question.
/// </summary>
public class InteractionMessage : WebLVCMessage, IParentMessage
{
    /// <summary>
    /// A string that indicates the type of the interaction sent by a WebLVC
    /// message(similar to HLA InteractionClass or DIS PDU Kind). All interaction messages
    /// must include the InteractionType property.Based on the value of the InteractionType
    /// property, an application can determine what other properties it can expect the message
    /// to contain. For example, interactions of type WebLVC:WeaponFire may contain a
    /// MunitionType property.
    ///
    /// Strings are used to represent interaction types (rather than enumerated numbers), to
    /// support easy extensibility.Strings allow naming conventions that make collisions
    /// unlikely among different users’ extensions, and avoid the need for a central repository
    /// of enumeration-to-string mappings for user extensions. By convention, interaction
    /// types defined by the Standard WebLVC Object Model have the prefix WebLVC: (for
    /// example, WebLVC:WeaponFire), while user extensions have a prefix that indicates the
    /// origin of an object model(for example, MyProject:MyInteractionKind or MyCompany:
    /// MyInteractionKind).
    /// </summary>
    [JsonProperty("InteractionType")]
    public string InteractionType { get; set; }

    /// <summary>
    /// The time at which the data is valid, using the DIS timestamp field format
    /// converted into hexadecimal ASCII character representation as defined by the RPRFOM.
    /// </summary>
    [JsonProperty("Timestamp")]
    public string TimeStamp { get; set; }

    public override WebLVCMessage Transform(string message)
    {
        InteractionMessage convertedMessage = JsonConvert.DeserializeObject<InteractionMessage>(message);
        return MessagesDictionary.InteractionMessages[convertedMessage.InteractionType];
    }
}
