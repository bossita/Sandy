﻿using Newtonsoft.Json;

/// <summary>
/// An application must send an ObjectDeletion message to inform the recipient that an
/// object it has been updating no longer exists.
/// </summary>
public class ObjectDeletionMessage : WebLVCMessage, IChildMessage
{
    /// <summary>
    /// ObjectName is a string representing the name of the object that has been deleted.
    /// </summary>
    [JsonProperty("ObjectName")]
    public string ObjectName { get; set; }

    public void HandleMessage()
    {
        MessagesHandler.DeleteEntity(this);
    }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<ObjectDeletionMessage>(message);
    }
}
