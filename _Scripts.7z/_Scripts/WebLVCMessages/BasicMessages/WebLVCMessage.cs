﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// MessageKind. All WebLVC messages must include the MessageKind property.
/// MessageKind is a number that indicates what kind of WebLVC message an object represents.
/// </summary>
public enum WebLVCMessageKind
{
    /// <summary>
    /// Any.
    /// </summary>
    Any = -1,

    /// <summary>
    /// Other.
    /// </summary>
    Other = 0,

    /// <summary>
    /// updates the values of attributes of a WebLVC object
    /// </summary>
    AttributeUpdate = 1,

    /// <summary>
    /// describes the parameters of an event or interaction
    /// </summary>
    Interaction = 2,

    /// <summary>
    /// simple handshake to connect client to server
    /// </summary>
    Connect = 3,

    /// <summary>
    /// informs recipient that a WebLVC object no longer exists
    /// </summary>
    ObjectDeletion = 4,

    Refresh = 5,

    Ping = 99,
}

/// <summary>
/// Represents the base class of WebLVC message, including the header property MessageKind.
/// </summary>
public class WebLVCMessage
{
    [JsonProperty("MessageKind")]
    public WebLVCMessageKind MessageKind { get; set; }

    public virtual WebLVCMessage Transform(string message)
    {
        return MessagesDictionary.WebLVCBasicMessages[this.MessageKind];
    }

    public WebLVCMessage ParseAll(string message)
    {
        WebLVCMessage convertedMessage = this.Transform(message);
        if (convertedMessage is IParentMessage)
        {
            convertedMessage = (convertedMessage as IParentMessage)?.Transform(message);
        }

        if (!(convertedMessage is IChildMessage))
        {
            Debug.LogError("Something went wrong");
            return null;
        }

        return (convertedMessage as IChildMessage)?.Parse(message);
    }
}
