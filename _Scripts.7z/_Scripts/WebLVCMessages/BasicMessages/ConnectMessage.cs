﻿using Newtonsoft.Json;

/// <summary>
/// A client application is not required to send a Connect message to the server in order to
/// connect.The client can start sending AttributeUpdates and Interactions immediately
/// upon opening its WebSocket to the server.However, it is often desirable to provide the
/// server with additional information about the client, so that the server can pass such
/// information along to the rest of the federation.
/// </summary>
public class ConnectMessage : WebLVCMessage, IChildMessage
{
    /// <summary>
    /// ClientName is a string representing the name of the client federate.
    /// </summary>
    [JsonProperty("ClientName")]
    public string ClientName { get; set; }

    /// <summary>
    /// A number representing the version of WebLVC to be used for
    /// communication between the connecting client and server.If WebLVCVersion is
    /// omitted, it is assumed that the client is using the default version of the WebLVC standard
    /// supported by the server.
    /// </summary>
    [JsonProperty("WebLVCVersion")]
    public float WebLVCVersion { get; set; }

    public void HandleMessage()
    {
        throw new System.NotImplementedException();
    }

    public WebLVCMessage Parse(string message)
    {
        return JsonConvert.DeserializeObject<ConnectMessage>(message);
    }
}
