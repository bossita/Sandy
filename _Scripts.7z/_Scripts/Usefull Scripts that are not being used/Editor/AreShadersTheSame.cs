﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

public class AreShadersTheSame : MonoBehaviour
{
    [SerializeField]
    public RenderTexture renderTexture;

    [SerializeField]
    public GameObject objectToCalculateDistinction;

    [SerializeField]
    public GameObject parentOfObjectsToCombine;

    private MeshRenderer meshRenderer;
    private int indexMat;
    private bool didCalculation;
    private Dictionary<ShaderDataHolder, Dictionary<ShaderDataHolder, List<ShaderDataHolder>>> shaderPropertiesCombinationTransferedToMaterialList;
    private MeshRenderer[] meshRenderers;
    private Dictionary<Material, MaterialPropertyBlock> distinctMaterialsAndTheirProps;
    private MeshRenderer meshRendererOfDistinctionObject;
    private List<Material> distinctMaterials;
    private List<ShaderDataHolder> shadersData;
    private int indexMessage = 1;
    private Dictionary<Material, List<ShaderDataHolder>> materailAndShadersThatCanBeAppliedToIt = new Dictionary<Material, List<ShaderDataHolder>>();
    private float currentTime = 0;
    private int indexShaderToCheckForSameImage = 0;
    private int indexOfMaterialForPossibilities = 0;
    private int indexShaderUsed = 0;
    private List<Texture2D> texturesVisualizedByMaterialGiven = new List<Texture2D>();
    private int indexTextureMaterial = 0;
    private bool ConstructedSharedMaterialsTextures = false;
    private ShaderDataHolder currentShaderDatHolderToApply;
    private MaterialPropertyBlock materialPropertyBlock;
    private Material currentMaterialCheckingForSubstitues;

    void Start()
    {
        didCalculation = false;
        indexMat = 0;
        meshRenderer = objectToCalculateDistinction.GetComponent<MeshRenderer>();
        shadersData = new List<ShaderDataHolder>();
        meshRenderers = parentOfObjectsToCombine.GetComponentsInChildren<MeshRenderer>();
        materialPropertyBlock = new MaterialPropertyBlock();
        meshRendererOfDistinctionObject = objectToCalculateDistinction.GetComponent<MeshRenderer>();
        distinctMaterials = new List<Material>();
        foreach (MeshRenderer currentMeshRenderer in meshRenderers)
        {
            Material[] materials = currentMeshRenderer.sharedMaterials;
            foreach (Material matUsed in materials)
            {
                if (!distinctMaterials.Contains(matUsed))
                {
                    distinctMaterials.Add(matUsed);
                }
            }
        }
        Debug.Log(distinctMaterials.Count);
        foreach (Material materialUsed in distinctMaterials)
        {
            Shader currentShader = materialUsed.shader;
            int numberOfProperties = ShaderUtil.GetPropertyCount(currentShader);
            ShaderDataHolder shaderData = new ShaderDataHolder(materialUsed);
            for (int indexShaderProperty = 0; indexShaderProperty < numberOfProperties; indexShaderProperty++)
            {
                AddPropertyDependingOnType(shaderData, materialUsed, indexShaderProperty);
            }
            shadersData.Add(shaderData);
        }


        Debug.Log("...............");
        // key is the shaderDataHolder that the properties data being transfered to the other shader
        // value is dictionary of the shaderDataHolder that takes the data from the shader key
        // the list of materials is combination of the properties of the shader key.
        shaderPropertiesCombinationTransferedToMaterialList = new Dictionary<ShaderDataHolder, Dictionary<ShaderDataHolder, List<ShaderDataHolder>>>();
        Dictionary<ShaderDataHolder, List<ShaderDataHolder>> shaderDataWithGreaterOrEqualPropsShadersDatas = ShaderDataByGreaterOrEqualPropsShadersDatas(shadersData);

        for (int indexShaderData = 0; indexShaderData < shadersData.Count; indexShaderData++)
        {
            ShaderDataHolder shaderToTakeDataFrom = shadersData[indexShaderData];
            //List<ShaderDataHolder> ShaderToTransferDataTo = shadersData.FindAll((currentShaderData) => shaderToTakeDataFrom.HasLessOrEqualAmountOfProperties(currentShaderData));
            List<ShaderDataHolder> ShaderToTransferDataTo = shaderDataWithGreaterOrEqualPropsShadersDatas[shaderToTakeDataFrom];
            Dictionary<ShaderDataHolder, List<ShaderDataHolder>> shaderPossibilities = ConstructShaderPossibilitiesByDataGiven(shaderToTakeDataFrom, ShaderToTransferDataTo);
            shaderPropertiesCombinationTransferedToMaterialList.Add(shaderToTakeDataFrom, shaderPossibilities);
        }
    }

    private Dictionary<ShaderDataHolder, List<ShaderDataHolder>> ShaderDataByGreaterOrEqualPropsShadersDatas(List<ShaderDataHolder> shaderDataHolders)
    {
        Dictionary<ShaderDataHolder, List<ShaderDataHolder>> outputDictionary = new Dictionary<ShaderDataHolder, List<ShaderDataHolder>>();
        for (int indexShaderCheckingWith = 0; indexShaderCheckingWith < shaderDataHolders.Count - 1; indexShaderCheckingWith++)
        {
            ShaderDataHolder shaderCheckingWith = shaderDataHolders[indexShaderCheckingWith];
            for (int innerIndexShader = indexShaderCheckingWith + 1; innerIndexShader < shaderDataHolders.Count; innerIndexShader++)
            {
                ShaderDataHolder currentShader = shaderDataHolders[innerIndexShader];
                ShaderDataHolder shaderWithLessOrEqualProps = shaderCheckingWith;
                ShaderDataHolder shaderWithMoreOrEqualProps = currentShader;
                if (currentShader.HasLessOrEqualAmountOfProperties(shaderCheckingWith))
                {
                    if (currentShader.AmountOfProperties == shaderCheckingWith.AmountOfProperties)
                    {
                        AddToGreaterPropsDictionary(outputDictionary, shaderWithLessOrEqualProps, shaderWithMoreOrEqualProps);
                    }
                    shaderWithLessOrEqualProps = currentShader;
                    shaderWithMoreOrEqualProps = shaderCheckingWith;
                }
                AddToGreaterPropsDictionary(outputDictionary, shaderWithLessOrEqualProps, shaderWithMoreOrEqualProps);
            }
        }
        return outputDictionary;
    }
    private void AddToGreaterPropsDictionary(Dictionary<ShaderDataHolder, List<ShaderDataHolder>> dictionaryToAddTo, ShaderDataHolder lessOrEqualPropsKey,
                                                                                                                     ShaderDataHolder greaterOrEqualPropsValue)
    {
        List<ShaderDataHolder> greaterPropsShaders;
        if (dictionaryToAddTo.TryGetValue(lessOrEqualPropsKey, out greaterPropsShaders))
        {
            greaterPropsShaders.Add(greaterOrEqualPropsValue);
        }
        else
        {
            greaterPropsShaders = new List<ShaderDataHolder>();
            greaterPropsShaders.Add(greaterOrEqualPropsValue);
            dictionaryToAddTo.Add(lessOrEqualPropsKey, greaterPropsShaders);
        }
    }
    private Dictionary<ShaderDataHolder, List<ShaderDataHolder>> ConstructShaderPossibilitiesByDataGiven(ShaderDataHolder shaderData, List<ShaderDataHolder> shadersThatCanFitData)
    {
        List<ShaderDataHolder> optionalShadersData;
        Dictionary<ShaderDataHolder, List<ShaderDataHolder>> possibleMaterialsOfShader = new Dictionary<ShaderDataHolder, List<ShaderDataHolder>>();

        foreach (ShaderDataHolder currentShaderData in shadersThatCanFitData)
        {
            optionalShadersData = new List<ShaderDataHolder>();
            AllPosibilitiesWithProperties(optionalShadersData, shaderData, currentShaderData);
            possibleMaterialsOfShader.Add(currentShaderData, optionalShadersData);
        }

        return possibleMaterialsOfShader;
    }
    private void AllPosibilitiesWithProperties(List<ShaderDataHolder> shaderPossibilitesToAddTo, ShaderDataHolder shaderToTakeDataFrom,
                                                                                ShaderDataHolder shaderToInitialValuesTo)
    {
        ShaderDataHolder dataHolderMadeByDataTransfer;
        if (shaderToTakeDataFrom.ShaderUsed == shaderToInitialValuesTo.ShaderUsed)
        {
            dataHolderMadeByDataTransfer = new ShaderDataHolder(shaderToInitialValuesTo.SharedMaterial);
            foreach (FloatProperty floatProp in shaderToTakeDataFrom.FloatsProperties)
            {
                dataHolderMadeByDataTransfer.AddFloatProperty(floatProp.floatName, floatProp.floatVariable);
            }
            foreach (TextureProperty textureProp in shaderToTakeDataFrom.TextureProperties)
            {
                if (textureProp.textureVariable != null)
                {
                    dataHolderMadeByDataTransfer.AddTextureProperty(textureProp.textureName, textureProp.textureVariable);
                }
            }
            foreach (ColorProperty colorProp in shaderToTakeDataFrom.ColorsProperties)
            {
                dataHolderMadeByDataTransfer.AddColorProperty(colorProp.colorName, colorProp.colorVariable);
            }
            shaderPossibilitesToAddTo.Add(dataHolderMadeByDataTransfer);
        }
        else
        {
            List<FloatProperty[]> floatsPossibilities = CombinationsGenerator.CombinationByMovement
                                                                (shaderToTakeDataFrom.FloatsProperties);
            List<TextureProperty[]> texturePossibilities = CombinationsGenerator.CombinationByMovement
                                                                (shaderToTakeDataFrom.TextureProperties);
            List<ColorProperty[]> colorPossibilities = CombinationsGenerator.CombinationByMovement
                                                                (shaderToTakeDataFrom.ColorsProperties);

            List<FloatProperty[]> floatsPossibilitiesToInitiate = CombinationsGenerator.CombinationByMovement
                                                                (shaderToInitialValuesTo.FloatsProperties);
            List<TextureProperty[]> texturePossibilitiesToInitiate = CombinationsGenerator.CombinationByMovement
                                                                (shaderToInitialValuesTo.TextureProperties);
            List<ColorProperty[]> colorPossibilitiesToInitiate = CombinationsGenerator.CombinationByMovement
                                                                (shaderToInitialValuesTo.ColorsProperties);

            // move all moving possibilites( a b c -> a b c , b c a , c a b) to shaderToInitialValuesTo materials
            foreach (FloatProperty[] optionalFloatProperties in floatsPossibilities)
            {
                foreach (TextureProperty[] optionalTextureProperties in texturePossibilities)
                {
                    foreach (ColorProperty[] optionalColorProperties in colorPossibilities)
                    {

                        foreach (FloatProperty[] initiateOptionalFloatProperties in floatsPossibilitiesToInitiate)
                        {
                            foreach (TextureProperty[] initiateOptionalTextureProperties in texturePossibilitiesToInitiate)
                            {
                                foreach (ColorProperty[] initiateOptionalColorProperties in colorPossibilitiesToInitiate)
                                {
                                    dataHolderMadeByDataTransfer = new ShaderDataHolder(shaderToInitialValuesTo.SharedMaterial);
                                    //materialToInitiate = new Material(shaderToInitialValuesTo.ShaderUsed);

                                    // to avoid index out of range exceptiom, although currently shaderToTakeDataFrom props length is always less or equal to shadersToConstruct
                                    int minLength = Mathf.Min(optionalColorProperties.Length, initiateOptionalColorProperties.Length);
                                    for (int indexColorProp = 0; indexColorProp < minLength; indexColorProp++)
                                    {
                                        ColorProperty colorProp = initiateOptionalColorProperties[indexColorProp];
                                        dataHolderMadeByDataTransfer.AddColorProperty(colorProp.colorName, optionalColorProperties[indexColorProp].colorVariable);
                                        //materialToInitiate.SetColor(colorProp.colorName, optionalColorProperties[indexColorProp].colorVariable);
                                    }
                                    minLength = Mathf.Min(optionalTextureProperties.Length, initiateOptionalTextureProperties.Length);
                                    for (int indexTexture = 0; indexTexture < minLength; indexTexture++)
                                    {
                                        TextureProperty textureProp = initiateOptionalTextureProperties[indexTexture];
                                        //materialToInitiate.SetTexture(textureProp.textureName, optionalTextureProperties[indexTexture].textureVariable);
                                        if (textureProp.textureVariable != null)
                                        {
                                            dataHolderMadeByDataTransfer.AddTextureProperty(textureProp.textureName, optionalTextureProperties[indexTexture].textureVariable);
                                        }
                                    }
                                    minLength = Mathf.Min(optionalFloatProperties.Length, initiateOptionalFloatProperties.Length);
                                    for (int indexFloat = 0; indexFloat < minLength; indexFloat++)
                                    {
                                        FloatProperty floatProp = initiateOptionalFloatProperties[indexFloat];
                                        //materialToInitiate.SetFloat(floatProp.floatName, optionalFloatProperties[indexFloat].floatVariable);
                                        dataHolderMadeByDataTransfer.AddFloatProperty(floatProp.floatName, optionalFloatProperties[indexFloat].floatVariable);
                                    }
                                    //materialsToAddTo.Add(materialToInitiate);
                                    shaderPossibilitesToAddTo.Add(dataHolderMadeByDataTransfer);
                                }
                            }
                        }
                    }
                }
            }
        }

    }
    private void AddPropertyDependingOnType(ShaderDataHolder shaderData, Material materialUsed, int indexProperty)
    {
        Shader shaderOfMaterial = materialUsed.shader;
        ShaderUtil.ShaderPropertyType shaderPropertyType = ShaderUtil.GetPropertyType(shaderOfMaterial, indexProperty);
        string propertyName = ShaderUtil.GetPropertyName(shaderOfMaterial, indexProperty);
        switch (shaderPropertyType)
        {
            case (ShaderUtil.ShaderPropertyType.Color):
                {
                    Color colorUsed = materialUsed.GetColor(propertyName);
                    shaderData.AddColorProperty(propertyName, colorUsed);
                    break;
                }
            case (ShaderUtil.ShaderPropertyType.Float | ShaderUtil.ShaderPropertyType.Range):
                {
                    float floatUsed = materialUsed.GetFloat(propertyName);
                    shaderData.AddFloatProperty(propertyName, floatUsed);
                    break;
                }
            case (ShaderUtil.ShaderPropertyType.Vector):
                {
                    break;
                }

            case (ShaderUtil.ShaderPropertyType.TexEnv):
                {
                    Texture textureUsed = materialUsed.GetTexture(propertyName);
                    shaderData.AddTextureProperty(propertyName, textureUsed);
                    break;
                }
        }
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (!ConstructedSharedMaterialsTextures)
        {
            Graphics.Blit(source, destination);
            Texture2D textureCapturedByCamera = SaveTexture();
            texturesVisualizedByMaterialGiven.Add(textureCapturedByCamera);
        }

        else if (!didCalculation)
        {
            Graphics.Blit(source, destination);
            int lengthOfDictionary = shaderPropertiesCombinationTransferedToMaterialList.Count;
            if (indexShaderToCheckForSameImage < lengthOfDictionary)
            {
                Texture2D initialTextureToCompareTo = texturesVisualizedByMaterialGiven[indexShaderToCheckForSameImage];
                Texture2D textureCapturedByCamera = ToTexture2D(renderTexture);
                if (AreTexturesTheSame(initialTextureToCompareTo, textureCapturedByCamera))
                {
                    Debug.Log(initialTextureToCompareTo + " is the same as " + textureCapturedByCamera + " " + indexMessage);
                    SaveTexture();
                    Debug.Log("previous shader : " + currentMaterialCheckingForSubstitues.shader + ", new Shader :  " + currentShaderDatHolderToApply.ShaderUsed);

                    List<ShaderDataHolder> shadersThatCanBeSeenAsShaderOutput;
                    if (materailAndShadersThatCanBeAppliedToIt.TryGetValue(currentMaterialCheckingForSubstitues, out shadersThatCanBeSeenAsShaderOutput))
                    {
                        shadersThatCanBeSeenAsShaderOutput.Add(currentShaderDatHolderToApply);
                    }
                    else
                    {
                        shadersThatCanBeSeenAsShaderOutput = new List<ShaderDataHolder>();
                        shadersThatCanBeSeenAsShaderOutput.Add(currentShaderDatHolderToApply);
                        materailAndShadersThatCanBeAppliedToIt.Add(currentMaterialCheckingForSubstitues, shadersThatCanBeSeenAsShaderOutput);
                    }
                    indexOfMaterialForPossibilities++;
                    indexShaderUsed = 0;
                    //SaveTexture();
                }
                else
                {
                    Debug.Log("NEVER NEVER NEVER its not the same.............................. " + indexMessage);
                }
                indexMessage++;
            }
            else
            {
                didCalculation = true;
                materailAndShadersThatCanBeAppliedToIt.OrderBy((matAndOptionalSubtitues) => matAndOptionalSubtitues.Value.Count);
                foreach (KeyValuePair<Material, List<ShaderDataHolder>> b in materailAndShadersThatCanBeAppliedToIt)
                {
                    Debug.Log(b.Key + " " + b.Value.Count);
                    b.Value.ForEach((Shad) => Debug.Log(Shad.SharedMaterial));
                }
                AssignNewShaderAccordingToPossibilites();
                List<Material> newDistinct = new List<Material>();
                meshRenderers = parentOfObjectsToCombine.GetComponentsInChildren<MeshRenderer>();
                foreach (MeshRenderer currentMeshRenderer in meshRenderers)
                {
                    Material[] materials = currentMeshRenderer.sharedMaterials;
                    foreach (Material matUsed in materials)
                    {
                        if (!newDistinct.Contains(matUsed))
                        {
                            newDistinct.Add(matUsed);
                            Debug.Log(matUsed.name + " " + matUsed.shader + " " + meshRenderer.name);
                        }

                    }
                }
                Debug.Log(newDistinct.Count);
            }
        }
    }
    private void AssignNewShaderAccordingToPossibilites()
    {
        List<Material> materialBlackList = new List<Material>();
        List<Material> materialsAlreadyApplied = new List<Material>();
        foreach (MeshRenderer currentMeshRenderer in meshRenderers)
        {
            Material[] materials = currentMeshRenderer.sharedMaterials;
            foreach (Material matUsed in materials)
            {
                List<ShaderDataHolder> dataHolderPossibilites;
                if (materailAndShadersThatCanBeAppliedToIt.TryGetValue(matUsed, out dataHolderPossibilites))
                {
                    ShaderDataHolder newShaderDataToMeshRenderer = FindShaderDataNotIncludedInBlackList(dataHolderPossibilites, materialBlackList, materialsAlreadyApplied, matUsed);
                    if (newShaderDataToMeshRenderer != null)
                    {
                        //Debug.Log(newShaderDataToMeshRenderer.SharedMaterial + " god damn");
                        currentMeshRenderer.sharedMaterial = newShaderDataToMeshRenderer.SharedMaterial;
                        AssignMaterialPropertyBlockByShaderData(currentMeshRenderer, materialPropertyBlock, newShaderDataToMeshRenderer);
                        if (!materialBlackList.Contains(matUsed))
                        {
                            materialBlackList.Add(matUsed);
                        }
                    }
                }

            }
        }
        //Debug.Log(materialsAlreadyApplied.Count + "............................................");

    }
    private ShaderDataHolder FindShaderDataNotIncludedInBlackList(List<ShaderDataHolder> shaderOptions, List<Material> materialBlackList, List<Material> materialAlreadyUsed, Material currentMaterialUsed)
    {
        // make it more suphisticated later
        ShaderDataHolder shaderFound = null;
        if (!materialAlreadyUsed.Contains(currentMaterialUsed))
        {
            shaderFound = shaderOptions.FirstOrDefault((shaderOption) => materialAlreadyUsed.Contains(shaderOption.SharedMaterial));
            if (shaderFound == null)
            {
                shaderFound = shaderOptions.FirstOrDefault((shaderOption) => !materialBlackList.Contains(shaderOption.SharedMaterial));
                if (shaderFound != null)
                {
                    if (!materialAlreadyUsed.Contains(shaderFound.SharedMaterial))
                    {
                        materialAlreadyUsed.Add(shaderFound.SharedMaterial);
                        Debug.Log(shaderFound.SharedMaterial + " has been added");
                    }
                }
                else
                {
                    materialAlreadyUsed.Add(currentMaterialUsed);
                }
            }
        }
        return shaderFound;
    }
    private void OnPreRender()
    {
        int lengthOfSharedMaterials = distinctMaterials.Count;
        if (indexTextureMaterial < lengthOfSharedMaterials)
        {
            meshRenderer.sharedMaterial = distinctMaterials[indexTextureMaterial];
            indexTextureMaterial++;
        }
        else
        {
            ConstructedSharedMaterialsTextures = true;
            int lengthOfDictionary = shaderPropertiesCombinationTransferedToMaterialList.Count;
            bool changedMaterialOfObject = false;
            while (indexShaderToCheckForSameImage < lengthOfDictionary && !changedMaterialOfObject)
            {
                KeyValuePair<ShaderDataHolder, Dictionary<ShaderDataHolder, List<ShaderDataHolder>>> possibleMaterialsConstructedToShaderData =
                                                                        shaderPropertiesCombinationTransferedToMaterialList.ElementAt(indexShaderToCheckForSameImage);
                currentMaterialCheckingForSubstitues = possibleMaterialsConstructedToShaderData.Key.SharedMaterial;
                Dictionary<ShaderDataHolder, List<ShaderDataHolder>> possibleShadersPropsConstructed = possibleMaterialsConstructedToShaderData.Value;
                if (indexOfMaterialForPossibilities < possibleShadersPropsConstructed.Count)
                {
                    KeyValuePair<ShaderDataHolder, List<ShaderDataHolder>> shadersPossibleOfShaderData =
                                                                                            possibleShadersPropsConstructed.ElementAt(indexOfMaterialForPossibilities);
                    List<ShaderDataHolder> shaderDataListConstructedByDataTransfer = shadersPossibleOfShaderData.Value;
                    if (indexShaderUsed < shaderDataListConstructedByDataTransfer.Count)
                    {
                        currentTime = Time.time;
                        currentShaderDatHolderToApply = shaderDataListConstructedByDataTransfer[indexShaderUsed];
                        if (indexShaderUsed == 0)
                        {
                            // new material need to be applied and not variations of the material props
                            meshRenderer.sharedMaterial = currentShaderDatHolderToApply.SharedMaterial;
                            meshRendererOfDistinctionObject.GetPropertyBlock(materialPropertyBlock);
                        }
                        AssignMaterialPropertyBlockByShaderData(meshRendererOfDistinctionObject, materialPropertyBlock, currentShaderDatHolderToApply);

                        indexShaderUsed++;
                        changedMaterialOfObject = true;
                    }
                    else
                    {
                        indexShaderUsed = 0;
                        indexOfMaterialForPossibilities++;
                    }
                }
                else
                {
                    indexOfMaterialForPossibilities = 0;
                    indexShaderToCheckForSameImage++;
                }
            }
        }
    }
    private void AssignMaterialPropertyBlockByShaderData(MeshRenderer meshRendererToAssignTo, MaterialPropertyBlock materialPropertyBlock, ShaderDataHolder dataToTransfer)
    {
        materialPropertyBlock.Clear();
        foreach (ColorProperty colorProp in dataToTransfer.ColorsProperties)
        {
            materialPropertyBlock.SetColor(colorProp.colorName, colorProp.colorVariable);
        }
        foreach (TextureProperty textureProp in dataToTransfer.TextureProperties)
        {
            if (textureProp.textureVariable != null)
            {
                materialPropertyBlock.SetTexture(textureProp.textureName, textureProp.textureVariable);
            }
        }
        foreach (FloatProperty floatProp in dataToTransfer.FloatsProperties)
        {
            materialPropertyBlock.SetFloat(floatProp.floatName, floatProp.floatVariable);
        }
        meshRendererToAssignTo.SetPropertyBlock(materialPropertyBlock);
    }
    public bool AreTexturesTheSame(Texture2D firstTexture, Texture2D secondTexture)
    {
        bool areTheSame = true;

        if (firstTexture.width != secondTexture.width || firstTexture.height != secondTexture.height)
        {
            areTheSame = false;
        }
        areTheSame = (firstTexture.imageContentsHash == secondTexture.imageContentsHash);
        return areTheSame;
    }

    public Texture2D SaveTexture()
    {
        const string CREATION_STARTING_PATH = "Assets/Texture";
        Texture2D texture = ToTexture2D(renderTexture);
        AssetDatabase.CreateAsset(texture, CREATION_STARTING_PATH + "(" + indexMat + ") " + ".asset");
        indexMat++;
        return texture;
    }

    private Texture2D ToTexture2D(RenderTexture renderTexture)
    {
        Texture2D texture = new Texture2D(renderTexture.width, renderTexture.height, TextureFormat.RGB24, false);
        RenderTexture.active = renderTexture;
        texture.ReadPixels(new Rect(0, 0, renderTexture.width, renderTexture.height), 0, 0);
        texture.Apply();
        return texture;
    }
}
